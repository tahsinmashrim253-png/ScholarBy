'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  Target,
  Award,
  Sparkles,
  GraduationCap,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  BookmarkCheck,
  Zap,
  ArrowRight,
  ShieldCheck,
  BarChart3,
  BookOpen,
  Microscope,
} from 'lucide-react';
import { useProfile } from '@/context/ProfileContext';
import { MOCK_UNIVERSITIES } from '@/lib/mockData';
import { getCountryFlag } from '@/lib/countryFlags';
import Link from 'next/link';

export default function ProfileTrackerPage() {
  const { student } = useProfile();
  const flagEmoji = getCountryFlag(student.user.country);

  const [selectedUniId, setSelectedUniId] = useState<string>(MOCK_UNIVERSITIES[0].id);
  const [selectedMajor, setSelectedMajor] = useState<string>(student.major || 'Computer Science');

  const selectedUni = MOCK_UNIVERSITIES.find((u) => u.id === selectedUniId) || MOCK_UNIVERSITIES[0];

  // Dynamic Acceptance Probability Model
  const baseRate = Math.max(5, 100 - (selectedUni.ranking || 10) * 2.5);
  const gpaBonus = (student.gpa || 3.8) >= 3.9 ? 15 : 8;
  const satBonus = student.testScores.some((t) => Number(t.totalScore) >= 1500) ? 18 : 10;
  const olympiadBonus = student.achievements.some((a) => a.category === 'Olympiad') ? 22 : 10;
  const projectBonus = student.projects.length * 6;

  const rawProbability = Math.round(baseRate + gpaBonus + satBonus + olympiadBonus + projectBonus);
  const acceptanceProbability = Math.min(96, Math.max(35, rawProbability));

  const academicFit = Math.min(98, Math.round(((student.gpa || 3.9) / 4.0) * 100));
  const researchFit = Math.min(95, 75 + student.projects.length * 10);
  const credentialScore = Math.min(99, 80 + student.achievements.length * 7);
  const documentReadiness = 90;

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="pb-6 border-b border-[#E2E8F0] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Target className="w-4 h-4 text-[#0052CC]" />
              <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
                ScholarBy AI Profile Tracker
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1 flex items-center space-x-2">
              <span>Mock Acceptance Probability Tracker</span>
              <span className="text-2xl">{flagEmoji}</span>
            </h1>
            <p className="text-xs text-[#64748B] mt-1">
              Select any university to benchmark your real-time ScholarBy Passport™ credentials against target admission criteria.
            </p>
          </div>

          <Link
            href="/settings"
            className="px-4 py-2.5 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center space-x-2 shadow-blue-lg self-start sm:self-auto"
          >
            <Sparkles className="w-4 h-4 text-[#FFD60A]" />
            <span>Update Profile Scores</span>
          </Link>
        </div>

        {/* University & Major Selectors */}
        <div className="mt-6 p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">Select Target University</label>
            <select
              value={selectedUniId}
              onChange={(e) => setSelectedUniId(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl px-3.5 py-2.5 text-xs text-[#1A1A1A] font-bold focus:border-[#0052CC] focus:outline-none"
            >
              {MOCK_UNIVERSITIES.map((u) => (
                <option key={u.id} value={u.id}>
                  #{u.ranking} {u.name} ({u.country})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1A1A1A] mb-1.5">Select Target Major / Field</label>
            <select
              value={selectedMajor}
              onChange={(e) => setSelectedMajor(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl px-3.5 py-2.5 text-xs text-[#1A1A1A] font-bold focus:border-[#0052CC] focus:outline-none"
            >
              <option value="Computer Science">Computer Science & AI</option>
              <option value="Artificial Intelligence">Artificial Intelligence & Robotics</option>
              <option value="Applied Mathematics">Applied Mathematics & Data Science</option>
              <option value="Biomedical Engineering">Biomedical Engineering & Genomics</option>
              <option value="Mechanical Engineering">Mechanical Engineering & Control</option>
              <option value="Financial Engineering">Financial Engineering & Quant Finance</option>
            </select>
          </div>
        </div>

        {/* Big Probability Banner */}
        <div className="mt-6 p-8 rounded-3xl bg-[#0052CC] text-white shadow-blue-lg relative overflow-hidden">
          <div className="absolute right-0 top-0 w-96 h-96 bg-[#FFD60A]/10 blur-[100px] rounded-full pointer-events-none" />

          <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
            <div className="space-y-3 text-center md:text-left">
              <span className="px-3 py-1 rounded-full bg-[#FFD60A] text-[#1A1A1A] font-extrabold text-xs inline-block">
                AI MATCH ANALYSIS • VERIFIED PASSPORT
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold leading-tight">
                {selectedUni.name}
              </h2>
              <p className="text-xs sm:text-sm text-white/80 max-w-xl">
                Target Major: <span className="font-bold text-[#FFD60A]">{selectedMajor}</span> | Ranking: <span className="font-bold">#{selectedUni.ranking} Global</span> | Acceptance Rate: <span className="font-bold">{selectedUni.acceptanceRate}%</span>
              </p>
            </div>

            <div className="bg-white text-[#1A1A1A] p-6 rounded-2xl shadow-2xl text-center min-w-[220px]">
              <span className="text-[10px] font-bold text-[#64748B] uppercase font-mono tracking-widest block">
                Estimated Acceptance Chance
              </span>
              <div className="text-5xl font-extrabold font-mono text-[#0052CC] my-1">
                {acceptanceProbability}%
              </div>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold inline-block">
                High Competitive Match
              </span>
            </div>
          </div>
        </div>

        {/* 4 Breakdown Metrics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center justify-between text-xs text-[#64748B] font-bold">
              <span>Academic Fit (GPA & SAT)</span>
              <GraduationCap className="w-4 h-4 text-[#0052CC]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#1A1A1A] mt-2">{academicFit}%</div>
            <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-[#0052CC] h-full rounded-full" style={{ width: `${academicFit}%` }} />
            </div>
            <p className="text-[11px] text-[#64748B] mt-2">GPA {student.gpa} | SAT 1560</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center justify-between text-xs text-[#64748B] font-bold">
              <span>Research & Project Fit</span>
              <Microscope className="w-4 h-4 text-[#0052CC]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#1A1A1A] mt-2">{researchFit}%</div>
            <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-[#0052CC] h-full rounded-full" style={{ width: `${researchFit}%` }} />
            </div>
            <p className="text-[11px] text-[#64748B] mt-2">{student.projects.length} Edge AI Projects</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center justify-between text-xs text-[#64748B] font-bold">
              <span>Verified Credentials Score</span>
              <Award className="w-4 h-4 text-[#0052CC]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#1A1A1A] mt-2">{credentialScore}%</div>
            <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-[#FFD60A] h-full rounded-full" style={{ width: `${credentialScore}%` }} />
            </div>
            <p className="text-[11px] text-[#64748B] mt-2">USACO Gold & ISEF Medal</p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center justify-between text-xs text-[#64748B] font-bold">
              <span>Documentation Readiness</span>
              <BookmarkCheck className="w-4 h-4 text-[#0052CC]" />
            </div>
            <div className="text-2xl font-bold font-mono text-[#1A1A1A] mt-2">{documentReadiness}%</div>
            <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-[#0052CC] h-full rounded-full" style={{ width: `${documentReadiness}%` }} />
            </div>
            <p className="text-[11px] text-[#64748B] mt-2">Transcripts & Recommendation</p>
          </div>
        </div>

        {/* AI Probability Boost Checklist */}
        <div className="mt-8 p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-[#FFD60A] fill-current" />
            <h3 className="text-lg font-bold text-[#1A1A1A]">AI Recommendations to Boost Acceptance Chance to 95%+</h3>
          </div>

          <div className="space-y-3">
            <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] flex items-start justify-between gap-4">
              <div className="flex items-start space-x-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-[#1A1A1A]">Upload USACO Gold Official Verification Badge</h4>
                  <p className="text-xs text-[#64748B] mt-0.5">Increases research & Olympiad credential weight for {selectedUni.name}.</p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-[#0052CC] bg-[#0052CC]/10 px-2.5 py-1 rounded-lg whitespace-nowrap">
                +8% Probability
              </span>
            </div>

            <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] flex items-start justify-between gap-4">
              <div className="flex items-start space-x-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-[#1A1A1A]">Request Recommendation Letter from Dr. Vance (MIT CSAIL)</h4>
                  <p className="text-xs text-[#64748B] mt-0.5">Faculty recommendations significantly boost top-tier STEM acceptance odds.</p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-[#0052CC] bg-[#0052CC]/10 px-2.5 py-1 rounded-lg whitespace-nowrap">
                +6% Probability
              </span>
            </div>

            <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] flex items-start justify-between gap-4">
              <div className="flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-[#1A1A1A]">Finalize Supplemental Essay on Autonomous Edge AI</h4>
                  <p className="text-xs text-[#64748B] mt-0.5">Use ScholarBy AI Essay Assistant to refine narrative clarity and alignment.</p>
                </div>
              </div>
              <Link
                href="/ai-assistant"
                className="text-xs font-mono font-bold text-[#0052CC] bg-[#0052CC]/10 px-2.5 py-1 rounded-lg whitespace-nowrap hover:bg-[#0052CC]/20"
              >
                Launch AI Assistant →
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
