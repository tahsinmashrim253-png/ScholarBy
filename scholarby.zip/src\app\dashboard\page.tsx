'use client';

import React from 'react';
import Link from 'next/link';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  Sparkles,
  BookmarkCheck,
  GraduationCap,
  BadgeCheck,
  Calendar,
  ArrowRight,
  TrendingUp,
  Clock,
  CheckSquare,
  Award,
  BookOpen,
} from 'lucide-react';
import { useProfile } from '@/context/ProfileContext';
import { INITIAL_APPLICATIONS, MOCK_OPPORTUNITIES } from '@/lib/mockData';
import { calculateOpportunityMatch } from '@/lib/matchEngine';
import { getCountryFlag } from '@/lib/countryFlags';

export default function DashboardPage() {
  const { student } = useProfile();
  const flagEmoji = getCountryFlag(student.user.country);

  const matchedOpps = MOCK_OPPORTUNITIES.map((opp) =>
    calculateOpportunityMatch(student, opp)
  ).sort((a, b) => b.score - a.score);

  const avgReadiness = Math.round(
    INITIAL_APPLICATIONS.reduce((acc, curr) => acc + curr.readinessScore, 0) /
      INITIAL_APPLICATIONS.length
  );

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl">
        {/* Welcome Header & Role Capsule */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-[#E2E8F0] gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
                Student Command Center
              </span>
              <span className="text-xs text-[#64748B]">•</span>
              <span className="text-xs text-[#64748B]">{student.school}</span>
              <span className="text-xs text-[#64748B]">• {student.user.country} {flagEmoji}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1 flex items-center space-x-2">
              <span>Welcome back, {student.user.name.split(' ')[0]}</span>
              <span className="text-xl">{flagEmoji}</span>
              <span className="w-5 h-5 rounded-full bg-[#FFD60A] text-[#1A1A1A] flex items-center justify-center text-xs font-bold" title="Verified Scholar">
                ✓
              </span>
            </h1>
          </div>

          <div className="flex items-center space-x-3">
            <Link
              href={`/passport/${student.user.name.toLowerCase().replace(/\s+/g, '')}`}
              className="px-4 py-2 rounded-xl bg-white border border-[#E2E8F0] hover:border-[#0052CC] text-xs font-bold text-[#1A1A1A] transition-colors flex items-center space-x-2 shadow-sm"
            >
              <Award className="w-4 h-4 text-[#0052CC]" />
              <span>ScholarBy Passport (94%)</span>
            </Link>
            <Link
              href="/applications"
              className="px-4 py-2 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center space-x-1.5 shadow-blue-lg"
            >
              <BookmarkCheck className="w-4 h-4" />
              <span>Bucket List ({INITIAL_APPLICATIONS.length})</span>
            </Link>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          <div className="p-4 rounded-xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center justify-between text-xs text-[#64748B] font-semibold">
              <span>Avg Readiness Score</span>
              <TrendingUp className="w-4 h-4 text-[#0052CC]" />
            </div>
            <div className="text-2xl font-bold text-[#1A1A1A] mt-2 font-mono">{avgReadiness}%</div>
            <p className="text-[11px] text-[#64748B] mt-1">Target benchmark: 85%+</p>
          </div>

          <div className="p-4 rounded-xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center justify-between text-xs text-[#64748B] font-semibold">
              <span>Upcoming Deadline</span>
              <Clock className="w-4 h-4 text-[#0052CC]" />
            </div>
            <div className="text-2xl font-bold text-[#1A1A1A] mt-2 font-mono">48 Days</div>
            <p className="text-[11px] text-[#64748B] mt-1">MIT EECS (Nov 01, 2026)</p>
          </div>

          <div className="p-4 rounded-xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center justify-between text-xs text-[#64748B] font-semibold">
              <span>AI Opportunity Matches</span>
              <Sparkles className="w-4 h-4 text-[#0052CC]" />
            </div>
            <div className="text-2xl font-bold text-[#1A1A1A] mt-2 font-mono">
              {matchedOpps.filter((m) => m.score >= 80).length} High Match
            </div>
            <p className="text-[11px] text-[#64748B] mt-1">Based on {student.major} profile</p>
          </div>

          <div className="p-4 rounded-xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center justify-between text-xs text-[#64748B] font-semibold">
              <span>Verified Credentials</span>
              <BadgeCheck className="w-4 h-4 text-[#0052CC]" />
            </div>
            <div className="text-2xl font-bold text-[#1A1A1A] mt-2 font-mono">
              {student.achievements.filter((a) => a.isVerified).length} Verified
            </div>
            <p className="text-[11px] text-[#64748B] mt-1">USACO & ISEF Award</p>
          </div>
        </div>

        {/* Two-Column Main Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          {/* Column 1 & 2: Application Command Center Bucket List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <BookmarkCheck className="w-5 h-5 text-[#0052CC]" />
                  <h2 className="text-base font-bold text-[#1A1A1A]">Active University Applications</h2>
                </div>
                <Link href="/applications" className="text-xs font-mono font-bold text-[#0052CC] hover:underline">
                  Manage Checklist →
                </Link>
              </div>

              <div className="space-y-3">
                {INITIAL_APPLICATIONS.map((app) => (
                  <div
                    key={app.id}
                    className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] hover:border-[#0052CC] transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                              app.category === 'DREAM'
                                ? 'bg-[#FFD60A] text-[#1A1A1A]'
                                : 'bg-[#0052CC]/10 text-[#0052CC]'
                            }`}
                          >
                            {app.category}
                          </span>
                          <span className="text-xs font-mono text-[#64748B]">
                            Deadline: {app.deadline}
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-[#1A1A1A] mt-1">
                          {app.universityName}
                        </h3>
                        <p className="text-xs text-[#64748B]">{app.programName}</p>
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <span className="text-[10px] text-[#64748B] uppercase font-mono font-semibold">Readiness</span>
                          <div className="text-sm font-bold font-mono text-[#0052CC]">
                            {app.readinessScore}%
                          </div>
                        </div>
                        <span
                          className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                            app.status === 'IN_PROGRESS'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {app.status.replace('_', ' ')}
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full mt-3 overflow-hidden">
                      <div
                        className="bg-[#0052CC] h-full rounded-full transition-all duration-500"
                        style={{ width: `${app.readinessScore}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Column 3: Top Recommended Opportunities */}
          <div className="space-y-6">
            <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-5 h-5 text-[#0052CC]" />
                  <h2 className="text-base font-bold text-[#1A1A1A]">Top Matched Opportunities</h2>
                </div>
                <Link href="/opportunities" className="text-xs font-mono font-bold text-[#0052CC] hover:underline">
                  All Matches →
                </Link>
              </div>

              <div className="space-y-3">
                {matchedOpps.slice(0, 3).map(({ opportunity: opp, score, reasons }) => (
                  <div
                    key={opp.id}
                    className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] hover:border-[#0052CC] transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-[#0052CC]/10 text-[#0052CC]">
                        {opp.category}
                      </span>
                      <span className="text-xs font-bold font-mono text-[#0052CC]">
                        {score}% Match
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-[#1A1A1A] mt-2 leading-tight">
                      {opp.title}
                    </h4>
                    <p className="text-[11px] text-[#64748B] mt-0.5">{opp.organization}</p>

                    <p className="text-[10px] text-emerald-700 font-semibold mt-2 flex items-center">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5" />
                      {reasons[0]}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
