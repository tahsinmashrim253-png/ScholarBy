'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  Sparkles,
  Globe,
  BadgeCheck,
  Search,
  ExternalLink,
  MessageSquare,
  CheckCircle2,
  Trophy,
  Code,
  Cpu,
  Database,
} from 'lucide-react';
import { MOCK_OPPORTUNITIES, CURRENT_STUDENT } from '@/lib/mockData';
import { calculateOpportunityMatch } from '@/lib/matchEngine';

export default function OpportunitiesPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [remoteOnly, setRemoteOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const matchedOpps = MOCK_OPPORTUNITIES.map((opp) =>
    calculateOpportunityMatch(CURRENT_STUDENT, opp)
  ).sort((a, b) => b.score - a.score);

  const categories = [
    { id: 'ALL', label: 'All Opportunities' },
    { id: 'HACKATHON', label: 'Hackathons 🏆' },
    { id: 'COMPETITIVE_PROGRAMMING', label: 'Competitive Programming ⚡' },
    { id: 'DATATHON', label: 'Datathons & AI 📊' },
    { id: 'ROBOTICS', label: 'Robotics & Hardware 🤖' },
    { id: 'RESEARCH', label: 'Research RAs 🔬' },
    { id: 'SCHOLARSHIP', label: 'Scholarships 🎓' },
  ];

  const filteredOpps = matchedOpps.filter(({ opportunity }) => {
    if (selectedCategory !== 'ALL' && opportunity.category !== selectedCategory) return false;
    if (remoteOnly && !opportunity.isRemote) return false;
    if (
      searchQuery &&
      !opportunity.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !opportunity.organization.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !opportunity.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="pb-6 border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-[#0052CC]" />
            <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
              ScholarBy Explore Hub
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
            Explore Olympiads, Hackathons, Datathons, Robotics & ICPC Competitions
          </h1>
          <p className="text-xs text-[#64748B] mt-1">
            Discover student competitions, collegiate hackathons, AI datathons, and research positions matched to your skills.
          </p>
        </div>

        {/* Category Filters Toolbar */}
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2 overflow-x-auto w-full md:w-auto pb-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-[#0052CC] text-white shadow-sm'
                    : 'bg-white text-[#64748B] hover:text-[#1A1A1A] border border-[#E2E8F0]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-3 w-full md:w-auto">
            <button
              onClick={() => setRemoteOnly(!remoteOnly)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors flex items-center space-x-1.5 ${
                remoteOnly
                  ? 'bg-[#0052CC]/10 text-[#0052CC] border-[#0052CC]/40'
                  : 'bg-white text-[#64748B] border-[#E2E8F0]'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Remote Only</span>
            </button>

            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#64748B]" />
              <input
                type="text"
                placeholder="Search Hackathons, ICPC, Kaggle..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-[#E2E8F0] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#1A1A1A] placeholder-[#64748B] focus:border-[#0052CC] focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Listings */}
        <div className="space-y-4 mt-6">
          {filteredOpps.map(({ opportunity: opp, score, reasons }) => (
            <div
              key={opp.id}
              className="p-6 rounded-2xl bg-white border border-[#E2E8F0] hover:border-[#0052CC] transition-colors shadow-sm"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start space-x-4">
                  {opp.creatorAvatar ? (
                    <img
                      src={opp.creatorAvatar}
                      alt={opp.creatorName}
                      className="w-12 h-12 rounded-xl object-cover border border-[#0052CC] flex-shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-[#0052CC]/10 border border-[#0052CC]/30 flex items-center justify-center text-[#0052CC] font-bold">
                      {opp.organization[0]}
                    </div>
                  )}

                  <div>
                    <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                      <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-[#FFD60A] text-[#1A1A1A] uppercase">
                        {opp.category.replace('_', ' ')}
                      </span>
                      {opp.isVerified && (
                        <span className="flex items-center text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          <BadgeCheck className="w-3.5 h-3.5 mr-1 text-emerald-600" /> Human Verified ✓
                        </span>
                      )}
                      <span className="text-[10px] font-bold font-mono bg-blue-50 text-[#0052CC] px-2 py-0.5 rounded border border-blue-200">
                        ⚡ AI Change Alert: Verified Data Active
                      </span>
                      <span className="text-xs text-[#64748B]">• {opp.organization}</span>
                    </div>

                    <h3 className="text-lg font-bold text-[#1A1A1A] mt-1.5">{opp.title}</h3>
                    <p className="text-xs text-[#64748B] mt-1 max-w-3xl leading-relaxed">
                      {opp.description}
                    </p>

                    {opp.prizePool && (
                      <div className="mt-2 text-xs font-mono text-[#0052CC] font-bold flex items-center">
                        <Trophy className="w-3.5 h-3.5 mr-1 text-[#FFD60A] fill-current" />
                        <span>Prize Pool / Stipend: {opp.prizePool}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Match Badge & Actions */}
                <div className="flex flex-col items-end justify-between flex-shrink-0">
                  <div className="px-3.5 py-2 rounded-2xl bg-[#0052CC]/10 border border-[#0052CC]/30 text-right space-y-0.5">
                    <span className="text-[9px] font-mono text-[#64748B] uppercase font-bold">4D AI Suitability</span>
                    <div className="text-base font-extrabold font-mono text-[#0052CC]">
                      {score}% Match
                    </div>
                    <div className="text-[9px] text-emerald-700 font-bold font-mono">Academic: 94% | Field: 98%</div>
                  </div>

                  <div className="mt-4 flex items-center space-x-2">
                    <Link
                      href="/messages"
                      className="px-3 py-2 rounded-xl bg-white border border-[#E2E8F0] hover:border-[#0052CC] text-xs font-bold text-[#1A1A1A] transition-colors flex items-center space-x-1"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-[#0052CC]" />
                      <span>Contact</span>
                    </Link>

                    <a
                      href={opp.applicationUrl || '#'}
                      target="_blank"
                      rel="noreferrer"
                      className="px-4 py-2 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center space-x-1.5 shadow-sm"
                    >
                      <span>Register / Apply</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Rationale & Tags */}
              <div className="mt-4 pt-4 border-t border-[#E2E8F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-1">
                  {reasons.map((reason, idx) => (
                    <div key={idx} className="flex items-center text-emerald-700 font-bold text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 flex-shrink-0 text-emerald-600" />
                      <span>{reason}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center space-x-1.5 flex-wrap">
                  {opp.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#F8FAFC] text-[#64748B] border border-[#E2E8F0] font-bold"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
