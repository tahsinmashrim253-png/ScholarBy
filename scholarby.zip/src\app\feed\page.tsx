'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  Compass,
  Heart,
  MessageSquare,
  Share2,
  Bookmark,
  BadgeCheck,
  Send,
  PlusCircle,
  Image as ImageIcon,
  Link2,
} from 'lucide-react';
import { MOCK_FEED_POSTS, CURRENT_STUDENT } from '@/lib/mockData';
import { FeedPostItem } from '@/types';

export default function FeedPage() {
  const [posts, setPosts] = useState<FeedPostItem[]>(MOCK_FEED_POSTS);
  const [activeFilter, setActiveFilter] = useState<string>('ALL');
  const [newPostContent, setNewPostContent] = useState('');

  const handleLikePost = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        const isLiked = !p.isLiked;
        return {
          ...p,
          isLiked,
          likesCount: isLiked ? p.likesCount + 1 : p.likesCount - 1,
        };
      })
    );
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim()) return;

    const newPost: FeedPostItem = {
      id: `post_${Date.now()}`,
      authorName: CURRENT_STUDENT.user.name,
      authorRole: CURRENT_STUDENT.user.role,
      authorAvatar: CURRENT_STUDENT.user.avatarUrl,
      authorHeadline: CURRENT_STUDENT.user.headline,
      isVerified: true,
      content: newPostContent,
      postType: 'PROJECT',
      tags: ['ScholarBy', 'Research', 'Academic'],
      createdAt: 'Just now',
      likesCount: 1,
      commentsCount: 0,
      isLiked: true,
    };

    setPosts([newPost, ...posts]);
    setNewPostContent('');
  };

  const filteredPosts = posts.filter((p) => {
    if (activeFilter === 'ALL') return true;
    return p.postType === activeFilter;
  });

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto">
        {/* Header */}
        <div className="pb-6 border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <Compass className="w-4 h-4 text-[#0052CC]" />
            <span className="text-xs font-mono text-[#0052CC] uppercase tracking-wider font-bold">
              ScholarBy Academic Knowledge Feed
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
            Academic & Research Knowledge Feed ({MOCK_FEED_POSTS.length}+ Posts)
          </h1>
          <p className="text-xs text-[#64748B] mt-1">
            Connecting verified student research showcases, professor RA positions, Olympiad medalists, and university announcements.
          </p>
        </div>

        {/* Post Creation Box */}
        <form
          onSubmit={handleCreatePost}
          className="mt-6 p-4 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-3"
        >
          <div className="flex items-start space-x-3">
            <img
              src={CURRENT_STUDENT.user.avatarUrl}
              alt={CURRENT_STUDENT.user.name}
              className="w-10 h-10 rounded-full object-cover border-2 border-[#0052CC]"
            />
            <textarea
              rows={3}
              placeholder="Share a research update, Olympiad medal win, paper abstract, or academic question..."
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-3 text-xs text-[#1A1A1A] placeholder-[#64748B] focus:border-[#0052CC] focus:outline-none resize-none"
            />
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-[#E2E8F0]">
            <div className="flex items-center space-x-2 text-xs text-[#64748B]">
              <button
                type="button"
                className="p-1.5 rounded-lg bg-[#F8FAFC] hover:text-[#0052CC] border border-[#E2E8F0] flex items-center space-x-1"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Media</span>
              </button>
              <button
                type="button"
                className="p-1.5 rounded-lg bg-[#F8FAFC] hover:text-[#0052CC] border border-[#E2E8F0] flex items-center space-x-1"
              >
                <Link2 className="w-3.5 h-3.5" />
                <span>DOI / GitHub</span>
              </button>
            </div>

            <button
              type="submit"
              disabled={!newPostContent.trim()}
              className="px-4 py-2 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] disabled:opacity-50 transition-colors flex items-center space-x-1.5 shadow-sm"
            >
              <span>Publish</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>

        {/* Post Type Filters */}
        <div className="flex items-center space-x-2 mt-6 pb-2 border-b border-[#E2E8F0] overflow-x-auto">
          {['ALL', 'ADMISSION', 'RESEARCH', 'OLYMPIAD', 'PROJECT', 'OPPORTUNITY', 'TUTORING', 'HACKATHON'].map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                activeFilter === filter
                  ? 'bg-[#0052CC] text-white shadow-sm'
                  : 'bg-white text-[#64748B] hover:text-[#1A1A1A] border border-[#E2E8F0]'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Feed Posts */}
        <div className="space-y-4 mt-6">
          {filteredPosts.map((post) => (
            <article
              key={post.id}
              className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4"
            >
              {/* Author Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  {post.authorAvatar ? (
                    <img
                      src={post.authorAvatar}
                      alt={post.authorName}
                      className="w-10 h-10 rounded-full object-cover border border-[#E2E8F0]"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-[#0052CC]/10 border border-[#0052CC]/30 flex items-center justify-center font-bold text-[#0052CC]">
                      {post.authorName[0]}
                    </div>
                  )}

                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="text-sm font-bold text-[#1A1A1A]">{post.authorName}</span>
                      {post.isVerified && (
                        <span className="w-4 h-4 rounded-full bg-[#FFD60A] text-[#1A1A1A] flex items-center justify-center text-[10px] font-bold" title="Verified Scholar">
                          ✓
                        </span>
                      )}
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-[#F8FAFC] text-[#64748B] border border-[#E2E8F0] font-bold">
                        {post.authorRole}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#64748B]">{post.authorHeadline}</p>
                  </div>
                </div>

                <span className="text-[10px] font-mono text-[#64748B]">{post.createdAt}</span>
              </div>

              {/* Content Body */}
              <p className="text-xs sm:text-sm text-[#1A1A1A] leading-relaxed whitespace-pre-line font-medium">
                {post.content}
              </p>

              {/* Tags */}
              <div className="flex items-center space-x-1.5 flex-wrap">
                {post.tags.map((t) => (
                  <span
                    key={t}
                    className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#0052CC]/10 text-[#0052CC] border border-[#0052CC]/20 font-bold"
                  >
                    {t}
                  </span>
                ))}
              </div>

              {/* Actions Footer */}
              <div className="pt-3 border-t border-[#E2E8F0] flex items-center justify-between text-xs text-[#64748B]">
                <button
                  onClick={() => handleLikePost(post.id)}
                  className={`flex items-center space-x-1.5 hover:text-[#0052CC] transition-colors ${
                    post.isLiked ? 'text-[#0052CC] font-bold' : ''
                  }`}
                >
                  <Heart className={`w-4 h-4 ${post.isLiked ? 'fill-[#0052CC]' : ''}`} />
                  <span>{post.likesCount}</span>
                </button>

                <button className="flex items-center space-x-1.5 hover:text-[#1A1A1A] transition-colors">
                  <MessageSquare className="w-4 h-4" />
                  <span>{post.commentsCount} Comments</span>
                </button>

                <button className="flex items-center space-x-1.5 hover:text-[#1A1A1A] transition-colors">
                  <Bookmark className="w-4 h-4" />
                  <span>Save</span>
                </button>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  );
}
