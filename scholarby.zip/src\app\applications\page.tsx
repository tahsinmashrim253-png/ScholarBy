'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  BookmarkCheck,
  Plus,
  Trash2,
  CheckSquare,
  Clock,
  Building2,
  GraduationCap,
  Sparkles,
  CheckCircle2,
  FileText,
} from 'lucide-react';
import { INITIAL_APPLICATIONS, MOCK_UNIVERSITIES } from '@/lib/mockData';
import { ApplicationBucketItem, AppCategory, AppStatus } from '@/types';
import Link from 'next/link';

export default function ApplicationsPage() {
  const [applications, setApplications] = useState<ApplicationBucketItem[]>(INITIAL_APPLICATIONS);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const handleToggleChecklist = (appId: string, itemIdx: number) => {
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id !== appId) return app;
        const newChecklist = [...app.checklist];
        newChecklist[itemIdx].isCompleted = !newChecklist[itemIdx].isCompleted;
        const completedCount = newChecklist.filter((c) => c.isCompleted).length;
        const readinessScore = Math.round((completedCount / newChecklist.length) * 100);

        return {
          ...app,
          checklist: newChecklist,
          readinessScore,
        };
      })
    );
  };

  const filteredApps = applications.filter((app) => {
    if (selectedCategory === 'ALL') return true;
    return app.category === selectedCategory;
  });

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="pb-6 border-b border-[#E2E8F0] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <BookmarkCheck className="w-4 h-4 text-[#0052CC]" />
              <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
                Application OS & Bucket List
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
              University Bucket List (Dream / Target / Safety)
            </h1>
            <p className="text-xs text-[#64748B] mt-1">
              Centralized admission application checklist, deadline countdowns, and readiness score tracking.
            </p>
          </div>

          <Link
            href="/universities"
            className="px-4 py-2.5 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center space-x-1.5 shadow-blue-lg self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Add University to Bucket List</span>
          </Link>
        </div>

        {/* Category Filter Toolbar */}
        <div className="mt-6 flex items-center space-x-2 pb-2 border-b border-[#E2E8F0]">
          {['ALL', 'DREAM', 'TARGET', 'SAFETY'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedCategory === cat
                  ? 'bg-[#0052CC] text-white shadow-sm'
                  : 'bg-white text-[#64748B] hover:text-[#1A1A1A] border border-[#E2E8F0]'
              }`}
            >
              {cat} {cat !== 'ALL' && `(${applications.filter((a) => a.category === cat).length})`}
            </button>
          ))}
        </div>

        {/* Applications Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          {filteredApps.map((app) => (
            <div
              key={app.id}
              className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC] transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span
                    className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                      app.category === 'DREAM'
                        ? 'bg-[#FFD60A] text-[#1A1A1A]'
                        : app.category === 'TARGET'
                        ? 'bg-[#0052CC]/10 text-[#0052CC]'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {app.category}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#64748B]">
                    Deadline: {app.deadline}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-[#1A1A1A] mt-3 leading-snug">
                  {app.universityName}
                </h3>
                <p className="text-xs text-[#64748B] mt-0.5">{app.programName}</p>

                {/* Readiness Score Progress */}
                <div className="mt-4 p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0]">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#64748B] font-bold">Application Readiness</span>
                    <span className="font-mono font-extrabold text-[#0052CC]">
                      {app.readinessScore}%
                    </span>
                  </div>
                  <div className="w-full bg-[#E2E8F0] h-2 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-[#0052CC] h-full rounded-full transition-all duration-500"
                      style={{ width: `${app.readinessScore}%` }}
                    />
                  </div>
                </div>

                {/* Interactive Checklist */}
                <div className="mt-4 space-y-2">
                  <span className="text-[10px] font-mono text-[#64748B] uppercase font-bold tracking-wider">
                    Application Requirement Checklist
                  </span>
                  {app.checklist.map((item, idx) => (
                    <button
                      key={item.id}
                      onClick={() => handleToggleChecklist(app.id, idx)}
                      className={`w-full text-left p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-between transition-colors ${
                        item.isCompleted
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                          : 'bg-white border-[#E2E8F0] text-[#1A1A1A] hover:border-[#0052CC]'
                      }`}
                    >
                      <span className="truncate pr-2">{item.title}</span>
                      <span className="text-xs font-bold">
                        {item.isCompleted ? '✓ Done' : '○ Pending'}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                <span className="text-[#64748B] font-bold">Status: {app.status.replace('_', ' ')}</span>
                <Link
                  href="/profile-tracker"
                  className="text-[#0052CC] font-bold hover:underline flex items-center space-x-1"
                >
                  <span>Probability Tracker →</span>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
