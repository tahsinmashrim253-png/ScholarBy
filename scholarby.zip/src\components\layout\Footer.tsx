import React from 'react';
import Link from 'next/link';
import Image from 'next/image';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#003D99] border-t border-[#0052CC] py-12 text-xs text-white/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-white border border-white/20 flex items-center justify-center p-1 shadow-sm">
              <Image src="/logo.png" alt="ScholarBy Logo" width={26} height={26} className="object-contain" />
            </div>
            <span className="text-xl font-extrabold text-white font-sans">
              Scholar<span className="text-[#FFD60A]">By</span>
            </span>
          </div>
          <p className="text-xs text-white/80 leading-relaxed">
            The global student opportunity and academic ecosystem. Unifying high school, university admissions, research labs, Olympiads, and lifelong careers.
          </p>
          <div className="text-[11px] font-mono text-[#FFD60A] font-semibold">
            © {new Date().getFullYear()} ScholarBy Ecosystem Inc. All rights reserved.
          </div>
        </div>

        <div>
          <h4 className="font-bold text-white mb-3 uppercase tracking-wider text-[11px] font-mono">Ecosystem Tabs</h4>
          <ul className="space-y-2 font-medium">
            <li><Link href="/feed" className="hover:text-[#FFD60A] transition-colors">Academic Feed (100+ Posts)</Link></li>
            <li><Link href="/opportunities" className="hover:text-[#FFD60A] transition-colors">Explore Opportunities</Link></li>
            <li><Link href="/professors" className="hover:text-[#FFD60A] transition-colors">Professors & Labs (20+)</Link></li>
            <li><Link href="/universities" className="hover:text-[#FFD60A] transition-colors">University Directory (20+)</Link></li>
            <li><Link href="/applications" className="hover:text-[#FFD60A] transition-colors">Application Bucket List</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-white mb-3 uppercase tracking-wider text-[11px] font-mono">Marketplace Portals</h4>
          <ul className="space-y-2 font-medium">
            <li><Link href="/tutors" className="hover:text-[#FFD60A] transition-colors">Tutor Marketplace (20+)</Link></li>
            <li><Link href="/tutors?tab=coaching" className="hover:text-[#FFD60A] transition-colors">Coaching Center Profiles (20+)</Link></li>
            <li><Link href="/consultants" className="hover:text-[#FFD60A] transition-colors">Admissions Consultants (20+)</Link></li>
            <li><Link href="/opportunities?tab=olympiads" className="hover:text-[#FFD60A] transition-colors">Olympiads & Competitions (20+)</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-white mb-3 uppercase tracking-wider text-[11px] font-mono">Trust & Verification</h4>
          <ul className="space-y-2 font-medium">
            <li><span className="text-[#FFD60A] font-bold">✓ ScholarBy Verified™</span></li>
            <li><span className="hover:text-white">Encrypted Document Vault</span></li>
            <li><span className="hover:text-white">Privacy Controls</span></li>
            <li><span className="hover:text-white">Academic Integrity Charter</span></li>
          </ul>
        </div>
      </div>
    </footer>
  );
};
