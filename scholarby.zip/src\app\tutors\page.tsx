'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  Award,
  Search,
  Star,
  CheckCircle2,
  MessageSquare,
  BookOpen,
  School,
  ExternalLink,
} from 'lucide-react';
import { MOCK_TUTORS } from '@/lib/mockData';
import Link from 'next/link';

export default function TutorsPage() {
  const [activeTab, setActiveTab] = useState<'TUTORS' | 'COACHING'>('TUTORS');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTutors = MOCK_TUTORS.filter((t) => {
    if (
      searchQuery &&
      !t.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !t.subjects.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()))
    ) {
      return false;
    }
    return true;
  });

  const coachingCenters = [
    { id: 'cc_1', name: 'Elite SAT & Olympiad Academy', location: 'New York & Online', rating: 4.98, reviews: 142, subjects: ['Digital SAT 1550+', 'USACO Gold Prep', 'AP Calculus BC'], fee: '$450 / month', success: '98% Admitted to Top 20', description: 'Premier test prep and STEM Olympiad training institute.' },
    { id: 'cc_2', name: 'Global IELTS & TOEFL Mastery Institute', location: 'London & Online', rating: 4.95, reviews: 98, subjects: ['IELTS 8.5 Band', 'TOEFL 110+', 'Academic English'], fee: '$380 / month', success: '99% Band 8.0+ Success', description: 'Official certified English language academy for international admissions.' },
    { id: 'cc_3', name: 'JEE Genius & NEET Science Academy', location: 'Singapore & Online', rating: 4.96, reviews: 210, subjects: ['JEE Advanced Physics', 'NEET Biology', 'Olympiad Chemistry'], fee: '$500 / month', success: 'Top 500 All India Rankers', description: 'Rigorous engineering & medical entrance exam coaching center.' },
    { id: 'cc_4', name: 'IB & A-Level Excellence Center', location: 'Zurich & Online', rating: 4.92, reviews: 85, subjects: ['IB Higher Level Math', 'A-Level Physics', 'AP Chem'], fee: '$420 / month', success: '43+ Average IB Score', description: 'Specialized international baccalaureate diploma coaching.' }
  ];

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="pb-6 border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <Award className="w-4 h-4 text-[#0052CC]" />
            <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
              ScholarBy Tutor & Coaching Marketplace
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
            Verified Tutors & Coaching Center Profiles (20+ Experts)
          </h1>
          <p className="text-xs text-[#64748B] mt-1">
            Connect with 1-on-1 tutors and accredited coaching academies for SAT, IELTS, AP, Olympiads, and Programming.
          </p>
        </div>

        {/* Tab Switcher & Search */}
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveTab('TUTORS')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
                activeTab === 'TUTORS'
                  ? 'bg-[#0052CC] text-white shadow-sm'
                  : 'bg-white text-[#64748B] hover:text-[#1A1A1A] border border-[#E2E8F0]'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>1-on-1 Verified Tutors (20+)</span>
            </button>
            <button
              onClick={() => setActiveTab('COACHING')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
                activeTab === 'COACHING'
                  ? 'bg-[#0052CC] text-white shadow-sm'
                  : 'bg-white text-[#64748B] hover:text-[#1A1A1A] border border-[#E2E8F0]'
              }`}
            >
              <School className="w-4 h-4" />
              <span>Coaching Center Profiles (20+)</span>
            </button>
          </div>

          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#64748B]" />
            <input
              type="text"
              placeholder="Search SAT, IELTS, Math, C++..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-[#E2E8F0] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#1A1A1A] placeholder-[#64748B] focus:border-[#0052CC] focus:outline-none"
            />
          </div>
        </div>

        {/* Tutors Grid */}
        {activeTab === 'TUTORS' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            {filteredTutors.map((tutor) => (
              <div
                key={tutor.id}
                className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC] transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <img
                        src={tutor.avatarUrl}
                        alt={tutor.name}
                        className="w-12 h-12 rounded-xl object-cover border border-[#0052CC]"
                      />
                      <div>
                        <div className="flex items-center space-x-1.5">
                          <h3 className="text-base font-bold text-[#1A1A1A]">{tutor.name}</h3>
                          {tutor.isVerified && (
                            <span className="w-4 h-4 rounded-full bg-[#FFD60A] text-[#1A1A1A] flex items-center justify-center text-[10px] font-bold">
                              ✓
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[#64748B]">{tutor.education}</p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-base font-extrabold font-mono text-[#0052CC]">{tutor.hourlyRate}</span>
                      <div className="flex items-center text-xs text-[#FFD60A] font-bold">
                        <Star className="w-3.5 h-3.5 fill-current mr-0.5" />
                        <span>{tutor.rating} ({tutor.reviewsCount})</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-[#64748B] mt-3 leading-relaxed">
                    {tutor.bio}
                  </p>

                  <div className="mt-3 flex items-center space-x-1.5 flex-wrap gap-y-1">
                    {tutor.subjects.map((s) => (
                      <span
                        key={s}
                        className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#0052CC]/10 text-[#0052CC] border border-[#0052CC]/20 font-bold"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                  <span className="text-emerald-700 font-bold">✓ Verified Educator</span>
                  <Link
                    href="/messages"
                    className="px-4 py-2 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center space-x-1.5 shadow-sm"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Book Session</span>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            {coachingCenters.map((cc) => (
              <div
                key={cc.id}
                className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC] transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-[#FFD60A] text-[#1A1A1A]">
                        Accredited Academy
                      </span>
                      <h3 className="text-lg font-bold text-[#1A1A1A] mt-2">{cc.name}</h3>
                      <p className="text-xs text-[#64748B]">{cc.location}</p>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-bold text-[#0052CC] font-mono">{cc.fee}</span>
                      <div className="flex items-center text-xs text-[#FFD60A] font-bold justify-end">
                        <Star className="w-3.5 h-3.5 fill-current mr-0.5" />
                        <span>{cc.rating} ({cc.reviews})</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-[#64748B] mt-3 leading-relaxed">
                    {cc.description}
                  </p>

                  <div className="mt-3 p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] text-xs">
                    <span className="text-[10px] text-[#64748B] uppercase font-mono font-bold block">Proven Results</span>
                    <span className="font-bold text-emerald-700">{cc.success}</span>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                  <span className="text-[#64748B] font-bold">Programs: {cc.subjects.join(', ')}</span>
                  <Link
                    href="/messages"
                    className="px-4 py-2 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors shadow-sm"
                  >
                    Enquire Now →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
