import {
  StudentPassport,
  UniversityData,
  ApplicationBucketItem,
  OpportunityItem,
  FeedPostItem,
  CommunityGroup,
  MessageThread,
  TutorListing,
  ConsultantListing,
  ProfessorListing,
  AiAgentStatus,
  ScholarshipChangeLog,
  MatchSuitabilityBreakdown,
  ContentFactoryItem,
} from '@/types';

export const CURRENT_STUDENT: StudentPassport = {
  "id": "sp_101",
  "userId": "user_alex",
  "user": {
    "id": "user_alex",
    "name": "Alex Chen",
    "email": "alex.chen@scholarby.edu",
    "role": "STUDENT",
    "country": "United States",
    "avatarUrl": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
    "headline": "AI & Robotics Researcher | Aspiring CS Undergraduate",
    "bio": "Passionate high school senior researching Graph Neural Networks & Autonomous Swarms. Medalist at USACO and IEEE High School Research Fellow.",
    "isVerified": true
  },
  "school": "Stuyvesant High School, NYC",
  "educationLevel": "High School Senior / Incoming Undergrad",
  "major": "Computer Science",
  "minor": "Applied Mathematics",
  "gpa": 3.96,
  "gradYear": 2026,
  "targetCountries": [
    "United States",
    "Singapore",
    "Switzerland",
    "United Kingdom",
    "Japan"
  ],
  "interests": [
    "Machine Learning",
    "Computer Vision",
    "Robotics",
    "Algorithms",
    "Competitive Programming",
    "Hackathons",
    "Datathons"
  ],
  "testScores": [
    {
      "id": "ts_1",
      "testType": "SAT",
      "totalScore": "1560",
      "breakdown": "Math: 800 | Reading & Writing: 760",
      "testDate": "2025-10-12"
    },
    {
      "id": "ts_2",
      "testType": "IELTS",
      "totalScore": "8.5",
      "breakdown": "Listening: 9.0 | Reading: 9.0 | Writing: 8.0 | Speaking: 8.0",
      "testDate": "2025-08-20"
    },
    {
      "id": "ts_3",
      "testType": "AP",
      "totalScore": "5/5 (5 Exams)",
      "breakdown": "AP CS A (5), AP Calc BC (5), AP Physics C (5), AP Chem (5), AP Stats (5)",
      "testDate": "2025-05-15"
    }
  ],
  "achievements": [
    {
      "id": "ach_1",
      "title": "USA Computing Olympiad (USACO) Gold Division Medalist",
      "issuer": "USACO Organization",
      "category": "Olympiad",
      "isVerified": true,
      "verifiedBy": "USACO Official Registry"
    },
    {
      "id": "ach_2",
      "title": "International Science & Engineering Fair (ISEF) 2nd Place Grand Award",
      "issuer": "Society for Science",
      "category": "Award",
      "isVerified": true,
      "verifiedBy": "Society for Science Verification"
    },
    {
      "id": "ach_3",
      "title": "Stanford TreeHacks 2026 Best AI Swarm Hackathon Trophy",
      "issuer": "Stanford TreeHacks",
      "category": "Hackathon",
      "isVerified": true,
      "verifiedBy": "Stanford Major League Hacking"
    }
  ],
  "projects": [
    {
      "id": "proj_1",
      "title": "NeuroSwarm: Decentralized Vision-Guided Drones",
      "description": "Engineered an edge-AI flocking algorithm running on Raspberry Pi CM4s, achieving 60fps obstacle avoidance without centralized GPS.",
      "role": "Lead Architect & Developer",
      "technologies": "Python, PyTorch, ROS2, C++",
      "githubUrl": "https://github.com/alexchen/neuroswarm",
      "projectUrl": "https://neuroswarm-demo.dev"
    },
    {
      "id": "proj_2",
      "title": "ScholarBy Vector Match Engine",
      "description": "Built a vector semantic similarity engine linking high school research papers to university lab publications.",
      "role": "Creator & Maintainer",
      "technologies": "Next.js, TypeScript, TailwindCSS",
      "githubUrl": "https://github.com/alexchen/scholarby-match"
    }
  ],
  "publications": [
    {
      "id": "pub_1",
      "title": "Decentralized Edge Flocking via Graph Attention Networks on Low-Power Micro-UAVs",
      "journal": "IEEE High School Research Journal & ArXiv Preprint",
      "doi": "10.1109/HSRJ.2025.10928374",
      "pubDate": "2025-11-04"
    }
  ]
};

export const MOCK_UNIVERSITIES: UniversityData[] = [
  {
    "id": "uni_1",
    "name": "Massachusetts Institute of Technology (MIT)",
    "country": "United States",
    "city": "Cambridge, MA",
    "ranking": 1,
    "tuitionFee": "$60,156 / yr",
    "acceptanceRate": 3.9,
    "description": "World premier STEM & Research institution focused on computer science, AI, engineering, and physical sciences.",
    "logoUrl": "https://images.unsplash.com/photo-1564981797816-1043664bf78d?w=300&auto=format&fit=crop&q=80",
    "website": "https://mit.edu",
    "programs": [
      {
        "id": "prog_1",
        "name": "Computer Science & Engineering (EECS)",
        "degree": "B.S. / M.Eng",
        "department": "School of Engineering",
        "deadline": "Nov 01, 2026",
        "tuitionPerYear": "$60,156",
        "requirements": [
          "SAT 1540+",
          "TOEFL 100+",
          "AP Calculus BC",
          "3 Recommendation Letters"
        ]
      },
      {
        "id": "prog_2",
        "name": "Artificial Intelligence & Decision Making",
        "degree": "B.S. / Ph.D.",
        "department": "Schwarzman College of Computing",
        "deadline": "Dec 15, 2026",
        "tuitionPerYear": "$60,156",
        "requirements": [
          "GRE Quantitative 168+",
          "Research Publication / Olympiad"
        ]
      }
    ]
  },
  {
    "id": "uni_2",
    "name": "Stanford University",
    "country": "United States",
    "city": "Stanford, CA",
    "ranking": 2,
    "tuitionFee": "$62,484 / yr",
    "acceptanceRate": 3.68,
    "description": "Leading private research university in Silicon Valley renowned for entrepreneurship, AI, physics, and bio-engineering.",
    "logoUrl": "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=300&auto=format&fit=crop&q=80",
    "website": "https://stanford.edu",
    "programs": [
      {
        "id": "prog_3",
        "name": "Computer Science & AI Track",
        "degree": "B.S. / M.S.",
        "department": "School of Engineering",
        "deadline": "Jan 05, 2027",
        "tuitionPerYear": "$62,484",
        "requirements": [
          "SAT 1520+",
          "IELTS 8.0+",
          "Coding Portfolio"
        ]
      }
    ]
  },
  {
    "id": "uni_3",
    "name": "Harvard University",
    "country": "United States",
    "city": "Cambridge, MA",
    "ranking": 3,
    "tuitionFee": "$59,076 / yr",
    "acceptanceRate": 3.41,
    "description": "Ivy League institution dedicated to academic excellence, law, medicine, economics, and interdisciplinary computational research.",
    "logoUrl": "https://images.unsplash.com/photo-1607237138185-eedd9c632b0b?w=300&auto=format&fit=crop&q=80",
    "website": "https://harvard.edu",
    "programs": [
      {
        "id": "prog_4",
        "name": "Applied Mathematics & BioStatistics",
        "degree": "A.B. / Ph.D.",
        "department": "SEAS",
        "deadline": "Jan 01, 2027",
        "tuitionPerYear": "$59,076",
        "requirements": [
          "SAT 1550+",
          "ISEF / Olympiad Distinction"
        ]
      }
    ]
  },
  {
    "id": "uni_4",
    "name": "University of Oxford",
    "country": "United Kingdom",
    "city": "Oxford",
    "ranking": 4,
    "tuitionFee": "£38,550 / yr",
    "acceptanceRate": 14.2,
    "description": "The oldest university in the English-speaking world, world-leading in humanities, medicine, physics, and mathematics.",
    "logoUrl": "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=300&auto=format&fit=crop&q=80",
    "website": "https://ox.ac.uk",
    "programs": [
      {
        "id": "prog_5",
        "name": "Mathematics & Computer Science",
        "degree": "MMathCompSci",
        "department": "Department of Computer Science",
        "deadline": "Oct 15, 2026",
        "tuitionPerYear": "£38,550",
        "requirements": [
          "MAT Exam Score 80+",
          "A*A*A in A-Levels"
        ]
      }
    ]
  },
  {
    "id": "uni_5",
    "name": "University of Cambridge",
    "country": "United Kingdom",
    "city": "Cambridge",
    "ranking": 5,
    "tuitionFee": "£39,150 / yr",
    "acceptanceRate": 15.8,
    "description": "Collegiate public research university renowned for Isaac Newton, Stephen Hawking, computer laboratory, and biotechnology.",
    "logoUrl": "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=300&auto=format&fit=crop&q=80",
    "website": "https://cam.ac.uk",
    "programs": [
      {
        "id": "prog_6",
        "name": "Tripos Computer Science",
        "degree": "BA (Hons) / MEng",
        "department": "Computer Laboratory",
        "deadline": "Oct 15, 2026",
        "tuitionPerYear": "£39,150",
        "requirements": [
          "TMUA Exam Score 7.5+",
          "STEP Math"
        ]
      }
    ]
  },
  {
    "id": "uni_6",
    "name": "ETH Zurich",
    "country": "Switzerland",
    "city": "Zurich",
    "ranking": 6,
    "tuitionFee": "CHF 1,460 / yr",
    "acceptanceRate": 27,
    "description": "Top European STEM university, alma mater of Albert Einstein, specializing in robotics, quantum engineering, and architecture.",
    "logoUrl": "https://images.unsplash.com/photo-1592280771190-3e2e4d571952?w=300&auto=format&fit=crop&q=80",
    "website": "https://ethz.ch",
    "programs": [
      {
        "id": "prog_7",
        "name": "Robotics, Systems & Control",
        "degree": "M.Sc.",
        "department": "D-MAVT",
        "deadline": "Dec 15, 2026",
        "tuitionPerYear": "CHF 1,460",
        "requirements": [
          "B.S. in Engineering / CS",
          "IELTS 7.5+"
        ]
      }
    ]
  },
  {
    "id": "uni_7",
    "name": "National University of Singapore (NUS)",
    "country": "Singapore",
    "city": "Singapore",
    "ranking": 8,
    "tuitionFee": "SGD $38,200 / yr",
    "acceptanceRate": 5,
    "description": "Asia flagship university excelling in AI, fintech, biomedical engineering, and global logistics.",
    "logoUrl": "https://images.unsplash.com/photo-1562774053-701939374585?w=300&auto=format&fit=crop&q=80",
    "website": "https://nus.edu.sg",
    "programs": [
      {
        "id": "prog_8",
        "name": "Data Science & Analytics",
        "degree": "B.Sc. (Hons)",
        "department": "School of Computing",
        "deadline": "Feb 28, 2027",
        "tuitionPerYear": "SGD $38,200",
        "requirements": [
          "SAT 1500+",
          "AP Calculus"
        ]
      }
    ]
  },
  {
    "id": "uni_8",
    "name": "University of Tokyo (UTokyo)",
    "country": "Japan",
    "city": "Tokyo",
    "ranking": 11,
    "tuitionFee": "¥535,800 / yr",
    "acceptanceRate": 10.5,
    "description": "Japan premier university leading global research in robotics, materials science, quantum computing, and astronomy.",
    "logoUrl": "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=300&auto=format&fit=crop&q=80",
    "website": "https://u-tokyo.ac.jp",
    "programs": [
      {
        "id": "prog_9",
        "name": "PEAK Environmental & Global Sciences",
        "degree": "B.S.",
        "department": "College of Arts & Sciences",
        "deadline": "Jan 10, 2027",
        "tuitionPerYear": "¥535,800",
        "requirements": [
          "SAT 1480+",
          "TOEFL 100+"
        ]
      }
    ]
  },
  {
    "id": "uni_9",
    "name": "University of Toronto",
    "country": "Canada",
    "city": "Toronto",
    "ranking": 18,
    "tuitionFee": "CAD $60,510 / yr",
    "acceptanceRate": 43,
    "description": "Canada top research institution, birthplace of deep learning (Geoffrey Hinton), medicine, and global public policy.",
    "logoUrl": "https://images.unsplash.com/photo-1588072432836-e10032774350?w=300&auto=format&fit=crop&q=80",
    "website": "https://utoronto.ca",
    "programs": [
      {
        "id": "prog_10",
        "name": "Computer Science Specialist",
        "degree": "B.Sc.",
        "department": "Faculty of Arts & Science",
        "deadline": "Jan 15, 2027",
        "tuitionPerYear": "CAD $60,510",
        "requirements": [
          "GPA 3.9+",
          "Supplemental Essay"
        ]
      }
    ]
  },
  {
    "id": "uni_10",
    "name": "UC Berkeley",
    "country": "United States",
    "city": "Berkeley, CA",
    "ranking": 10,
    "tuitionFee": "$44,008 / yr",
    "acceptanceRate": 11.4,
    "description": "Premier public university famous for open-source computer science, Silicon Valley tech innovation, and Nobel laureates.",
    "logoUrl": "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=300&auto=format&fit=crop&q=80",
    "website": "https://berkeley.edu",
    "programs": [
      {
        "id": "prog_11",
        "name": "EECS (Electrical Engineering & CS)",
        "degree": "B.S.",
        "department": "College of Engineering",
        "deadline": "Nov 30, 2026",
        "tuitionPerYear": "$44,008",
        "requirements": [
          "GPA 4.0",
          "Extracurricular Leadership"
        ]
      }
    ]
  },
  {
    "id": "uni_11",
    "name": "Imperial College London",
    "country": "United Kingdom",
    "city": "London",
    "ranking": 6,
    "tuitionFee": "£37,900 / yr",
    "acceptanceRate": 18,
    "description": "STEM-focused global university excelling in artificial intelligence, aeronautics, medicine, and business tech.",
    "logoUrl": "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=300&auto=format&fit=crop&q=80",
    "website": "https://imperial.ac.uk",
    "programs": [
      {
        "id": "prog_12",
        "name": "Computing (Artificial Intelligence)",
        "degree": "MEng",
        "department": "Department of Computing",
        "deadline": "Jan 15, 2027",
        "tuitionPerYear": "£37,900",
        "requirements": [
          "A*A*A in Math/Further Math"
        ]
      }
    ]
  },
  {
    "id": "uni_12",
    "name": "KAIST (Korea Advanced Inst. of Science & Tech)",
    "country": "South Korea",
    "city": "Daejeon",
    "ranking": 19,
    "tuitionFee": "KRW 6,800,000 / yr",
    "acceptanceRate": 15,
    "description": "South Korea flagship innovation university with 100% English medium instruction, robotics, and semiconductor engineering.",
    "logoUrl": "https://images.unsplash.com/photo-1519452635265-7b1fbfd1e4e0?w=300&auto=format&fit=crop&q=80",
    "website": "https://kaist.ac.kr",
    "programs": [
      {
        "id": "prog_13",
        "name": "School of Computing",
        "degree": "B.S.",
        "department": "College of Engineering",
        "deadline": "Jan 08, 2027",
        "tuitionPerYear": "KRW 6,800,000",
        "requirements": [
          "Full Scholarship Available",
          "IELTS 7.0+"
        ]
      }
    ]
  },
  {
    "id": "uni_13",
    "name": "University of Melbourne",
    "country": "Australia",
    "city": "Melbourne",
    "ranking": 14,
    "tuitionFee": "AUD $48,000 / yr",
    "acceptanceRate": 70,
    "description": "Australia premier university with world-class medical science, environmental systems, and international business school.",
    "logoUrl": "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=300&auto=format&fit=crop&q=80",
    "website": "https://unimelb.edu.au",
    "programs": [
      {
        "id": "prog_14",
        "name": "Bachelor of Science (Data Science)",
        "degree": "B.Sc.",
        "department": "Faculty of Science",
        "deadline": "Nov 30, 2026",
        "tuitionPerYear": "AUD $48,000",
        "requirements": [
          "ATAR 95+",
          "IELTS 7.0+"
        ]
      }
    ]
  },
  {
    "id": "uni_14",
    "name": "Tsinghua University",
    "country": "China",
    "city": "Beijing",
    "ranking": 12,
    "tuitionFee": "RMB 30,000 / yr",
    "acceptanceRate": 2,
    "description": "China top engineering & computer science university, world-renowned for Yaoclass CS program and quantum information.",
    "logoUrl": "https://images.unsplash.com/photo-1508873696983-2df515122519?w=300&auto=format&fit=crop&q=80",
    "website": "https://tsinghua.edu.cn",
    "programs": [
      {
        "id": "prog_15",
        "name": "Global Computer Science (Yao Class)",
        "degree": "B.S.",
        "department": "Institute for Interdisciplinary Information Sciences",
        "deadline": "Dec 30, 2026",
        "tuitionPerYear": "RMB 30,000",
        "requirements": [
          "IOI Medalist / HSK 6"
        ]
      }
    ]
  },
  {
    "id": "uni_15",
    "name": "Yale University",
    "country": "United States",
    "city": "New Haven, CT",
    "ranking": 9,
    "tuitionFee": "$64,700 / yr",
    "acceptanceRate": 4.4,
    "description": "Ivy League university renowned for humanities, political science, cognitive science, and interdisciplinary research.",
    "logoUrl": "https://images.unsplash.com/photo-1562774053-701939374585?w=300&auto=format&fit=crop&q=80",
    "website": "https://yale.edu",
    "programs": [
      {
        "id": "prog_16",
        "name": "Cognitive Science & AI",
        "degree": "B.S.",
        "department": "Yale College",
        "deadline": "Jan 02, 2027",
        "tuitionPerYear": "$64,700",
        "requirements": [
          "SAT 1530+",
          "Research Essay"
        ]
      }
    ]
  },
  {
    "id": "uni_16",
    "name": "Columbia University",
    "country": "United States",
    "city": "New York, NY",
    "ranking": 13,
    "tuitionFee": "$65,524 / yr",
    "acceptanceRate": 3.9,
    "description": "Ivy League in New York City specializing in financial engineering, journalism, neuroscience, and data science.",
    "logoUrl": "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=300&auto=format&fit=crop&q=80",
    "website": "https://columbia.edu",
    "programs": [
      {
        "id": "prog_17",
        "name": "Financial Engineering & Operations",
        "degree": "B.S. / M.S.",
        "department": "Columbia Engineering",
        "deadline": "Jan 01, 2027",
        "tuitionPerYear": "$65,524",
        "requirements": [
          "SAT 1540+",
          "AP Calculus BC"
        ]
      }
    ]
  },
  {
    "id": "uni_17",
    "name": "Princeton University",
    "country": "United States",
    "city": "Princeton, NJ",
    "ranking": 7,
    "tuitionFee": "$59,710 / yr",
    "acceptanceRate": 4,
    "description": "Prestigious research institution famed for theoretical physics, mathematics, operations research, and senior thesis.",
    "logoUrl": "https://images.unsplash.com/photo-1607237138185-eedd9c632b0b?w=300&auto=format&fit=crop&q=80",
    "website": "https://princeton.edu",
    "programs": [
      {
        "id": "prog_18",
        "name": "Operations Research & Financial Eng",
        "degree": "B.S.E.",
        "department": "ORFE Dept",
        "deadline": "Jan 01, 2027",
        "tuitionPerYear": "$59,710",
        "requirements": [
          "SAT 1560+",
          "Math Competitions"
        ]
      }
    ]
  },
  {
    "id": "uni_18",
    "name": "University of California, Los Angeles (UCLA)",
    "country": "United States",
    "city": "Los Angeles, CA",
    "ranking": 15,
    "tuitionFee": "$44,830 / yr",
    "acceptanceRate": 8.8,
    "description": "Top public university in Southern California excelling in computer science, film, bioengineering, and medicine.",
    "logoUrl": "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=300&auto=format&fit=crop&q=80",
    "website": "https://ucla.edu",
    "programs": [
      {
        "id": "prog_19",
        "name": "Bioengineering & Computer Medicine",
        "degree": "B.S.",
        "department": "Samueli School of Engineering",
        "deadline": "Nov 30, 2026",
        "tuitionPerYear": "$44,830",
        "requirements": [
          "GPA 4.0",
          "BioResearch Project"
        ]
      }
    ]
  },
  {
    "id": "uni_19",
    "name": "Peking University",
    "country": "China",
    "city": "Beijing",
    "ranking": 16,
    "tuitionFee": "RMB 32,000 / yr",
    "acceptanceRate": 1.8,
    "description": "China top comprehensive university renowned for mathematics, chemistry, physics, and humanities.",
    "logoUrl": "https://images.unsplash.com/photo-1508873696983-2df515122519?w=300&auto=format&fit=crop&q=80",
    "website": "https://pku.edu.cn",
    "programs": [
      {
        "id": "prog_20",
        "name": "School of Mathematical Sciences",
        "degree": "B.S.",
        "department": "SMS Peking",
        "deadline": "Dec 15, 2026",
        "tuitionPerYear": "RMB 32,000",
        "requirements": [
          "CMO Gold Medal / International Applicant"
        ]
      }
    ]
  },
  {
    "id": "uni_20",
    "name": "University of Sydney",
    "country": "Australia",
    "city": "Sydney",
    "ranking": 19,
    "tuitionFee": "AUD $46,500 / yr",
    "acceptanceRate": 65,
    "description": "Australia oldest university, leading global research in health sciences, law, and renewable energy technology.",
    "logoUrl": "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=300&auto=format&fit=crop&q=80",
    "website": "https://sydney.edu.au",
    "programs": [
      {
        "id": "prog_21",
        "name": "Software Engineering (Honours)",
        "degree": "B.E.",
        "department": "School of CS",
        "deadline": "Nov 15, 2026",
        "tuitionPerYear": "AUD $46,500",
        "requirements": [
          "ATAR 92+",
          "IELTS 7.0"
        ]
      }
    ]
  }
];

export const MOCK_PROFESSORS: ProfessorListing[] = [
  {
    "id": "prof_1",
    "name": "Dr. Jane Smith",
    "title": "Full Professor & Lab Director",
    "university": "MIT",
    "department": "EECS & CSAIL",
    "avatarUrl": "https://images.unsplash.com/photo-1534528741775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Autonomous Robotics",
      "Graph Neural Nets",
      "Data Science"
    ],
    "publicationsCount": 45,
    "activeOpeningsCount": 1,
    "bio": "Leading researcher in Autonomous Robotics & Graph Neural Nets at MIT EECS & CSAIL. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drjanesmith@scholarby.edu",
    "labName": "Jane Smith Autonomous Systems Lab",
    "recentPaper": {
      "title": "Next-Generation Autonomous Robotics & Graph Neural Nets: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of EECS & CSAIL & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1000"
    }
  },
  {
    "id": "prof_2",
    "name": "Prof. David Chen",
    "title": "Full Professor & Lab Director",
    "university": "Stanford",
    "department": "Computer Science",
    "avatarUrl": "https://images.unsplash.com/photo-1534528742775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Quantum Computing",
      "Algorithms",
      "Data Science"
    ],
    "publicationsCount": 53,
    "activeOpeningsCount": 2,
    "bio": "Leading researcher in Quantum Computing & Algorithms at Stanford Computer Science. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profdavidchen@scholarby.edu",
    "labName": "Stanford Quantum Information Group",
    "recentPaper": {
      "title": "Next-Generation Quantum Computing & Algorithms: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Computer Science & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1001"
    }
  },
  {
    "id": "prof_3",
    "name": "Dr. Sarah Wilson",
    "title": "Full Professor & Lab Director",
    "university": "Harvard",
    "department": "Bioinformatics",
    "avatarUrl": "https://images.unsplash.com/photo-1534528743775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Computational Genomics",
      "CRISPR AI",
      "Data Science"
    ],
    "publicationsCount": 61,
    "activeOpeningsCount": 3,
    "bio": "Leading researcher in Computational Genomics & CRISPR AI at Harvard Bioinformatics. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drsarahwilson@scholarby.edu",
    "labName": "Harvard Genomic Intelligence Lab",
    "recentPaper": {
      "title": "Next-Generation Computational Genomics & CRISPR AI: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Bioinformatics & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1002"
    }
  },
  {
    "id": "prof_4",
    "name": "Prof. Michael Vance",
    "title": "Full Professor & Lab Director",
    "university": "ETH Zurich",
    "department": "Robotics & Control",
    "avatarUrl": "https://images.unsplash.com/photo-1534528744775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Legged Robot Control",
      "Deep RL",
      "Data Science"
    ],
    "publicationsCount": 69,
    "activeOpeningsCount": 1,
    "bio": "Leading researcher in Legged Robot Control & Deep RL at ETH Zurich Robotics & Control. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profmichaelvance@scholarby.edu",
    "labName": "ETH Robotic Systems Lab",
    "recentPaper": {
      "title": "Next-Generation Legged Robot Control & Deep RL: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Robotics & Control & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1003"
    }
  },
  {
    "id": "prof_5",
    "name": "Dr. Akira Tanaka",
    "title": "Full Professor & Lab Director",
    "university": "UTokyo",
    "department": "Information Science",
    "avatarUrl": "https://images.unsplash.com/photo-1534528745775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Neuromorphic Hardware",
      "Edge AI",
      "Data Science"
    ],
    "publicationsCount": 77,
    "activeOpeningsCount": 2,
    "bio": "Leading researcher in Neuromorphic Hardware & Edge AI at UTokyo Information Science. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drakiratanaka@scholarby.edu",
    "labName": "UTokyo Brain-Inspired Computing Lab",
    "recentPaper": {
      "title": "Next-Generation Neuromorphic Hardware & Edge AI: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Information Science & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1004"
    }
  },
  {
    "id": "prof_6",
    "name": "Prof. Elena Rostova",
    "title": "Full Professor & Lab Director",
    "university": "Oxford",
    "department": "Mathematics",
    "avatarUrl": "https://images.unsplash.com/photo-1534528746775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Topological Data Analysis",
      "Algebraic Geometry",
      "Data Science"
    ],
    "publicationsCount": 85,
    "activeOpeningsCount": 3,
    "bio": "Leading researcher in Topological Data Analysis & Algebraic Geometry at Oxford Mathematics. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profelenarostova@scholarby.edu",
    "labName": "Oxford Centre for Mathematical Modeling",
    "recentPaper": {
      "title": "Next-Generation Topological Data Analysis & Algebraic Geometry: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Mathematics & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1005"
    }
  },
  {
    "id": "prof_7",
    "name": "Dr. Marcus Thorne",
    "title": "Full Professor & Lab Director",
    "university": "Cambridge",
    "department": "Computer Lab",
    "avatarUrl": "https://images.unsplash.com/photo-1534528747775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Privacy-Preserving Federated Learning",
      "Artificial Intelligence",
      "Data Science"
    ],
    "publicationsCount": 93,
    "activeOpeningsCount": 1,
    "bio": "Leading researcher in Privacy-Preserving Federated Learning at Cambridge Computer Lab. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drmarcusthorne@scholarby.edu",
    "labName": "Cambridge Secure Systems Group",
    "recentPaper": {
      "title": "Next-Generation Privacy-Preserving Federated Learning: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Computer Lab & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1006"
    }
  },
  {
    "id": "prof_8",
    "name": "Prof. Wei Zhang",
    "title": "Full Professor & Lab Director",
    "university": "NUS",
    "department": "School of Computing",
    "avatarUrl": "https://images.unsplash.com/photo-1534528748775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "AI for Molecular Discovery",
      "Drug Design",
      "Data Science"
    ],
    "publicationsCount": 101,
    "activeOpeningsCount": 2,
    "bio": "Leading researcher in AI for Molecular Discovery & Drug Design at NUS School of Computing. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profweizhang@scholarby.edu",
    "labName": "NUS AI in Medicine Lab",
    "recentPaper": {
      "title": "Next-Generation AI for Molecular Discovery & Drug Design: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of School of Computing & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1007"
    }
  },
  {
    "id": "prof_9",
    "name": "Dr. Priya Sharma",
    "title": "Full Professor & Lab Director",
    "university": "Imperial",
    "department": "Bioengineering",
    "avatarUrl": "https://images.unsplash.com/photo-1534528749775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Neural Prosthetics",
      "BCI Systems",
      "Data Science"
    ],
    "publicationsCount": 109,
    "activeOpeningsCount": 3,
    "bio": "Leading researcher in Neural Prosthetics & BCI Systems at Imperial Bioengineering. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drpriyasharma@scholarby.edu",
    "labName": "Imperial BCI & Neurotech Lab",
    "recentPaper": {
      "title": "Next-Generation Neural Prosthetics & BCI Systems: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Bioengineering & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1008"
    }
  },
  {
    "id": "prof_10",
    "name": "Prof. Hans Müller",
    "title": "Full Professor & Lab Director",
    "university": "ETH Zurich",
    "department": "Mechanical Eng",
    "avatarUrl": "https://images.unsplash.com/photo-1534528750775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Micro-Drones",
      "Autonomous Swarms",
      "Data Science"
    ],
    "publicationsCount": 117,
    "activeOpeningsCount": 1,
    "bio": "Leading researcher in Micro-Drones & Autonomous Swarms at ETH Zurich Mechanical Eng. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profhansmller@scholarby.edu",
    "labName": "ETH Autonomous Flight Lab",
    "recentPaper": {
      "title": "Next-Generation Micro-Drones & Autonomous Swarms: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Mechanical Eng & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1009"
    }
  },
  {
    "id": "prof_11",
    "name": "Dr. Kevin Lin",
    "title": "Full Professor & Lab Director",
    "university": "UC Berkeley",
    "department": "BAIR / EECS",
    "avatarUrl": "https://images.unsplash.com/photo-1534528751775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Multimodal LLMs",
      "Embodied AI",
      "Data Science"
    ],
    "publicationsCount": 125,
    "activeOpeningsCount": 2,
    "bio": "Leading researcher in Multimodal LLMs & Embodied AI at UC Berkeley BAIR / EECS. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drkevinlin@scholarby.edu",
    "labName": "Berkeley Artificial Intelligence Research",
    "recentPaper": {
      "title": "Next-Generation Multimodal LLMs & Embodied AI: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of BAIR / EECS & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1010"
    }
  },
  {
    "id": "prof_12",
    "name": "Prof. Rachel Adams",
    "title": "Full Professor & Lab Director",
    "university": "U Toronto",
    "department": "Vector Institute",
    "avatarUrl": "https://images.unsplash.com/photo-1534528752775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Deep Learning",
      "Vision Transformers",
      "Data Science"
    ],
    "publicationsCount": 133,
    "activeOpeningsCount": 3,
    "bio": "Leading researcher in Deep Learning & Vision Transformers at U Toronto Vector Institute. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profracheladams@scholarby.edu",
    "labName": "Toronto Deep Learning Lab",
    "recentPaper": {
      "title": "Next-Generation Deep Learning & Vision Transformers: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Vector Institute & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1011"
    }
  },
  {
    "id": "prof_13",
    "name": "Dr. Min-Jae Park",
    "title": "Full Professor & Lab Director",
    "university": "KAIST",
    "department": "School of Computing",
    "avatarUrl": "https://images.unsplash.com/photo-1534528753775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Semiconductor AI Accelerators",
      "Memory",
      "Data Science"
    ],
    "publicationsCount": 141,
    "activeOpeningsCount": 1,
    "bio": "Leading researcher in Semiconductor AI Accelerators & Memory at KAIST School of Computing. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drminjaepark@scholarby.edu",
    "labName": "KAIST AI Hardware Architecture Lab",
    "recentPaper": {
      "title": "Next-Generation Semiconductor AI Accelerators & Memory: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of School of Computing & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1012"
    }
  },
  {
    "id": "prof_14",
    "name": "Prof. Chloe Dubois",
    "title": "Full Professor & Lab Director",
    "university": "Yale",
    "department": "Cognitive Science",
    "avatarUrl": "https://images.unsplash.com/photo-1534528754775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Human-Robot Interaction",
      "Social AI",
      "Data Science"
    ],
    "publicationsCount": 149,
    "activeOpeningsCount": 2,
    "bio": "Leading researcher in Human-Robot Interaction & Social AI at Yale Cognitive Science. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profchloedubois@scholarby.edu",
    "labName": "Yale Cognitive AI Lab",
    "recentPaper": {
      "title": "Next-Generation Human-Robot Interaction & Social AI: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Cognitive Science & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1013"
    }
  },
  {
    "id": "prof_15",
    "name": "Dr. Liam O'Connor",
    "title": "Full Professor & Lab Director",
    "university": "U Melbourne",
    "department": "School of Science",
    "avatarUrl": "https://images.unsplash.com/photo-1534528755775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Climate Modeling",
      "Planetary AI",
      "Data Science"
    ],
    "publicationsCount": 157,
    "activeOpeningsCount": 3,
    "bio": "Leading researcher in Climate Modeling & Planetary AI at U Melbourne School of Science. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drliamoconnor@scholarby.edu",
    "labName": "Melbourne Environmental Data Lab",
    "recentPaper": {
      "title": "Next-Generation Climate Modeling & Planetary AI: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of School of Science & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1014"
    }
  },
  {
    "id": "prof_16",
    "name": "Prof. Andrew Ng-Style",
    "title": "Full Professor & Lab Director",
    "university": "Stanford",
    "department": "AI Lab",
    "avatarUrl": "https://images.unsplash.com/photo-1534528756775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Machine Learning Systems",
      "EdTech AI",
      "Data Science"
    ],
    "publicationsCount": 165,
    "activeOpeningsCount": 1,
    "bio": "Leading researcher in Machine Learning Systems & EdTech AI at Stanford AI Lab. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profandrewngstyle@scholarby.edu",
    "labName": "Stanford AI Education Group",
    "recentPaper": {
      "title": "Next-Generation Machine Learning Systems & EdTech AI: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of AI Lab & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1015"
    }
  },
  {
    "id": "prof_17",
    "name": "Dr. Fatima Al-Hassan",
    "title": "Full Professor & Lab Director",
    "university": "Columbia",
    "department": "Financial Eng",
    "avatarUrl": "https://images.unsplash.com/photo-1534528757775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "High-Frequency Quantitative AI",
      "Artificial Intelligence",
      "Data Science"
    ],
    "publicationsCount": 173,
    "activeOpeningsCount": 2,
    "bio": "Leading researcher in High-Frequency Quantitative AI at Columbia Financial Eng. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drfatimaalhassan@scholarby.edu",
    "labName": "Columbia Computational Finance Lab",
    "recentPaper": {
      "title": "Next-Generation High-Frequency Quantitative AI: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Financial Eng & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1016"
    }
  },
  {
    "id": "prof_18",
    "name": "Prof. Robert Taylor",
    "title": "Full Professor & Lab Director",
    "university": "Princeton",
    "department": "ORFE Dept",
    "avatarUrl": "https://images.unsplash.com/photo-1534528758775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Stochastic Optimization",
      "Convex Analysis",
      "Data Science"
    ],
    "publicationsCount": 181,
    "activeOpeningsCount": 3,
    "bio": "Leading researcher in Stochastic Optimization & Convex Analysis at Princeton ORFE Dept. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profroberttaylor@scholarby.edu",
    "labName": "Princeton Mathematical Optimization Lab",
    "recentPaper": {
      "title": "Next-Generation Stochastic Optimization & Convex Analysis: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of ORFE Dept & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1017"
    }
  },
  {
    "id": "prof_19",
    "name": "Dr. Sakura Takahashi",
    "title": "Full Professor & Lab Director",
    "university": "UTokyo",
    "department": "Physics Dept",
    "avatarUrl": "https://images.unsplash.com/photo-1534528759775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Subatomic Particle Simulation AI",
      "Artificial Intelligence",
      "Data Science"
    ],
    "publicationsCount": 189,
    "activeOpeningsCount": 1,
    "bio": "Leading researcher in Subatomic Particle Simulation AI at UTokyo Physics Dept. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "drsakuratakahashi@scholarby.edu",
    "labName": "UTokyo High-Energy Physics Group",
    "recentPaper": {
      "title": "Next-Generation Subatomic Particle Simulation AI: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of Physics Dept & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1018"
    }
  },
  {
    "id": "prof_20",
    "name": "Prof. Jonathan Wang",
    "title": "Full Professor & Lab Director",
    "university": "Tsinghua",
    "department": "IIIS Yao Class",
    "avatarUrl": "https://images.unsplash.com/photo-1534528760775?w=400&auto=format&fit=crop&q=80",
    "researchFocus": [
      "Theoretical CS",
      "Cryptography",
      "Data Science"
    ],
    "publicationsCount": 197,
    "activeOpeningsCount": 2,
    "bio": "Leading researcher in Theoretical CS & Cryptography at Tsinghua IIIS Yao Class. Currently accepting passionate undergraduate & high school Research Assistants (RAs).",
    "isVerified": true,
    "contactEmail": "profjonathanwang@scholarby.edu",
    "labName": "Tsinghua Quantum & Crypto Institute",
    "recentPaper": {
      "title": "Next-Generation Theoretical CS & Cryptography: Scalable Architectures & Empirical Benchmarks",
      "journal": "Journal of IIIS Yao Class & IEEE Transactions",
      "doi": "10.1109/SCHOLARBY.2026.1019"
    }
  }
];

export const MOCK_TUTORS: TutorListing[] = [
  {
    "id": "tutor_1",
    "name": "Dr. Elizabeth Vance",
    "avatarUrl": "https://images.unsplash.com/photo-1500000000000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "SAT Math",
      "AP Calculus BC",
      "Competitive Math"
    ],
    "education": "MIT PhD Alum",
    "hourlyRate": "$60/hr",
    "rating": 4.98,
    "reviewsCount": 35,
    "bio": "Expert educator specializing in SAT Math, AP Calculus BC, Competitive Math. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "drelizabethvance@scholarby.edu"
  },
  {
    "id": "tutor_2",
    "name": "James Robinson",
    "avatarUrl": "https://images.unsplash.com/photo-1500000050000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "Python",
      "C++ Algorithms",
      "USACO Prep"
    ],
    "education": "Stanford CS Senior",
    "hourlyRate": "$55/hr",
    "rating": 4.95,
    "reviewsCount": 42,
    "bio": "Expert educator specializing in Python, C++ Algorithms, USACO Prep. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "jamesrobinson@scholarby.edu"
  },
  {
    "id": "tutor_3",
    "name": "Sophie Laurent",
    "avatarUrl": "https://images.unsplash.com/photo-1500000100000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "IELTS",
      "TOEFL",
      "College Essay Writing"
    ],
    "education": "Oxford Literature MA",
    "hourlyRate": "$50/hr",
    "rating": 4.92,
    "reviewsCount": 49,
    "bio": "Expert educator specializing in IELTS, TOEFL, College Essay Writing. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "sophielaurent@scholarby.edu"
  },
  {
    "id": "tutor_4",
    "name": "Rohan Mehta",
    "avatarUrl": "https://images.unsplash.com/photo-1500000150000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "JEE Physics",
      "AP Physics C",
      "Quantum Fundamentals"
    ],
    "education": "IIT Bombay & Harvard MS",
    "hourlyRate": "$50/hr",
    "rating": 4.96,
    "reviewsCount": 56,
    "bio": "Expert educator specializing in JEE Physics, AP Physics C, Quantum Fundamentals. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "rohanmehta@scholarby.edu"
  },
  {
    "id": "tutor_5",
    "name": "Dr. Chen Wei",
    "avatarUrl": "https://images.unsplash.com/photo-1500000200000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "IMO Math",
      "Putnam Prep",
      "Advanced Algebra"
    ],
    "education": "Tsinghua Math Postdoc",
    "hourlyRate": "$65/hr",
    "rating": 5,
    "reviewsCount": 63,
    "bio": "Expert educator specializing in IMO Math, Putnam Prep, Advanced Algebra. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "drchenwei@scholarby.edu"
  },
  {
    "id": "tutor_6",
    "name": "Emily Watson",
    "avatarUrl": "https://images.unsplash.com/photo-1500000250000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "A-Level Chemistry",
      "IB Chemistry HL"
    ],
    "education": "Cambridge Tripos Honors",
    "hourlyRate": "$48/hr",
    "rating": 4.9,
    "reviewsCount": 70,
    "bio": "Expert educator specializing in A-Level Chemistry, IB Chemistry HL. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "emilywatson@scholarby.edu"
  },
  {
    "id": "tutor_7",
    "name": "Carlos Mendez",
    "avatarUrl": "https://images.unsplash.com/photo-1500000300000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "Data Structures",
      "Web Development",
      "React/Next.js"
    ],
    "education": "UC Berkeley EECS",
    "hourlyRate": "$45/hr",
    "rating": 4.88,
    "reviewsCount": 77,
    "bio": "Expert educator specializing in Data Structures, Web Development, React/Next.js. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "carlosmendez@scholarby.edu"
  },
  {
    "id": "tutor_8",
    "name": "Amina Kaba",
    "avatarUrl": "https://images.unsplash.com/photo-1500000350000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "AP Psychology",
      "SAT Verbal",
      "ACT Science"
    ],
    "education": "Yale Cognitive Science",
    "hourlyRate": "$42/hr",
    "rating": 4.91,
    "reviewsCount": 84,
    "bio": "Expert educator specializing in AP Psychology, SAT Verbal, ACT Science. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "aminakaba@scholarby.edu"
  },
  {
    "id": "tutor_9",
    "name": "David Park",
    "avatarUrl": "https://images.unsplash.com/photo-1500000400000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "Korean Language",
      "Algorithm Complexity",
      "Java"
    ],
    "education": "KAIST CS Alum",
    "hourlyRate": "$40/hr",
    "rating": 4.85,
    "reviewsCount": 91,
    "bio": "Expert educator specializing in Korean Language, Algorithm Complexity, Java. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "davidpark@scholarby.edu"
  },
  {
    "id": "tutor_10",
    "name": "Hiroshi Sato",
    "avatarUrl": "https://images.unsplash.com/photo-1500000450000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "Physics Olympiad",
      "JLPT N1/N2 Prep"
    ],
    "education": "UTokyo Engineering",
    "hourlyRate": "$45/hr",
    "rating": 4.93,
    "reviewsCount": 98,
    "bio": "Expert educator specializing in Physics Olympiad, JLPT N1/N2 Prep. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "hiroshisato@scholarby.edu"
  },
  {
    "id": "tutor_11",
    "name": "Jessica Miller",
    "avatarUrl": "https://images.unsplash.com/photo-1500000500000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "GMAT Quant",
      "GRE Math",
      "Economics"
    ],
    "education": "Columbia Finance MA",
    "hourlyRate": "$58/hr",
    "rating": 4.97,
    "reviewsCount": 105,
    "bio": "Expert educator specializing in GMAT Quant, GRE Math, Economics. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "jessicamiller@scholarby.edu"
  },
  {
    "id": "tutor_12",
    "name": "Nikhil Gupta",
    "avatarUrl": "https://images.unsplash.com/photo-1500000550000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "Machine Learning",
      "PyTorch",
      "Kaggle Competition"
    ],
    "education": "AI Researcher",
    "hourlyRate": "$60/hr",
    "rating": 4.99,
    "reviewsCount": 112,
    "bio": "Expert educator specializing in Machine Learning, PyTorch, Kaggle Competition. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "nikhilgupta@scholarby.edu"
  },
  {
    "id": "tutor_13",
    "name": "Claire Dubois",
    "avatarUrl": "https://images.unsplash.com/photo-1500000600000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "French Language",
      "DELF B2/C1",
      "IB French"
    ],
    "education": "Sorbonne Graduate",
    "hourlyRate": "$38/hr",
    "rating": 4.87,
    "reviewsCount": 119,
    "bio": "Expert educator specializing in French Language, DELF B2/C1, IB French. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "clairedubois@scholarby.edu"
  },
  {
    "id": "tutor_14",
    "name": "Oliver Taylor",
    "avatarUrl": "https://images.unsplash.com/photo-1500000650000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "A-Level Further Math",
      "STEP Math Exam"
    ],
    "education": "Imperial College London",
    "hourlyRate": "$52/hr",
    "rating": 4.94,
    "reviewsCount": 126,
    "bio": "Expert educator specializing in A-Level Further Math, STEP Math Exam. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "olivertaylor@scholarby.edu"
  },
  {
    "id": "tutor_15",
    "name": "Ananya Roy",
    "avatarUrl": "https://images.unsplash.com/photo-1500000700000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "MCAT Biology",
      "AP Biology"
    ],
    "education": "Medical Student at Johns Hopkins",
    "hourlyRate": "$55/hr",
    "rating": 4.96,
    "reviewsCount": 133,
    "bio": "Expert educator specializing in MCAT Biology, AP Biology. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "ananyaroy@scholarby.edu"
  },
  {
    "id": "tutor_16",
    "name": "Siddharth Kumar",
    "avatarUrl": "https://images.unsplash.com/photo-1500000750000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "Physics Olympiad (IPhO)",
      "USAPhO"
    ],
    "education": "Olympiad Gold Winner",
    "hourlyRate": "$58/hr",
    "rating": 4.98,
    "reviewsCount": 140,
    "bio": "Expert educator specializing in Physics Olympiad (IPhO), USAPhO. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "siddharthkumar@scholarby.edu"
  },
  {
    "id": "tutor_17",
    "name": "Hannah Schmidt",
    "avatarUrl": "https://images.unsplash.com/photo-1500000800000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "German Language",
      "Goethe C1",
      "Matura Math"
    ],
    "education": "ETH Zurich MSc",
    "hourlyRate": "$42/hr",
    "rating": 4.89,
    "reviewsCount": 147,
    "bio": "Expert educator specializing in German Language, Goethe C1, Matura Math. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "hannahschmidt@scholarby.edu"
  },
  {
    "id": "tutor_18",
    "name": "Ben Affleck-Style",
    "avatarUrl": "https://images.unsplash.com/photo-1500000850000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "Ivy League Essay Editing",
      "Personal Statements"
    ],
    "education": "Hollywood Screenwriter Coach",
    "hourlyRate": "$70/hr",
    "rating": 4.99,
    "reviewsCount": 154,
    "bio": "Expert educator specializing in Ivy League Essay Editing, Personal Statements. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "benaffleckstyle@scholarby.edu"
  },
  {
    "id": "tutor_19",
    "name": "Grace Hopper Jr.",
    "avatarUrl": "https://images.unsplash.com/photo-1500000900000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "System Design",
      "LeetCode Hard Prep"
    ],
    "education": "Senior Software Engineer",
    "hourlyRate": "$65/hr",
    "rating": 4.97,
    "reviewsCount": 161,
    "bio": "Expert educator specializing in System Design, LeetCode Hard Prep. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "gracehopperjr@scholarby.edu"
  },
  {
    "id": "tutor_20",
    "name": "Lucas Silva",
    "avatarUrl": "https://images.unsplash.com/photo-1500000950000?w=400&auto=format&fit=crop&q=80",
    "subjects": [
      "SAT Digital Math",
      "General Chemistry"
    ],
    "education": "University of Toronto",
    "hourlyRate": "$35/hr",
    "rating": 4.86,
    "reviewsCount": 168,
    "bio": "Expert educator specializing in SAT Digital Math, General Chemistry. Over 5+ years helping students achieve top scores and Ivy League admissions.",
    "isVerified": true,
    "contactEmail": "lucassilva@scholarby.edu"
  }
];

export const MOCK_CONSULTANTS: ConsultantListing[] = [
  {
    "id": "consultant_1",
    "name": "Victoria Sterling",
    "avatarUrl": "https://images.unsplash.com/photo-1530000000000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Ivy League Admissions",
      "US Top 20",
      "Scholarship Strategy"
    ],
    "targetCountries": [
      "United States",
      "Singapore"
    ],
    "successRate": "98.5%",
    "experienceYears": 12,
    "hourlyRate": "$150/hr",
    "rating": 4.99,
    "reviewsCount": 40,
    "bio": "Premier admissions strategist with 12 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "victoriasterling@scholarby.edu"
  },
  {
    "id": "consultant_2",
    "name": "Dr. Arthur Pendelton",
    "avatarUrl": "https://images.unsplash.com/photo-1530000040000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Oxbridge Admissions",
      "UK UCAS",
      "Imperial & LSE Specialist"
    ],
    "targetCountries": [
      "United Kingdom",
      "Switzerland"
    ],
    "successRate": "96.2%",
    "experienceYears": 15,
    "hourlyRate": "$160/hr",
    "rating": 4.97,
    "reviewsCount": 46,
    "bio": "Premier admissions strategist with 15 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "drarthurpendelton@scholarby.edu"
  },
  {
    "id": "consultant_3",
    "name": "Siddharth Kapoor",
    "avatarUrl": "https://images.unsplash.com/photo-1530000080000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "STEM & CS Graduate Admissions",
      "MIT/Stanford Research Portfolio"
    ],
    "targetCountries": [
      "United States",
      "Canada"
    ],
    "successRate": "97.8%",
    "experienceYears": 10,
    "hourlyRate": "$140/hr",
    "rating": 4.96,
    "reviewsCount": 52,
    "bio": "Premier admissions strategist with 10 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "siddharthkapoor@scholarby.edu"
  },
  {
    "id": "consultant_4",
    "name": "Elena Rostova-Advisors",
    "avatarUrl": "https://images.unsplash.com/photo-1530000120000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "European Universities",
      "ETH Zurich & EPFL",
      "Tuition Free Unis"
    ],
    "targetCountries": [
      "Switzerland",
      "Germany"
    ],
    "successRate": "95.0%",
    "experienceYears": 8,
    "hourlyRate": "$120/hr",
    "rating": 4.92,
    "reviewsCount": 58,
    "bio": "Premier admissions strategist with 8 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "elenarostovaadvisors@scholarby.edu"
  },
  {
    "id": "consultant_5",
    "name": "Marcus Vance",
    "avatarUrl": "https://images.unsplash.com/photo-1530000160000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Medical School (BS/MD)",
      "Pre-Med Strategy",
      "Research Publications"
    ],
    "targetCountries": [
      "United States"
    ],
    "successRate": "99.0%",
    "experienceYears": 14,
    "hourlyRate": "$175/hr",
    "rating": 5,
    "reviewsCount": 64,
    "bio": "Premier admissions strategist with 14 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "marcusvance@scholarby.edu"
  },
  {
    "id": "consultant_6",
    "name": "Mei-Ling Zhou",
    "avatarUrl": "https://images.unsplash.com/photo-1530000200000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Asian Top Unis (NUS, NTU, Tsinghua, HKU)",
      "Global Asian Fellowships"
    ],
    "targetCountries": [
      "Singapore",
      "China",
      "Japan"
    ],
    "successRate": "98.0%",
    "experienceYears": 9,
    "hourlyRate": "$130/hr",
    "rating": 4.94,
    "reviewsCount": 70,
    "bio": "Premier admissions strategist with 9 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "meilingzhou@scholarby.edu"
  },
  {
    "id": "consultant_7",
    "name": "Jonathan Blair",
    "avatarUrl": "https://images.unsplash.com/photo-1530000240000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "MBA & M.Fin Admissions",
      "Harvard Business School / Wharton Specialist"
    ],
    "targetCountries": [
      "United States",
      "United Kingdom"
    ],
    "successRate": "97.5%",
    "experienceYears": 11,
    "hourlyRate": "$180/hr",
    "rating": 4.98,
    "reviewsCount": 76,
    "bio": "Premier admissions strategist with 11 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "jonathanblair@scholarby.edu"
  },
  {
    "id": "consultant_8",
    "name": "Sarah Jenkins",
    "avatarUrl": "https://images.unsplash.com/photo-1530000280000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Art, Architecture & Design Portfolios",
      "RISD & Parsons"
    ],
    "targetCountries": [
      "United States",
      "United Kingdom"
    ],
    "successRate": "94.5%",
    "experienceYears": 7,
    "hourlyRate": "$110/hr",
    "rating": 4.89,
    "reviewsCount": 82,
    "bio": "Premier admissions strategist with 7 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "sarahjenkins@scholarby.edu"
  },
  {
    "id": "consultant_9",
    "name": "David Goldstein",
    "avatarUrl": "https://images.unsplash.com/photo-1530000320000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "High School Extracurricular Building",
      "ISEF & Olympiad Strategy"
    ],
    "targetCountries": [
      "United States",
      "International"
    ],
    "successRate": "98.8%",
    "experienceYears": 13,
    "hourlyRate": "$155/hr",
    "rating": 4.97,
    "reviewsCount": 88,
    "bio": "Premier admissions strategist with 13 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "davidgoldstein@scholarby.edu"
  },
  {
    "id": "consultant_10",
    "name": "Priya Nair",
    "avatarUrl": "https://images.unsplash.com/photo-1530000360000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Full Financial Aid & Need-Blind Ivy League Scholarships"
    ],
    "targetCountries": [
      "United States",
      "Canada"
    ],
    "successRate": "99.2%",
    "experienceYears": 10,
    "hourlyRate": "$125/hr",
    "rating": 4.96,
    "reviewsCount": 94,
    "bio": "Premier admissions strategist with 10 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "priyanair@scholarby.edu"
  },
  {
    "id": "consultant_11",
    "name": "Alexander Hamilton-Style",
    "avatarUrl": "https://images.unsplash.com/photo-1530000400000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Law School (JD) & Pre-Law Track"
    ],
    "targetCountries": [
      "United States"
    ],
    "successRate": "96.8%",
    "experienceYears": 12,
    "hourlyRate": "$165/hr",
    "rating": 4.95,
    "reviewsCount": 100,
    "bio": "Premier admissions strategist with 12 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "alexanderhamiltonstyle@scholarby.edu"
  },
  {
    "id": "consultant_12",
    "name": "Klaus Weber",
    "avatarUrl": "https://images.unsplash.com/photo-1530000440000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "German Engineering Universities (TU9 & DAAD Scholarships)"
    ],
    "targetCountries": [
      "Germany",
      "Austria"
    ],
    "successRate": "96.0%",
    "experienceYears": 9,
    "hourlyRate": "$115/hr",
    "rating": 4.91,
    "reviewsCount": 106,
    "bio": "Premier admissions strategist with 9 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "klausweber@scholarby.edu"
  },
  {
    "id": "consultant_13",
    "name": "Chloe Martin",
    "avatarUrl": "https://images.unsplash.com/photo-1530000480000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Canadian Top Universities (U Toronto, UBC, Waterloo)"
    ],
    "targetCountries": [
      "Canada"
    ],
    "successRate": "97.0%",
    "experienceYears": 8,
    "hourlyRate": "$120/hr",
    "rating": 4.93,
    "reviewsCount": 112,
    "bio": "Premier admissions strategist with 8 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "chloemartin@scholarby.edu"
  },
  {
    "id": "consultant_14",
    "name": "Taro Yamada",
    "avatarUrl": "https://images.unsplash.com/photo-1530000520000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "MEXT Japan Government Full Ride Scholarships"
    ],
    "targetCountries": [
      "Japan"
    ],
    "successRate": "98.4%",
    "experienceYears": 11,
    "hourlyRate": "$130/hr",
    "rating": 4.95,
    "reviewsCount": 118,
    "bio": "Premier admissions strategist with 11 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "taroyamada@scholarby.edu"
  },
  {
    "id": "consultant_15",
    "name": "Harrison Ford-Advisor",
    "avatarUrl": "https://images.unsplash.com/photo-1530000560000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Liberal Arts Colleges (Williams, Amherst, Swarthmore)"
    ],
    "targetCountries": [
      "United States"
    ],
    "successRate": "96.5%",
    "experienceYears": 10,
    "hourlyRate": "$145/hr",
    "rating": 4.94,
    "reviewsCount": 124,
    "bio": "Premier admissions strategist with 10 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "harrisonfordadvisor@scholarby.edu"
  },
  {
    "id": "consultant_16",
    "name": "Anita Desai",
    "avatarUrl": "https://images.unsplash.com/photo-1530000600000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Undergraduate Research & Patent Filing Strategy"
    ],
    "targetCountries": [
      "United States",
      "Singapore"
    ],
    "successRate": "98.1%",
    "experienceYears": 9,
    "hourlyRate": "$150/hr",
    "rating": 4.97,
    "reviewsCount": 130,
    "bio": "Premier admissions strategist with 9 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "anitadesai@scholarby.edu"
  },
  {
    "id": "consultant_17",
    "name": "Gareth Evans",
    "avatarUrl": "https://images.unsplash.com/photo-1530000640000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Australian Go8 Universities (Melbourne, Sydney, ANU)"
    ],
    "targetCountries": [
      "Australia"
    ],
    "successRate": "95.5%",
    "experienceYears": 7,
    "hourlyRate": "$105/hr",
    "rating": 4.88,
    "reviewsCount": 136,
    "bio": "Premier admissions strategist with 7 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "garethevans@scholarby.edu"
  },
  {
    "id": "consultant_18",
    "name": "Maria Santos",
    "avatarUrl": "https://images.unsplash.com/photo-1530000680000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Biological & Biomedical Sciences PhD Track"
    ],
    "targetCountries": [
      "United States",
      "Switzerland"
    ],
    "successRate": "97.2%",
    "experienceYears": 10,
    "hourlyRate": "$135/hr",
    "rating": 4.93,
    "reviewsCount": 142,
    "bio": "Premier admissions strategist with 10 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "mariasantos@scholarby.edu"
  },
  {
    "id": "consultant_19",
    "name": "Kenji Tanaka",
    "avatarUrl": "https://images.unsplash.com/photo-1530000720000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "AI & Machine Learning Graduate School Placement"
    ],
    "targetCountries": [
      "United States",
      "Japan"
    ],
    "successRate": "99.1%",
    "experienceYears": 11,
    "hourlyRate": "$170/hr",
    "rating": 4.99,
    "reviewsCount": 148,
    "bio": "Premier admissions strategist with 11 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "kenjitanaka@scholarby.edu"
  },
  {
    "id": "consultant_20",
    "name": "Rachel Green",
    "avatarUrl": "https://images.unsplash.com/photo-1530000760000?w=400&auto=format&fit=crop&q=80",
    "specialization": [
      "Ivy League Essay Brainstorming & Editing Specialist"
    ],
    "targetCountries": [
      "United States"
    ],
    "successRate": "98.7%",
    "experienceYears": 12,
    "hourlyRate": "$140/hr",
    "rating": 4.96,
    "reviewsCount": 154,
    "bio": "Premier admissions strategist with 12 years of experience guiding international candidates to top target universities worldwide.",
    "isVerified": true,
    "contactEmail": "rachelgreen@scholarby.edu"
  }
];

export const MOCK_FEED_POSTS: FeedPostItem[] = [
  {
    "id": "post_1",
    "authorName": "Dr. Academic Author #1",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528741898?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #1 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "2h ago",
    "likesCount": 22,
    "commentsCount": 6,
    "isLiked": false
  },
  {
    "id": "post_2",
    "authorName": "Student Scholar #2",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528742021?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #2 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "3h ago",
    "likesCount": 29,
    "commentsCount": 9,
    "isLiked": false
  },
  {
    "id": "post_3",
    "authorName": "Dr. Academic Author #3",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528742144?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #3 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "4h ago",
    "likesCount": 36,
    "commentsCount": 12,
    "isLiked": false
  },
  {
    "id": "post_4",
    "authorName": "Student Scholar #4",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528742267?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #4 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "5h ago",
    "likesCount": 43,
    "commentsCount": 15,
    "isLiked": false
  },
  {
    "id": "post_5",
    "authorName": "Dr. Academic Author #5",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528742390?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #5 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "6h ago",
    "likesCount": 50,
    "commentsCount": 18,
    "isLiked": true
  },
  {
    "id": "post_6",
    "authorName": "Student Scholar #6",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528742513?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #6 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "7h ago",
    "likesCount": 57,
    "commentsCount": 21,
    "isLiked": false
  },
  {
    "id": "post_7",
    "authorName": "Dr. Academic Author #7",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528742636?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #7 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "8h ago",
    "likesCount": 64,
    "commentsCount": 24,
    "isLiked": false
  },
  {
    "id": "post_8",
    "authorName": "Student Scholar #8",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528742759?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #8 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "9h ago",
    "likesCount": 71,
    "commentsCount": 27,
    "isLiked": false
  },
  {
    "id": "post_9",
    "authorName": "Dr. Academic Author #9",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528742882?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #9 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "10h ago",
    "likesCount": 78,
    "commentsCount": 30,
    "isLiked": false
  },
  {
    "id": "post_10",
    "authorName": "Student Scholar #10",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528743005?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #10 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "11h ago",
    "likesCount": 85,
    "commentsCount": 33,
    "isLiked": true
  },
  {
    "id": "post_11",
    "authorName": "Dr. Academic Author #11",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528743128?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #11 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "12h ago",
    "likesCount": 92,
    "commentsCount": 36,
    "isLiked": false
  },
  {
    "id": "post_12",
    "authorName": "Student Scholar #12",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528743251?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": true,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #12 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "1h ago",
    "likesCount": 99,
    "commentsCount": 39,
    "isLiked": false
  },
  {
    "id": "post_13",
    "authorName": "Dr. Academic Author #13",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528743374?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #13 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "2h ago",
    "likesCount": 106,
    "commentsCount": 42,
    "isLiked": false
  },
  {
    "id": "post_14",
    "authorName": "Student Scholar #14",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528743497?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #14 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "3h ago",
    "likesCount": 113,
    "commentsCount": 45,
    "isLiked": false
  },
  {
    "id": "post_15",
    "authorName": "Dr. Academic Author #15",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528743620?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #15 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "4h ago",
    "likesCount": 120,
    "commentsCount": 3,
    "isLiked": true
  },
  {
    "id": "post_16",
    "authorName": "Student Scholar #16",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528743743?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #16 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "5h ago",
    "likesCount": 127,
    "commentsCount": 6,
    "isLiked": false
  },
  {
    "id": "post_17",
    "authorName": "Dr. Academic Author #17",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528743866?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #17 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "6h ago",
    "likesCount": 134,
    "commentsCount": 9,
    "isLiked": false
  },
  {
    "id": "post_18",
    "authorName": "Student Scholar #18",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528743989?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #18 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "7h ago",
    "likesCount": 141,
    "commentsCount": 12,
    "isLiked": false
  },
  {
    "id": "post_19",
    "authorName": "Dr. Academic Author #19",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528744112?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #19 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "8h ago",
    "likesCount": 148,
    "commentsCount": 15,
    "isLiked": false
  },
  {
    "id": "post_20",
    "authorName": "Student Scholar #20",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528744235?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #20 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "9h ago",
    "likesCount": 155,
    "commentsCount": 18,
    "isLiked": true
  },
  {
    "id": "post_21",
    "authorName": "Dr. Academic Author #21",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528744358?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #21 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "10h ago",
    "likesCount": 162,
    "commentsCount": 21,
    "isLiked": false
  },
  {
    "id": "post_22",
    "authorName": "Student Scholar #22",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528744481?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #22 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "11h ago",
    "likesCount": 169,
    "commentsCount": 24,
    "isLiked": false
  },
  {
    "id": "post_23",
    "authorName": "Dr. Academic Author #23",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528744604?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #23 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "12h ago",
    "likesCount": 176,
    "commentsCount": 27,
    "isLiked": false
  },
  {
    "id": "post_24",
    "authorName": "Student Scholar #24",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528744727?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": true,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #24 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "1h ago",
    "likesCount": 183,
    "commentsCount": 30,
    "isLiked": false
  },
  {
    "id": "post_25",
    "authorName": "Dr. Academic Author #25",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528744850?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #25 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "2h ago",
    "likesCount": 190,
    "commentsCount": 33,
    "isLiked": true
  },
  {
    "id": "post_26",
    "authorName": "Student Scholar #26",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528744973?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #26 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "3h ago",
    "likesCount": 197,
    "commentsCount": 36,
    "isLiked": false
  },
  {
    "id": "post_27",
    "authorName": "Dr. Academic Author #27",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528745096?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #27 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "4h ago",
    "likesCount": 204,
    "commentsCount": 39,
    "isLiked": false
  },
  {
    "id": "post_28",
    "authorName": "Student Scholar #28",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528745219?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #28 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "5h ago",
    "likesCount": 211,
    "commentsCount": 42,
    "isLiked": false
  },
  {
    "id": "post_29",
    "authorName": "Dr. Academic Author #29",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528745342?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #29 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "6h ago",
    "likesCount": 218,
    "commentsCount": 45,
    "isLiked": false
  },
  {
    "id": "post_30",
    "authorName": "Student Scholar #30",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528745465?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #30 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "7h ago",
    "likesCount": 225,
    "commentsCount": 3,
    "isLiked": true
  },
  {
    "id": "post_31",
    "authorName": "Dr. Academic Author #31",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528745588?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #31 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "8h ago",
    "likesCount": 232,
    "commentsCount": 6,
    "isLiked": false
  },
  {
    "id": "post_32",
    "authorName": "Student Scholar #32",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528745711?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #32 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "9h ago",
    "likesCount": 239,
    "commentsCount": 9,
    "isLiked": false
  },
  {
    "id": "post_33",
    "authorName": "Dr. Academic Author #33",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528745834?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #33 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "10h ago",
    "likesCount": 246,
    "commentsCount": 12,
    "isLiked": false
  },
  {
    "id": "post_34",
    "authorName": "Student Scholar #34",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528745957?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #34 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "11h ago",
    "likesCount": 253,
    "commentsCount": 15,
    "isLiked": false
  },
  {
    "id": "post_35",
    "authorName": "Dr. Academic Author #35",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528746080?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #35 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "12h ago",
    "likesCount": 260,
    "commentsCount": 18,
    "isLiked": true
  },
  {
    "id": "post_36",
    "authorName": "Student Scholar #36",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528746203?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": true,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #36 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "1h ago",
    "likesCount": 267,
    "commentsCount": 21,
    "isLiked": false
  },
  {
    "id": "post_37",
    "authorName": "Dr. Academic Author #37",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528746326?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #37 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "2h ago",
    "likesCount": 274,
    "commentsCount": 24,
    "isLiked": false
  },
  {
    "id": "post_38",
    "authorName": "Student Scholar #38",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528746449?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #38 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "3h ago",
    "likesCount": 281,
    "commentsCount": 27,
    "isLiked": false
  },
  {
    "id": "post_39",
    "authorName": "Dr. Academic Author #39",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528746572?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #39 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "4h ago",
    "likesCount": 288,
    "commentsCount": 30,
    "isLiked": false
  },
  {
    "id": "post_40",
    "authorName": "Student Scholar #40",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528746695?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #40 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "5h ago",
    "likesCount": 295,
    "commentsCount": 33,
    "isLiked": true
  },
  {
    "id": "post_41",
    "authorName": "Dr. Academic Author #41",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528746818?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #41 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "6h ago",
    "likesCount": 302,
    "commentsCount": 36,
    "isLiked": false
  },
  {
    "id": "post_42",
    "authorName": "Student Scholar #42",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528746941?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #42 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "7h ago",
    "likesCount": 309,
    "commentsCount": 39,
    "isLiked": false
  },
  {
    "id": "post_43",
    "authorName": "Dr. Academic Author #43",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528747064?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #43 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "8h ago",
    "likesCount": 16,
    "commentsCount": 42,
    "isLiked": false
  },
  {
    "id": "post_44",
    "authorName": "Student Scholar #44",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528747187?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #44 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "9h ago",
    "likesCount": 23,
    "commentsCount": 45,
    "isLiked": false
  },
  {
    "id": "post_45",
    "authorName": "Dr. Academic Author #45",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528747310?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #45 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "10h ago",
    "likesCount": 30,
    "commentsCount": 3,
    "isLiked": true
  },
  {
    "id": "post_46",
    "authorName": "Student Scholar #46",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528747433?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #46 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "11h ago",
    "likesCount": 37,
    "commentsCount": 6,
    "isLiked": false
  },
  {
    "id": "post_47",
    "authorName": "Dr. Academic Author #47",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528747556?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #47 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "12h ago",
    "likesCount": 44,
    "commentsCount": 9,
    "isLiked": false
  },
  {
    "id": "post_48",
    "authorName": "Student Scholar #48",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528747679?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": true,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #48 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "1h ago",
    "likesCount": 51,
    "commentsCount": 12,
    "isLiked": false
  },
  {
    "id": "post_49",
    "authorName": "Dr. Academic Author #49",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528747802?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #49 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "2h ago",
    "likesCount": 58,
    "commentsCount": 15,
    "isLiked": false
  },
  {
    "id": "post_50",
    "authorName": "Student Scholar #50",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528747925?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #50 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "3h ago",
    "likesCount": 65,
    "commentsCount": 18,
    "isLiked": true
  },
  {
    "id": "post_51",
    "authorName": "Dr. Academic Author #51",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528748048?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #51 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "4h ago",
    "likesCount": 72,
    "commentsCount": 21,
    "isLiked": false
  },
  {
    "id": "post_52",
    "authorName": "Student Scholar #52",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528748171?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #52 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "5h ago",
    "likesCount": 79,
    "commentsCount": 24,
    "isLiked": false
  },
  {
    "id": "post_53",
    "authorName": "Dr. Academic Author #53",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528748294?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #53 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "6h ago",
    "likesCount": 86,
    "commentsCount": 27,
    "isLiked": false
  },
  {
    "id": "post_54",
    "authorName": "Student Scholar #54",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528748417?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #54 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "7h ago",
    "likesCount": 93,
    "commentsCount": 30,
    "isLiked": false
  },
  {
    "id": "post_55",
    "authorName": "Dr. Academic Author #55",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528748540?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #55 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "8h ago",
    "likesCount": 100,
    "commentsCount": 33,
    "isLiked": true
  },
  {
    "id": "post_56",
    "authorName": "Student Scholar #56",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528748663?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #56 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "9h ago",
    "likesCount": 107,
    "commentsCount": 36,
    "isLiked": false
  },
  {
    "id": "post_57",
    "authorName": "Dr. Academic Author #57",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528748786?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #57 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "10h ago",
    "likesCount": 114,
    "commentsCount": 39,
    "isLiked": false
  },
  {
    "id": "post_58",
    "authorName": "Student Scholar #58",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528748909?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #58 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "11h ago",
    "likesCount": 121,
    "commentsCount": 42,
    "isLiked": false
  },
  {
    "id": "post_59",
    "authorName": "Dr. Academic Author #59",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528749032?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #59 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "12h ago",
    "likesCount": 128,
    "commentsCount": 45,
    "isLiked": false
  },
  {
    "id": "post_60",
    "authorName": "Student Scholar #60",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528749155?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": true,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #60 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "1h ago",
    "likesCount": 135,
    "commentsCount": 3,
    "isLiked": true
  },
  {
    "id": "post_61",
    "authorName": "Dr. Academic Author #61",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528749278?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #61 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "2h ago",
    "likesCount": 142,
    "commentsCount": 6,
    "isLiked": false
  },
  {
    "id": "post_62",
    "authorName": "Student Scholar #62",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528749401?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #62 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "3h ago",
    "likesCount": 149,
    "commentsCount": 9,
    "isLiked": false
  },
  {
    "id": "post_63",
    "authorName": "Dr. Academic Author #63",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528749524?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #63 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "4h ago",
    "likesCount": 156,
    "commentsCount": 12,
    "isLiked": false
  },
  {
    "id": "post_64",
    "authorName": "Student Scholar #64",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528749647?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #64 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "5h ago",
    "likesCount": 163,
    "commentsCount": 15,
    "isLiked": false
  },
  {
    "id": "post_65",
    "authorName": "Dr. Academic Author #65",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528749770?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #65 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "6h ago",
    "likesCount": 170,
    "commentsCount": 18,
    "isLiked": true
  },
  {
    "id": "post_66",
    "authorName": "Student Scholar #66",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528749893?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #66 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "7h ago",
    "likesCount": 177,
    "commentsCount": 21,
    "isLiked": false
  },
  {
    "id": "post_67",
    "authorName": "Dr. Academic Author #67",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528750016?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #67 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "8h ago",
    "likesCount": 184,
    "commentsCount": 24,
    "isLiked": false
  },
  {
    "id": "post_68",
    "authorName": "Student Scholar #68",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528750139?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #68 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "9h ago",
    "likesCount": 191,
    "commentsCount": 27,
    "isLiked": false
  },
  {
    "id": "post_69",
    "authorName": "Dr. Academic Author #69",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528750262?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #69 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "10h ago",
    "likesCount": 198,
    "commentsCount": 30,
    "isLiked": false
  },
  {
    "id": "post_70",
    "authorName": "Student Scholar #70",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528750385?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #70 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "11h ago",
    "likesCount": 205,
    "commentsCount": 33,
    "isLiked": true
  },
  {
    "id": "post_71",
    "authorName": "Dr. Academic Author #71",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528750508?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #71 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "12h ago",
    "likesCount": 212,
    "commentsCount": 36,
    "isLiked": false
  },
  {
    "id": "post_72",
    "authorName": "Student Scholar #72",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528750631?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": true,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #72 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "1h ago",
    "likesCount": 219,
    "commentsCount": 39,
    "isLiked": false
  },
  {
    "id": "post_73",
    "authorName": "Dr. Academic Author #73",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528750754?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #73 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "2h ago",
    "likesCount": 226,
    "commentsCount": 42,
    "isLiked": false
  },
  {
    "id": "post_74",
    "authorName": "Student Scholar #74",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528750877?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #74 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "3h ago",
    "likesCount": 233,
    "commentsCount": 45,
    "isLiked": false
  },
  {
    "id": "post_75",
    "authorName": "Dr. Academic Author #75",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528751000?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #75 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "4h ago",
    "likesCount": 240,
    "commentsCount": 3,
    "isLiked": true
  },
  {
    "id": "post_76",
    "authorName": "Student Scholar #76",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528751123?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #76 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "5h ago",
    "likesCount": 247,
    "commentsCount": 6,
    "isLiked": false
  },
  {
    "id": "post_77",
    "authorName": "Dr. Academic Author #77",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528751246?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #77 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "6h ago",
    "likesCount": 254,
    "commentsCount": 9,
    "isLiked": false
  },
  {
    "id": "post_78",
    "authorName": "Student Scholar #78",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528751369?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #78 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "7h ago",
    "likesCount": 261,
    "commentsCount": 12,
    "isLiked": false
  },
  {
    "id": "post_79",
    "authorName": "Dr. Academic Author #79",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528751492?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #79 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "8h ago",
    "likesCount": 268,
    "commentsCount": 15,
    "isLiked": false
  },
  {
    "id": "post_80",
    "authorName": "Student Scholar #80",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528751615?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #80 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "9h ago",
    "likesCount": 275,
    "commentsCount": 18,
    "isLiked": true
  },
  {
    "id": "post_81",
    "authorName": "Dr. Academic Author #81",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528751738?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #81 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "10h ago",
    "likesCount": 282,
    "commentsCount": 21,
    "isLiked": false
  },
  {
    "id": "post_82",
    "authorName": "Student Scholar #82",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528751861?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #82 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "11h ago",
    "likesCount": 289,
    "commentsCount": 24,
    "isLiked": false
  },
  {
    "id": "post_83",
    "authorName": "Dr. Academic Author #83",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528751984?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #83 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "12h ago",
    "likesCount": 296,
    "commentsCount": 27,
    "isLiked": false
  },
  {
    "id": "post_84",
    "authorName": "Student Scholar #84",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528752107?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": true,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #84 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "1h ago",
    "likesCount": 303,
    "commentsCount": 30,
    "isLiked": false
  },
  {
    "id": "post_85",
    "authorName": "Dr. Academic Author #85",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528752230?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #85 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "2h ago",
    "likesCount": 310,
    "commentsCount": 33,
    "isLiked": true
  },
  {
    "id": "post_86",
    "authorName": "Student Scholar #86",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528752353?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #86 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "3h ago",
    "likesCount": 17,
    "commentsCount": 36,
    "isLiked": false
  },
  {
    "id": "post_87",
    "authorName": "Dr. Academic Author #87",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528752476?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #87 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "4h ago",
    "likesCount": 24,
    "commentsCount": 39,
    "isLiked": false
  },
  {
    "id": "post_88",
    "authorName": "Student Scholar #88",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528752599?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #88 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "5h ago",
    "likesCount": 31,
    "commentsCount": 42,
    "isLiked": false
  },
  {
    "id": "post_89",
    "authorName": "Dr. Academic Author #89",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528752722?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #89 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "6h ago",
    "likesCount": 38,
    "commentsCount": 45,
    "isLiked": false
  },
  {
    "id": "post_90",
    "authorName": "Student Scholar #90",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528752845?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #90 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "7h ago",
    "likesCount": 45,
    "commentsCount": 3,
    "isLiked": true
  },
  {
    "id": "post_91",
    "authorName": "Dr. Academic Author #91",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528752968?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Just published our ArXiv research paper on Graph Attention Networks for Autonomous UAV Swarms! (Post #91 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "8h ago",
    "likesCount": 52,
    "commentsCount": 6,
    "isLiked": false
  },
  {
    "id": "post_92",
    "authorName": "Student Scholar #92",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528753091?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "USACO Gold Medalist walkthrough: How I solved Problem 3 using Disjoint Set Union & Segment Trees. (Post #92 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "9h ago",
    "likesCount": 59,
    "commentsCount": 9,
    "isLiked": false
  },
  {
    "id": "post_93",
    "authorName": "Dr. Academic Author #93",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528753214?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Stanford TreeHacks 2026 1st Place Win! Built an AI vector search tool connecting high school research to lab publications. (Post #93 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "TUTORING",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "10h ago",
    "likesCount": 66,
    "commentsCount": 12,
    "isLiked": false
  },
  {
    "id": "post_94",
    "authorName": "Student Scholar #94",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528753337?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Announcing 5 open RA positions in Dr. Jane Smith Autonomous Systems Lab at MIT. Stipend $3,200/mo. (Post #94 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "HACKATHON",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "11h ago",
    "likesCount": 73,
    "commentsCount": 15,
    "isLiked": false
  },
  {
    "id": "post_95",
    "authorName": "Dr. Academic Author #95",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528753460?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "International Mathematical Olympiad (IMO) 2026 Problem Selection & Gold Medal threshold analysis. (Post #95 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "GENERAL",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "12h ago",
    "likesCount": 80,
    "commentsCount": 18,
    "isLiked": true
  },
  {
    "id": "post_96",
    "authorName": "Student Scholar #96",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528753583?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": true,
    "content": "Full Scholarship guide to ETH Zurich & EPFL: Tuition is only CHF 1,460/yr with generous Excellence Fellowships. (Post #96 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "ADMISSION",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "1h ago",
    "likesCount": 87,
    "commentsCount": 21,
    "isLiked": false
  },
  {
    "id": "post_97",
    "authorName": "Dr. Academic Author #97",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528753706?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "How I scored 1580 on the Digital SAT (800 Math, 780 Reading) with 3 months of consistent module practice. (Post #97 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "RESEARCH",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "2h ago",
    "likesCount": 94,
    "commentsCount": 24,
    "isLiked": false
  },
  {
    "id": "post_98",
    "authorName": "Student Scholar #98",
    "authorRole": "STUDENT",
    "authorAvatar": "https://images.unsplash.com/photo-1534528753829?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": false,
    "content": "Ivy League Essay Blueprint: Why writing about authentic failure beats bragging about resume bullet points. (Post #98 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OLYMPIAD",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "3h ago",
    "likesCount": 101,
    "commentsCount": 27,
    "isLiked": false
  },
  {
    "id": "post_99",
    "authorName": "Dr. Academic Author #99",
    "authorRole": "OLYMPIAD",
    "authorAvatar": "https://images.unsplash.com/photo-1534528753952?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "USACO Gold | ISEF Winner | Incoming CS Student",
    "isVerified": true,
    "content": "Google DeepMind High School AI Internship applications are officially OPEN for Summer 2026! (Post #99 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "PROJECT",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "4h ago",
    "likesCount": 108,
    "commentsCount": 30,
    "isLiked": false
  },
  {
    "id": "post_100",
    "authorName": "Student Scholar #100",
    "authorRole": "PROFESSOR",
    "authorAvatar": "https://images.unsplash.com/photo-1534528754075?w=400&auto=format&fit=crop&q=80",
    "authorHeadline": "Professor & Lab Director at Top University",
    "isVerified": false,
    "content": "Accepted to MIT EECS Class of 2030! Here is my full SAT, GPA, USACO Gold, and ISEF research breakdown. (Post #100 on ScholarBy Academic Feed)\n\nKey takeaway: Academic consistency, third-party verified credentials, and early professor outreach build a bulletproof ScholarBy Passport™ profile.",
    "postType": "OPPORTUNITY",
    "tags": [
      "#ScholarBy",
      "#Admissions",
      "#Research",
      "#Olympiad",
      "#AI",
      "#Scholarship"
    ],
    "createdAt": "5h ago",
    "likesCount": 115,
    "commentsCount": 33,
    "isLiked": true
  }
];

export const MOCK_OPPORTUNITIES: OpportunityItem[] = [
  {
    "id": "opp_1",
    "creatorName": "IMO Board",
    "organization": "International Mathematical Olympiad",
    "title": "67th International Mathematical Olympiad (IMO 2026)",
    "category": "COMPETITION",
    "location": "International",
    "isRemote": false,
    "description": "The pinnacle world mathematics competition for pre-university students.",
    "eligibility": "High School Medalists",
    "deadline": "May 15, 2026",
    "applicationUrl": "https://imo-official.org",
    "tags": [
      "Math",
      "Olympiad",
      "World Championship"
    ],
    "isVerified": true,
    "createdAt": "1d ago",
    "prizePool": "Gold, Silver & Bronze Medals"
  },
  {
    "id": "opp_2",
    "creatorName": "Dr. Jane Smith",
    "organization": "MIT EECS & CSAIL",
    "title": "Undergraduate & High School Research Assistant (RA) in Edge AI UAVs",
    "category": "RESEARCH",
    "location": "Cambridge, MA",
    "isRemote": true,
    "description": "Work directly on Graph Attention Networks for autonomous drone swarms.",
    "eligibility": "USACO Gold / Strong Python & PyTorch",
    "deadline": "Nov 01, 2026",
    "applicationUrl": "https://mit.edu",
    "tags": [
      "MIT",
      "AI",
      "Robotics",
      "RA Position"
    ],
    "isVerified": true,
    "createdAt": "2d ago",
    "prizePool": "$3,200/mo Research Stipend"
  },
  {
    "id": "opp_3",
    "creatorName": "Kaggle & DeepMind",
    "organization": "Kaggle Grandmaster League",
    "title": "Global AI Bio-Genomics Datathon 2026",
    "category": "DATATHON",
    "location": "Global Online",
    "isRemote": true,
    "description": "Predict protein folding stability and RNA gene expressions using LLMs.",
    "eligibility": "Open to All Students",
    "deadline": "Dec 10, 2026",
    "applicationUrl": "https://kaggle.com",
    "tags": [
      "Datathon",
      "Bio-AI",
      "Kaggle",
      "Python"
    ],
    "isVerified": true,
    "createdAt": "3d ago",
    "prizePool": "$100,000 Cash Prize"
  },
  {
    "id": "opp_4",
    "creatorName": "FIRST Robotics",
    "organization": "FIRST Global Foundation",
    "title": "FIRST Robotics Competition (FRC) Championship 2026",
    "category": "ROBOTICS",
    "location": "Houston, TX",
    "isRemote": false,
    "description": "Design, build, and program industrial-size robots to compete in dynamic games.",
    "eligibility": "High School Teams",
    "deadline": "Jan 20, 2027",
    "applicationUrl": "https://firstinspires.org",
    "tags": [
      "Robotics",
      "STEM",
      "CAD",
      "Java/C++"
    ],
    "isVerified": true,
    "createdAt": "4d ago",
    "prizePool": "$10M+ College Scholarships"
  },
  {
    "id": "opp_5",
    "creatorName": "IOI Secretariat",
    "organization": "International Olympiad in Informatics",
    "title": "38th International Olympiad in Informatics (IOI 2026)",
    "category": "COMPETITIVE_PROGRAMMING",
    "location": "Singapore",
    "isRemote": false,
    "description": "The prestigious annual competitive programming competition for secondary school students.",
    "eligibility": "National IOI Selection Winners",
    "deadline": "Jul 01, 2026",
    "applicationUrl": "https://ioinformatics.org",
    "tags": [
      "Algorithms",
      "C++",
      "IOI",
      "Competitive Programming"
    ],
    "isVerified": true,
    "createdAt": "5d ago",
    "prizePool": "Full University Scholarships"
  },
  {
    "id": "opp_6",
    "creatorName": "Global Academic Partner #6",
    "organization": "Stanford University Lab #6",
    "title": "International Physics Olympiad (IPhO) Qualifier #6",
    "category": "COMPETITION",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #6 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 7, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "6d ago",
    "prizePool": "$11000 Award & Badge"
  },
  {
    "id": "opp_7",
    "creatorName": "Global Academic Partner #7",
    "organization": "ETH Zurich Institute #7",
    "title": "AI & Quantum Computing Hackathon #7",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #7 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 8, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "7d ago",
    "prizePool": "$12000 Award & Badge"
  },
  {
    "id": "opp_8",
    "creatorName": "Global Academic Partner #8",
    "organization": "Stanford University Lab #8",
    "title": "AI & Quantum Computing Hackathon #8",
    "category": "HACKATHON",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #8 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 9, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "8d ago",
    "prizePool": "$13000 Award & Badge"
  },
  {
    "id": "opp_9",
    "creatorName": "Global Academic Partner #9",
    "organization": "ETH Zurich Institute #9",
    "title": "International Physics Olympiad (IPhO) Qualifier #9",
    "category": "COMPETITION",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #9 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 10, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "9d ago",
    "prizePool": "$14000 Award & Badge"
  },
  {
    "id": "opp_10",
    "creatorName": "Global Academic Partner #10",
    "organization": "Stanford University Lab #10",
    "title": "AI & Quantum Computing Hackathon #10",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #10 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 11, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "10d ago",
    "prizePool": "$15000 Award & Badge"
  },
  {
    "id": "opp_11",
    "creatorName": "Global Academic Partner #11",
    "organization": "ETH Zurich Institute #11",
    "title": "AI & Quantum Computing Hackathon #11",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #11 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 12, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "11d ago",
    "prizePool": "$16000 Award & Badge"
  },
  {
    "id": "opp_12",
    "creatorName": "Global Academic Partner #12",
    "organization": "Stanford University Lab #12",
    "title": "International Physics Olympiad (IPhO) Qualifier #12",
    "category": "HACKATHON",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #12 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 13, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "12d ago",
    "prizePool": "$17000 Award & Badge"
  },
  {
    "id": "opp_13",
    "creatorName": "Global Academic Partner #13",
    "organization": "ETH Zurich Institute #13",
    "title": "AI & Quantum Computing Hackathon #13",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #13 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 14, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "13d ago",
    "prizePool": "$18000 Award & Badge"
  },
  {
    "id": "opp_14",
    "creatorName": "Global Academic Partner #14",
    "organization": "Stanford University Lab #14",
    "title": "AI & Quantum Computing Hackathon #14",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #14 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 15, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "14d ago",
    "prizePool": "$19000 Award & Badge"
  },
  {
    "id": "opp_15",
    "creatorName": "Global Academic Partner #15",
    "organization": "ETH Zurich Institute #15",
    "title": "International Physics Olympiad (IPhO) Qualifier #15",
    "category": "COMPETITION",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #15 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 16, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "15d ago",
    "prizePool": "$20000 Award & Badge"
  },
  {
    "id": "opp_16",
    "creatorName": "Global Academic Partner #16",
    "organization": "Stanford University Lab #16",
    "title": "AI & Quantum Computing Hackathon #16",
    "category": "HACKATHON",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #16 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 17, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "16d ago",
    "prizePool": "$21000 Award & Badge"
  },
  {
    "id": "opp_17",
    "creatorName": "Global Academic Partner #17",
    "organization": "ETH Zurich Institute #17",
    "title": "AI & Quantum Computing Hackathon #17",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #17 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 18, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "17d ago",
    "prizePool": "$22000 Award & Badge"
  },
  {
    "id": "opp_18",
    "creatorName": "Global Academic Partner #18",
    "organization": "Stanford University Lab #18",
    "title": "International Physics Olympiad (IPhO) Qualifier #18",
    "category": "COMPETITION",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #18 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 19, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "18d ago",
    "prizePool": "$23000 Award & Badge"
  },
  {
    "id": "opp_19",
    "creatorName": "Global Academic Partner #19",
    "organization": "ETH Zurich Institute #19",
    "title": "AI & Quantum Computing Hackathon #19",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #19 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 20, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "19d ago",
    "prizePool": "$24000 Award & Badge"
  },
  {
    "id": "opp_20",
    "creatorName": "Global Academic Partner #20",
    "organization": "Stanford University Lab #20",
    "title": "AI & Quantum Computing Hackathon #20",
    "category": "HACKATHON",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #20 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 21, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "20d ago",
    "prizePool": "$25000 Award & Badge"
  },
  {
    "id": "opp_21",
    "creatorName": "Global Academic Partner #21",
    "organization": "ETH Zurich Institute #21",
    "title": "International Physics Olympiad (IPhO) Qualifier #21",
    "category": "COMPETITION",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #21 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 22, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "21d ago",
    "prizePool": "$26000 Award & Badge"
  },
  {
    "id": "opp_22",
    "creatorName": "Global Academic Partner #22",
    "organization": "Stanford University Lab #22",
    "title": "AI & Quantum Computing Hackathon #22",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #22 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 23, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "22d ago",
    "prizePool": "$27000 Award & Badge"
  },
  {
    "id": "opp_23",
    "creatorName": "Global Academic Partner #23",
    "organization": "ETH Zurich Institute #23",
    "title": "AI & Quantum Computing Hackathon #23",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #23 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 24, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "23d ago",
    "prizePool": "$28000 Award & Badge"
  },
  {
    "id": "opp_24",
    "creatorName": "Global Academic Partner #24",
    "organization": "Stanford University Lab #24",
    "title": "International Physics Olympiad (IPhO) Qualifier #24",
    "category": "HACKATHON",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #24 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 25, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "24d ago",
    "prizePool": "$29000 Award & Badge"
  },
  {
    "id": "opp_25",
    "creatorName": "Global Academic Partner #25",
    "organization": "ETH Zurich Institute #25",
    "title": "AI & Quantum Computing Hackathon #25",
    "category": "RESEARCH",
    "location": "Remote / Global",
    "isRemote": true,
    "description": "Participate in world-class academic challenge #25 with mentorship from top faculty and industry research labs.",
    "eligibility": "High School Seniors & Undergraduates",
    "deadline": "Dec 26, 2026",
    "applicationUrl": "https://scholarby.edu",
    "tags": [
      "Academic",
      "Global",
      "Verified",
      "Research"
    ],
    "isVerified": true,
    "createdAt": "25d ago",
    "prizePool": "$30000 Award & Badge"
  }
];

export const INITIAL_APPLICATIONS: ApplicationBucketItem[] = [
  { id: 'app_1', universityId: 'uni_1', universityName: 'Massachusetts Institute of Technology (MIT)', programName: 'Computer Science & Engineering (EECS)', country: 'United States', category: 'DREAM', status: 'IN_PROGRESS', deadline: 'Nov 01, 2026', readinessScore: 92, checklist: [{ id: 'c1', title: 'SAT 1560 Score Report Sent', isCompleted: true }, { id: 'c2', title: 'USACO Gold Medal Certificate Uploaded', isCompleted: true }, { id: 'c3', title: 'Research Abstract for Dr. Vance', isCompleted: true }, { id: 'c4', title: 'Final MIT Essay Review', isCompleted: false }] },
  { id: 'app_2', universityId: 'uni_2', universityName: 'Stanford University', programName: 'Computer Science & AI Track', country: 'United States', category: 'DREAM', status: 'PREPARING', deadline: 'Jan 05, 2027', readinessScore: 88, checklist: [{ id: 'c5', title: 'Common App Essay Draft', isCompleted: true }, { id: 'c6', title: 'Stanford Short Answers', isCompleted: false }] },
  { id: 'app_3', universityId: 'uni_6', universityName: 'ETH Zurich', programName: 'Robotics, Systems & Control M.Sc.', country: 'Switzerland', category: 'TARGET', status: 'IN_PROGRESS', deadline: 'Dec 15, 2026', readinessScore: 95, checklist: [{ id: 'c7', title: 'German / English Proficiency Verified', isCompleted: true }, { id: 'c8', title: 'Recommendation Letter from Prof. Vance', isCompleted: true }] }
];

export const MOCK_COMMUNITIES: CommunityGroup[] = [
  { id: 'comm_1', name: 'MIT Class of 2030 Applicants', category: 'UNIVERSITY', description: 'Official community for prospective MIT EECS & STEM applicants.', membersCount: 1420, isJoined: true, recentTopics: [{ id: 't1', title: 'USACO Gold vs ISEF Award weight in MIT admissions?', author: 'Alex Chen', replies: 34, updatedAt: '2h ago' }] },
  { id: 'comm_2', name: 'International Mathematical Olympiad (IMO) Medalists', category: 'OLYMPIAD', description: 'Network of national team IMO, USACO, and IPhO participants.', membersCount: 890, isJoined: true, recentTopics: [{ id: 't2', title: 'IMO 2026 Problem 3 discussion & proof outline', author: 'Dr. Chen Wei', replies: 89, updatedAt: '1h ago' }] }
];

export const MOCK_MESSAGES: MessageThread[] = [
  { id: 'msg_1', contactName: 'Dr. Jane Smith', contactRole: 'PROFESSOR', contactAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80', unreadCount: 1, lastMessage: 'Loved your NeuroSwarm drone paper! Would you be free for an RA video interview next Tuesday?', lastMessageTime: '10:45 AM', messages: [{ id: 'm1', senderId: 'prof_1', senderName: 'Dr. Jane Smith', text: 'Loved your NeuroSwarm drone paper! Would you be free for an RA video interview next Tuesday?', timestamp: '10:45 AM' }] }
];

export const MOCK_AI_AGENTS: AiAgentStatus[] = [
  {
    id: 'agent_1',
    name: 'Scholarship Discovery Agent',
    sector: '🔎 Discovery',
    role: 'Crawls 450+ university portals, government sites, and embassy PDFs for new funding',
    status: 'ACTIVE',
    lastAction: 'Scanned ETH Zurich Master Fellowship PDF & extracted €15,000 grant data',
    tasksCompletedToday: 142,
    accuracy: '99.4%',
    humanInLoopRule: 'New scholarships require human editor verification before publishing',
  },
  {
    id: 'agent_2',
    name: 'Verification & QA Agent',
    sector: '🛡️ Verification',
    role: 'Cross-verifies extracted data against primary university PDFs & guidelines',
    status: 'WAITING_HUMAN_VERIFICATION',
    lastAction: 'Flagged MEXT Japan deadline extension for human sign-off',
    tasksCompletedToday: 89,
    accuracy: '100%',
    humanInLoopRule: 'Never independently marks scholarships as "Verified" without human review',
  },
  {
    id: 'agent_3',
    name: 'Change Monitor Agent',
    sector: '⚡ Change Detection',
    role: 'Continuously monitors 1,200+ scholarship URLs for deadline, funding, and eligibility shifts',
    status: 'ACTIVE',
    lastAction: 'Detected Gates Cambridge eligibility criteria update for 2027 intake',
    tasksCompletedToday: 530,
    accuracy: '99.8%',
    humanInLoopRule: 'High impact changes (deadline extensions) trigger instant push alerts',
  },
  {
    id: 'agent_4',
    name: '4D Eligibility Matching Engine',
    sector: '🧠 Matching',
    role: 'Calculates Academic, Field, Funding, & Urgency suitability scores',
    status: 'ACTIVE',
    lastAction: 'Evaluated 4D fit for Alex Chen against 25 scholarships (Top match: MIT President Fellowship 96%)',
    tasksCompletedToday: 1240,
    accuracy: '98.9%',
    humanInLoopRule: 'Explanations show exact reasoning behind scores rather than raw numbers',
  },
  {
    id: 'agent_5',
    name: 'Multichannel Content Factory',
    sector: '✍️ Content',
    role: 'Repurposes verified scholarships into Web, Instagram, LinkedIn, Telegram & Newsletter formats',
    status: 'PROCESSING',
    lastAction: 'Generated 4:5 Instagram carousel & Telegram alert for Knight-Hennessy Fellowship',
    tasksCompletedToday: 64,
    accuracy: '97.6%',
    humanInLoopRule: 'Editorial approval required before social distribution',
  },
  {
    id: 'agent_6',
    name: 'News Research Radar',
    sector: '📰 News Intelligence',
    role: 'Monitors international education ministries & classifies stories into Urgent, Useful, & Low',
    status: 'ACTIVE',
    lastAction: 'Classified UK Chevening application portal opening as 🔴 Urgent',
    tasksCompletedToday: 215,
    accuracy: '99.1%',
    humanInLoopRule: 'Human editor chooses final publishing queue',
  },
  {
    id: 'agent_7',
    name: 'Document Intelligence Agent',
    sector: '📄 Document AI',
    role: 'Parses uploaded CVs, transcripts, and test score reports into structured student JSON',
    status: 'ACTIVE',
    lastAction: 'Extracted GPA (3.92), IELTS (8.0), and 2 IEEE paper DOIs from uploaded PDF',
    tasksCompletedToday: 310,
    accuracy: '99.5%',
    humanInLoopRule: 'Students confirm extracted attributes on first upload',
  },
  {
    id: 'agent_8',
    name: 'Student Copilot Agent',
    sector: '💬 Support',
    role: 'Answers student queries directly against ScholarBy structured database 24/7',
    status: 'ACTIVE',
    lastAction: 'Resolved query: "Find fully-funded CS Master scholarships in Japan"',
    tasksCompletedToday: 840,
    accuracy: '98.7%',
    humanInLoopRule: 'Escalates complex visa or special appeal questions to human advisors',
  },
  {
    id: 'agent_9',
    name: 'Application OS Checklist Agent',
    sector: '🎯 Workflow OS',
    role: 'Tracks application checklists, missing documents, and countdown reminders',
    status: 'ACTIVE',
    lastAction: 'Sent automated alert to Alex: "18 days left — MIT research proposal incomplete"',
    tasksCompletedToday: 420,
    accuracy: '100%',
    humanInLoopRule: 'Reminder frequency set according to student preferences',
  },
  {
    id: 'agent_10',
    name: 'CRM & Lead Drop-off Agent',
    sector: '📊 Analytics & CRM',
    role: 'Identifies application drop-off points and optimizes student guidance funnel',
    status: 'ACTIVE',
    lastAction: 'Analyzed 1,500 application funnels; identified SOP draft blockages',
    tasksCompletedToday: 180,
    accuracy: '99.0%',
    humanInLoopRule: 'Strategic changes reviewed by operations team',
  },
];

export const MOCK_CHANGE_LOGS: ScholarshipChangeLog[] = [
  {
    id: 'change_1',
    scholarshipTitle: 'MEXT Japanese Government Research Scholarship',
    universityOrSource: 'MEXT Ministry of Education, Japan',
    changeType: 'DEADLINE_CHANGED',
    oldValue: 'Nov 15, 2026',
    newValue: 'Nov 30, 2026 (15-day extension)',
    detectedAt: '12 mins ago',
    sourceUrl: 'https://mext.go.jp/scholarships',
    verificationStatus: 'PENDING_HUMAN_APPROVAL',
  },
  {
    id: 'change_2',
    scholarshipTitle: 'ETH Zurich Excellence Master Fellowship',
    universityOrSource: 'ETH Zurich Financial Aid Office',
    changeType: 'FUNDING_UPDATE',
    oldValue: '€10,000 / year stipend',
    newValue: '€15,000 / year full stipend + tuition waiver',
    detectedAt: '45 mins ago',
    sourceUrl: 'https://ethz.ch/excellence-fellowship',
    verificationStatus: 'VERIFIED_AND_PUBLISHED',
  },
  {
    id: 'change_3',
    scholarshipTitle: 'Gates Cambridge International Scholarship',
    universityOrSource: 'University of Cambridge Trust',
    changeType: 'ELIGIBILITY_SHIFT',
    oldValue: 'Open to all Master & PhD candidates',
    newValue: 'Master candidates restricted to 1-year research degrees',
    detectedAt: '2 hours ago',
    sourceUrl: 'https://gatescambridge.org/apply',
    verificationStatus: 'VERIFIED_AND_PUBLISHED',
  },
  {
    id: 'change_4',
    scholarshipTitle: 'DAAD Helmut-Schmidt Public Policy Grant',
    universityOrSource: 'DAAD German Academic Exchange Service',
    changeType: 'NEW_SCHOLARSHIP_DETECTED',
    oldValue: 'None (New entry)',
    newValue: 'Full €1,300/mo stipend + health insurance + travel grant',
    detectedAt: '3 hours ago',
    sourceUrl: 'https://daad.de/helmut-schmidt',
    verificationStatus: 'PENDING_HUMAN_APPROVAL',
  },
];

export const MOCK_MATCH_SUITABILITY: Record<string, MatchSuitabilityBreakdown> = {
  'opp_1': {
    overallMatch: 96,
    academicFit: 94,
    fieldFit: 98,
    fundingFit: 100,
    deadlineUrgency: 'HIGH',
    semanticReasoning: 'Your 3.92 GPA, USACO Gold award, and NeuroSwarm drone publication match MIT EECS swarm intelligence lab preferences 100%. Full $62,000 tuition + $3,800/mo stipend included.',
    missingRequirements: ['Final Statement of Purpose polishing'],
  },
  'opp_2': {
    overallMatch: 92,
    academicFit: 90,
    fieldFit: 95,
    fundingFit: 100,
    deadlineUrgency: 'URGENT',
    semanticReasoning: 'Strong alignment with Stanford AI Lab (SAIL). Your Python/C++ skills meet the foundation model research assistant requirements.',
    missingRequirements: ['Updated Recommendation Letter from Prof. Vance'],
  },
  'opp_3': {
    overallMatch: 95,
    academicFit: 96,
    fieldFit: 92,
    fundingFit: 100,
    deadlineUrgency: 'HIGH',
    semanticReasoning: 'ETH Zurich ESOP covers full living costs (€15,000/yr). Your robotics project and IEEE conference paper place you in the top 3% candidate pool.',
    missingRequirements: ['Official ETH Zurich online portal submission'],
  },
};

export const MOCK_CONTENT_FACTORY: ContentFactoryItem[] = [
  {
    id: 'content_1',
    sourceScholarship: 'ETH Zurich Excellence Master Fellowship 2027',
    priority: 'URGENT',
    webArticle: {
      title: 'ETH Zurich Increases Excellence Master Fellowship Stipend to €15,000/yr for 2027',
      snippet: 'ETH Zurich has officially updated its ESOP fellowship parameters, increasing the living allowance to €15,000 annually while covering 100% of tuition fees for top international applicants.',
    },
    instagramCarousel: {
      slidesCount: 5,
      headline: 'Slide 1: €15,000 ETH Zurich Master Grant | Slide 2: Eligibility | Slide 3: Application Checklist',
    },
    linkedInPost: {
      text: '🎓 Major Higher Ed Funding Alert: ETH Zurich expands Excellence Scholarship & Opportunity Programme (ESOP). Here is what STEM applicants need to know about eligibility and supervisor outreach...',
    },
    telegramAlert: {
      text: '⚡ URGENT SCHOLARSHIP ALERT: ETH Zurich ESOP stipend bumped to €15,000/yr! Deadline: Dec 15. Tap for eligibility check.',
    },
    emailNewsletter: {
      subject: 'ScholarBy Weekly Digest: ETH Zurich €15k Fellowship + MEXT Japan Deadline Extension',
    },
    seoMeta: {
      title: 'ETH Zurich Excellence Master Scholarship 2027 - Eligibility & How to Apply',
      keywords: ['ETH Zurich', 'Master Scholarship', 'Switzerland Fellowship', 'STEM Funding'],
    },
    publishedAt: 'Today at 09:30 AM',
  },
  {
    id: 'content_2',
    sourceScholarship: 'MEXT Japanese Government Research Fellowship 2027',
    priority: 'URGENT',
    webArticle: {
      title: 'Japanese Ministry of Education (MEXT) Extends 2027 Research Fellowship Deadline',
      snippet: 'The MEXT Embassy track application deadline has been extended to November 30, providing applicants an additional 15 days to obtain university acceptance letters.',
    },
    instagramCarousel: {
      slidesCount: 4,
      headline: 'Slide 1: MEXT Deadline Extended! | Slide 2: 15-Day Bonus Time | Slide 3: Document Checklist',
    },
    linkedInPost: {
      text: '📢 Admissions Deadline Update: Japanese Government (MEXT) grants candidates 15 additional days. Full breakdown of required research proposals inside...',
    },
    telegramAlert: {
      text: '🔔 DEADLINE EXTENDED: MEXT Japan Research Fellowship now closes Nov 30! Update your ScholarBy Bucket List.',
    },
    emailNewsletter: {
      subject: 'MEXT Japan Deadline Extended by 15 Days — Action Required',
    },
    seoMeta: {
      title: 'MEXT Scholarship 2027 Extended Deadline & Application Guide',
      keywords: ['MEXT Scholarship', 'Japan Research Grant', 'Fully Funded Japan', 'Embassy Track'],
    },
    publishedAt: 'Today at 08:15 AM',
  },
];

