import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-center px-4 text-center">
      <h1 className="text-6xl font-extrabold text-[#0052CC]">404</h1>
      <h2 className="text-2xl font-bold text-[#1A1A1A] mt-2">Page Not Found</h2>
      <p className="text-[#64748B] mt-2 max-w-md">
        The academic resource or profile you are looking for might have been moved or does not exist.
      </p>
      <Link
        href="/feed"
        className="mt-6 px-6 py-2.5 bg-[#0052CC] text-white font-bold rounded-xl shadow-md hover:bg-[#0052CC]/90 transition-colors text-sm"
      >
        Return to Academic Feed
      </Link>
    </div>
  );
}
