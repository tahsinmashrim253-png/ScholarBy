export function getCountryFlag(countryName?: string): string {
  if (!countryName) return '🌐';
  const name = countryName.trim().toLowerCase();

  const flagMap: Record<string, string> = {
    'united states': '🇺🇸',
    'usa': '🇺🇸',
    'us': '🇺🇸',
    'singapore': '🇸🇬',
    'switzerland': '🇨🇭',
    'united kingdom': '🇬🇧',
    'uk': '🇬🇧',
    'japan': '🇯🇵',
    'canada': '🇨🇦',
    'germany': '🇩🇪',
    'france': '🇫🇷',
    'australia': '🇦🇺',
    'india': '🇮🇳',
    'china': '🇨🇳',
    'bangladesh': '🇧🇩',
    'south korea': '🇰🇷',
    'korea': '🇰🇷',
    'brazil': '🇧🇷',
    'vietnam': '🇻🇳',
    'indonesia': '🇮🇩',
    'malaysia': '🇲🇾',
    'pakistan': '🇵🇰',
    'turkey': '🇹🇷',
  };

  return flagMap[name] || '🌐';
}
