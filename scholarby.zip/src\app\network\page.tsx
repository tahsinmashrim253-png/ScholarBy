'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  Users,
  Search,
  BadgeCheck,
  UserPlus,
  UserCheck,
  MessageSquare,
  Building2,
  Microscope,
  GraduationCap,
} from 'lucide-react';
import { CURRENT_STUDENT } from '@/lib/mockData';

export default function NetworkPage() {
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({
    prof_vance: true,
  });

  const [searchQuery, setSearchQuery] = useState('');

  const networkMembers = [
    {
      id: 'prof_vance',
      name: 'Prof. Jonathan Vance',
      role: 'PROFESSOR',
      headline: 'Associate Professor of EECS at MIT CSAIL',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      institution: 'MIT',
      isVerified: true,
    },
    {
      id: 'user_sarah',
      name: 'Sarah Jenkins',
      role: 'STUDENT',
      headline: 'Quantum Computing Researcher | Stanford Class of 2029',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      institution: 'Stanford University',
      isVerified: true,
    },
    {
      id: 'uni_nus',
      name: 'National University of Singapore',
      role: 'UNIVERSITY',
      headline: 'Official University Account',
      avatarUrl: 'https://images.unsplash.com/photo-1592280771190-3e2e4d571952?w=150&auto=format&fit=crop&q=80',
      institution: 'Singapore',
      isVerified: true,
    },
    {
      id: 'prof_elena',
      name: 'Dr. Elena Rostova',
      role: 'PROFESSOR',
      headline: 'Director, ETH Zurich Robotics Institute',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
      institution: 'ETH Zurich',
      isVerified: true,
    },
  ];

  const toggleFollow = (id: string) => {
    setFollowingMap((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const filteredMembers = networkMembers.filter((m) =>
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.headline.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex bg-[#09090B] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl">
        {/* Header */}
        <div className="pb-6 border-b border-[#27272A]">
          <div className="flex items-center space-x-2">
            <Users className="w-4 h-4 text-[#FFC000]" />
            <span className="text-xs font-mono text-[#FFC000] uppercase tracking-wider">
              ScholarBy Academic Network
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            Discover & Connect with Peers, Professors & Institutions
          </h1>
          <p className="text-xs text-[#A1A1AA] mt-1">
            Build your academic research network and connect directly with mentors worldwide.
          </p>
        </div>

        {/* Search Toolbar */}
        <div className="mt-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A1A1AA]" />
            <input
              type="text"
              placeholder="Search researchers, professors, students..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#121215] border border-[#27272A] rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-[#A1A1AA] focus:border-[#FFC000] focus:outline-none"
            />
          </div>
        </div>

        {/* Network Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          {filteredMembers.map((member) => {
            const isFollowing = !!followingMap[member.id];
            return (
              <div
                key={member.id}
                className="p-5 rounded-2xl bg-[#121215] border border-[#27272A] hover:border-[#FFC000]/40 transition-colors flex items-center justify-between gap-4"
              >
                <div className="flex items-center space-x-4">
                  <img
                    src={member.avatarUrl}
                    alt={member.name}
                    className="w-12 h-12 rounded-2xl object-cover border border-[#FFC000]/40 flex-shrink-0"
                  />

                  <div>
                    <div className="flex items-center space-x-1.5">
                      <h3 className="text-sm font-bold text-white">{member.name}</h3>
                      {member.isVerified && <BadgeCheck className="w-4 h-4 text-[#FFC000]" />}
                    </div>
                    <span className="text-[10px] font-mono text-[#FFC000] uppercase">
                      {member.role} • {member.institution}
                    </span>
                    <p className="text-xs text-[#A1A1AA] mt-0.5">{member.headline}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-2 flex-shrink-0">
                  <button
                    onClick={() => toggleFollow(member.id)}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all flex items-center space-x-1 ${
                      isFollowing
                        ? 'bg-[#121215] text-[#FFC000] border-[#FFC000]/40'
                        : 'bg-[#FFC000] text-[#09090B] border-transparent hover:bg-[#E0A800]'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Connect</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
