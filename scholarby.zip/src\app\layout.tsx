import type { Metadata } from 'next';
import './globals.css';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { ProfileProvider } from '@/context/ProfileContext';

export const metadata: Metadata = {
  title: 'ScholarBy — Global Student Opportunity & Academic Ecosystem',
  description:
    'ScholarBy connects students, professors, universities, research labs, scholarships, Olympiads, and careers into one continuous academic lifecycle.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#09090B] text-white min-h-screen flex flex-col antialiased">
        <ProfileProvider>
          <Navbar />
          <div className="flex-1">{children}</div>
          <Footer />
        </ProfileProvider>
      </body>
    </html>
  );
}
