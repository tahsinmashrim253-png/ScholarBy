'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { MessageSquare, Send, Paperclip, CheckCircle2, User } from 'lucide-react';
import { MOCK_MESSAGES, CURRENT_STUDENT } from '@/lib/mockData';

export default function MessagesPage() {
  const [activeThread, setActiveThread] = useState(MOCK_MESSAGES[0]);
  const [textInput, setTextInput] = useState('');

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim()) return;

    const newMsg = {
      id: `m_${Date.now()}`,
      senderId: CURRENT_STUDENT.userId,
      senderName: CURRENT_STUDENT.user.name,
      text: textInput,
      timestamp: 'Just now',
    };

    setActiveThread({
      ...activeThread,
      lastMessage: textInput,
      messages: [...activeThread.messages, newMsg],
    });

    setTextInput('');
  };

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto flex flex-col">
        <div className="pb-6 border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <MessageSquare className="w-4 h-4 text-[#0052CC]" />
            <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
              ScholarBy Direct Messaging
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
            Direct Messages & Faculty Outreach
          </h1>
        </div>

        <div className="mt-6 flex-1 bg-white border border-[#E2E8F0] rounded-2xl shadow-sm grid grid-cols-1 md:grid-cols-3 overflow-hidden min-h-[500px]">
          {/* Thread List */}
          <div className="border-r border-[#E2E8F0] p-4 space-y-2 bg-[#F8FAFC]">
            <span className="text-[10px] font-mono text-[#64748B] uppercase font-bold tracking-wider px-2">Conversations</span>
            {MOCK_MESSAGES.map((thread) => (
              <button
                key={thread.id}
                onClick={() => setActiveThread(thread)}
                className={`w-full p-3 rounded-xl border text-left transition-colors flex items-center space-x-3 ${
                  activeThread.id === thread.id
                    ? 'bg-white border-[#0052CC] shadow-sm'
                    : 'bg-[#F8FAFC] border-transparent hover:bg-white'
                }`}
              >
                <img src={thread.contactAvatar} alt={thread.contactName} className="w-10 h-10 rounded-full object-cover border border-[#0052CC]" />
                <div className="flex-1 truncate">
                  <span className="text-xs font-bold text-[#1A1A1A] block">{thread.contactName}</span>
                  <span className="text-[11px] text-[#64748B] truncate block">{thread.lastMessage}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Active Chat Area */}
          <div className="md:col-span-2 flex flex-col justify-between p-4">
            <div className="pb-3 border-b border-[#E2E8F0] flex items-center space-x-3">
              <img src={activeThread.contactAvatar} alt={activeThread.contactName} className="w-9 h-9 rounded-full object-cover border border-[#0052CC]" />
              <div>
                <h3 className="text-sm font-bold text-[#1A1A1A]">{activeThread.contactName}</h3>
                <span className="text-[10px] font-mono text-[#0052CC] font-bold">{activeThread.contactRole}</span>
              </div>
            </div>

            <div className="flex-1 py-4 space-y-3 overflow-y-auto max-h-[360px]">
              {activeThread.messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${
                    m.senderId === CURRENT_STUDENT.userId ? 'items-end' : 'items-start'
                  }`}
                >
                  <div
                    className={`max-w-md p-3 rounded-2xl text-xs leading-relaxed ${
                      m.senderId === CURRENT_STUDENT.userId
                        ? 'bg-[#0052CC] text-white font-medium'
                        : 'bg-[#F8FAFC] border border-[#E2E8F0] text-[#1A1A1A] font-semibold'
                    }`}
                  >
                    {m.text}
                  </div>
                  <span className="text-[9px] text-[#64748B] mt-1 font-mono">{m.timestamp}</span>
                </div>
              ))}
            </div>

            <form onSubmit={handleSendMessage} className="pt-3 border-t border-[#E2E8F0] flex items-center space-x-2">
              <input
                type="text"
                placeholder="Type your message or RA query..."
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                className="flex-1 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl px-3.5 py-2.5 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
              />
              <button type="submit" className="p-2.5 rounded-xl bg-[#0052CC] text-white hover:bg-[#003D99] transition-colors shadow-sm">
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}
