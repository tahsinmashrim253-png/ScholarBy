'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight, CheckCircle2, ShieldCheck, UserCheck } from 'lucide-react';
import { RoleType } from '@/types';

export default function SignupPage() {
  const [selectedRole, setSelectedRole] = useState<RoleType>('STUDENT');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const roles: Array<{ type: RoleType; title: string; desc: string }> = [
    { type: 'STUDENT', title: 'Student Scholar', desc: 'High school, undergraduate & graduate candidates' },
    { type: 'PROFESSOR', title: 'Professor & Lab Director', desc: 'Post RA positions & review research portfolios' },
    { type: 'UNIVERSITY', title: 'University Admissions', desc: 'Institutional recruitment & applicant discovery' },
    { type: 'RESEARCH_LAB', title: 'Research Institute', desc: 'Post fellowships & research projects' },
    { type: 'OLYMPIAD', title: 'Olympiad Committee', desc: 'Verify official medals & contest results' },
    { type: 'TUTOR', title: '1-on-1 Educator / Tutor', desc: 'Teach SAT, IELTS, AP, and coding' },
    { type: 'COACHING_CENTER', title: 'Coaching Academy', desc: 'Showcase institute results & student reviews' },
    { type: 'CONSULTANT', title: 'Admissions Consultant', desc: 'Guide candidates to target Ivy League/Global Unis' },
    { type: 'COMPANY', title: 'Corporate Recruiter', desc: 'Hire top computational & STEM talent' },
    { type: 'ALUMNI', title: 'University Alumni', desc: 'Mentor students & share career opportunities' },
  ];

  return (
    <main className="min-h-screen bg-[#F8FAFC] py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto flex flex-col justify-center">
      <div className="text-center space-y-3">
        <Link href="/" className="inline-flex items-center space-x-3 group">
          <div className="w-10 h-10 rounded-xl bg-white border border-[#E2E8F0] flex items-center justify-center p-1 shadow-sm">
            <Image src="/logo.png" alt="ScholarBy Logo" width={32} height={32} className="object-contain" />
          </div>
          <span className="text-2xl font-extrabold text-[#1A1A1A] font-sans">
            Scholar<span className="text-[#0052CC]">By</span>
          </span>
        </Link>

        <h1 className="text-3xl font-extrabold text-[#1A1A1A]">Select Your Ecosystem Role</h1>
        <p className="text-xs text-[#64748B]">Choose your primary identity to join the 10+ year global academic graph.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
        {roles.map((r) => (
          <button
            key={r.type}
            type="button"
            onClick={() => setSelectedRole(r.type)}
            className={`p-4 rounded-2xl border text-left transition-all ${
              selectedRole === r.type
                ? 'bg-white border-[#0052CC] ring-2 ring-[#0052CC]/20 shadow-md'
                : 'bg-white border-[#E2E8F0] hover:border-[#0052CC]/50 shadow-sm'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-[#1A1A1A]">{r.title}</span>
              {selectedRole === r.type && (
                <span className="w-4 h-4 rounded-full bg-[#FFD60A] text-[#1A1A1A] flex items-center justify-center text-[10px] font-bold">
                  ✓
                </span>
              )}
            </div>
            <p className="text-xs text-[#64748B] mt-1">{r.desc}</p>
          </button>
        ))}
      </div>

      <div className="mt-8 p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Full Name</label>
            <input
              type="text"
              placeholder="e.g. Alex Chen"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Institutional Email</label>
            <input
              type="email"
              placeholder="alex@scholarby.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
            />
          </div>
        </div>

        <Link
          href="/dashboard"
          className="w-full py-3.5 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors shadow-blue-lg flex items-center justify-center space-x-2 block text-center"
        >
          <span>Create {selectedRole} Account & Launch Dashboard</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </main>
  );
}
