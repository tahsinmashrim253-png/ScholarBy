'use client';

import React from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Users, MessageSquare, Plus, CheckCircle2 } from 'lucide-react';
import { MOCK_COMMUNITIES } from '@/lib/mockData';
import Link from 'next/link';

export default function CommunitiesPage() {
  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        <div className="pb-6 border-b border-[#E2E8F0] flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-[#0052CC]" />
              <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
                Student & Class Communities
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
              Global Student Communities & Olympiad Hubs
            </h1>
            <p className="text-xs text-[#64748B] mt-1">
              Connect with fellow applicants, current undergraduates, and Olympiad medalists across major universities.
            </p>
          </div>

          <button className="px-4 py-2.5 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center space-x-1.5 shadow-blue-lg">
            <Plus className="w-4 h-4" />
            <span>Create Community</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          {MOCK_COMMUNITIES.map((comm) => (
            <div key={comm.id} className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC] transition-colors flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-[#FFD60A] text-[#1A1A1A]">
                    {comm.category}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#0052CC]">{comm.membersCount} Members</span>
                </div>

                <h3 className="text-lg font-bold text-[#1A1A1A] mt-2">{comm.name}</h3>
                <p className="text-xs text-[#64748B] mt-1">{comm.description}</p>

                <div className="mt-4 space-y-2">
                  <span className="text-[10px] font-mono text-[#64748B] uppercase font-bold tracking-wider">Recent Discussions</span>
                  {comm.recentTopics.map((t) => (
                    <div key={t.id} className="p-2.5 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0] text-xs">
                      <span className="font-bold text-[#1A1A1A] block">{t.title}</span>
                      <span className="text-[11px] text-[#64748B]">by {t.author} • {t.replies} replies</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                <span className="text-emerald-700 font-bold">✓ Joined Group</span>
                <Link href="/feed" className="text-[#0052CC] font-bold hover:underline">
                  View Community Feed →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
