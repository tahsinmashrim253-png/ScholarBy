'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  GraduationCap,
  Sparkles,
  BookmarkCheck,
  Award,
  BookOpen,
  UserCheck,
  Bot,
  Users,
  MessageSquare,
  Briefcase,
  UserCheck2,
  Settings,
  Microscope,
  Compass,
  Trophy,
  Building2,
  School,
  Target,
} from 'lucide-react';
import { useProfile } from '@/context/ProfileContext';
import { INITIAL_APPLICATIONS, MOCK_FEED_POSTS } from '@/lib/mockData';
import { getCountryFlag } from '@/lib/countryFlags';

export const Sidebar: React.FC = () => {
  const pathname = usePathname();
  const { student } = useProfile();
  const flagEmoji = getCountryFlag(student.user.country);

  const mainTabs = [
    { name: 'Command Center', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Profile Tracker', href: '/profile-tracker', icon: Target, badge: 'Probability %' },
    { name: 'Academic Feed', href: '/feed', icon: Compass, count: '100+' },
    { name: 'Explore Hub', href: '/opportunities', icon: Sparkles, badge: 'AI Match' },
    { name: 'University Bucket List', href: '/applications', icon: BookmarkCheck, count: INITIAL_APPLICATIONS.length },
    { name: 'Professors & Labs', href: '/professors', icon: Microscope, count: '20+' },
    { name: 'University Directory', href: '/universities', icon: GraduationCap, count: '20+' },
    { name: 'Top Olympiads', href: '/opportunities?tab=olympiads', icon: Trophy, count: '20+' },
    { name: 'Tutor Marketplace', href: '/tutors', icon: BookOpen, count: '20+' },
    { name: 'Coaching Centers', href: '/tutors?tab=coaching', icon: School, count: '20+' },
    { name: 'Admissions Consultants', href: '/consultants', icon: UserCheck2, count: '20+' },
    { name: 'AI Essay Assistant', href: '/ai-assistant', icon: Bot, badge: 'AI Tool' },
    { name: 'ScholarBy Passport', href: `/passport/${student.user.name.toLowerCase().replace(/\s+/g, '')}`, icon: UserCheck },
    { name: 'Communities', href: '/communities', icon: Users },
    { name: 'Direct Messages', href: '/messages', icon: MessageSquare, count: 1 },
    { name: 'Profile Settings', href: '/settings', icon: Settings },
  ];

  return (
    <aside className="w-64 flex-shrink-0 hidden lg:block border-r border-[#E2E8F0] min-h-[calc(100vh-4rem)] p-4 bg-white shadow-card-soft">
      {/* Student Passport Mini Card */}
      <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] mb-6 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="relative flex-shrink-0">
            <img
              src={student.user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
              alt={student.user.name}
              className="w-10 h-10 rounded-full object-cover border-2 border-[#0052CC]"
            />
          </div>

          <div className="flex flex-col truncate">
            <div className="flex items-center space-x-1">
              <span className="text-sm font-bold text-[#1A1A1A] truncate">{student.user.name}</span>
              <span className="text-xs leading-none select-none" title={student.user.country}>
                {flagEmoji}
              </span>
            </div>
            <span className="text-[11px] text-[#64748B] truncate">{student.school}</span>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-[#E2E8F0] flex items-center justify-between text-[11px]">
          <span className="text-[#64748B] font-medium">Passport Readiness</span>
          <span className="font-mono font-bold text-[#0052CC]">94%</span>
        </div>
        <div className="w-full bg-[#E2E8F0] h-1.5 rounded-full mt-1.5 overflow-hidden">
          <div className="bg-[#0052CC] h-full rounded-full" style={{ width: '94%' }} />
        </div>
        <Link
          href="/settings"
          className="mt-3 block text-center py-1.5 rounded-lg bg-white border border-[#E2E8F0] hover:border-[#0052CC] text-[11px] font-bold text-[#0052CC] transition-colors shadow-sm"
        >
          Edit Profile Information →
        </Link>
      </div>

      {/* Primary Left Navigation Tabs */}
      <div>
        <span className="px-3 text-[10px] font-mono uppercase tracking-widest text-[#64748B] font-bold">
          Ecosystem Tabs
        </span>
        <nav className="mt-2 space-y-1">
          {mainTabs.map((link) => {
            const Icon = link.icon;
            const isActive = pathname === link.href || (link.href !== '/dashboard' && pathname.startsWith(link.href.split('?')[0]));
            return (
              <Link
                key={link.name}
                href={link.href}
                className={`flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-[#0052CC] text-white shadow-md'
                    : 'text-[#4A5568] hover:text-[#0052CC] hover:bg-[#F8FAFC]'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-[#64748B]'}`} />
                  <span>{link.name}</span>
                </div>
                {link.count !== undefined && (
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                      isActive ? 'bg-white/20 text-white' : 'bg-[#E2E8F0] text-[#1A1A1A]'
                    }`}
                  >
                    {link.count}
                  </span>
                )}
                {link.badge && (
                  <span
                    className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${
                      isActive ? 'bg-[#FFD60A] text-[#1A1A1A]' : 'bg-[#FFD60A] text-[#1A1A1A]'
                    }`}
                  >
                    {link.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
      </div>
    </aside>
  );
};
