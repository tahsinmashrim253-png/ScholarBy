'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  GraduationCap,
  Search,
  Globe,
  Award,
  BookmarkCheck,
  ExternalLink,
  Plus,
} from 'lucide-react';
import { MOCK_UNIVERSITIES } from '@/lib/mockData';
import Link from 'next/link';

export default function UniversitiesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [countryFilter, setCountryFilter] = useState('ALL');

  const countries = ['ALL', 'United States', 'United Kingdom', 'Switzerland', 'Singapore', 'Japan', 'Canada', 'China', 'South Korea', 'Australia'];

  const filteredUnis = MOCK_UNIVERSITIES.filter((uni) => {
    if (countryFilter !== 'ALL' && uni.country !== countryFilter) return false;
    if (
      searchQuery &&
      !uni.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !uni.country.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !uni.description.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="pb-6 border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <GraduationCap className="w-4 h-4 text-[#0052CC]" />
            <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
              ScholarBy University Directory
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
            Global University Directory (20+ World Leader Institutions)
          </h1>
          <p className="text-xs text-[#64748B] mt-1">
            Explore world rankings, tuition, admission acceptance rates, and degree programs across US, UK, Europe & Asia.
          </p>
        </div>

        {/* Toolbar */}
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2 overflow-x-auto w-full md:w-auto pb-1">
            {countries.map((c) => (
              <button
                key={c}
                onClick={() => setCountryFilter(c)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                  countryFilter === c
                    ? 'bg-[#0052CC] text-white shadow-sm'
                    : 'bg-white text-[#64748B] hover:text-[#1A1A1A] border border-[#E2E8F0]'
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#64748B]" />
            <input
              type="text"
              placeholder="Search MIT, Stanford, Oxford..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-[#E2E8F0] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#1A1A1A] placeholder-[#64748B] focus:border-[#0052CC] focus:outline-none"
            />
          </div>
        </div>

        {/* University Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          {filteredUnis.map((uni) => (
            <div
              key={uni.id}
              className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC] transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <img
                      src={uni.logoUrl}
                      alt={uni.name}
                      className="w-12 h-12 rounded-xl object-cover border border-[#E2E8F0]"
                    />
                    <div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#FFD60A] text-[#1A1A1A]">
                        World Rank #{uni.ranking}
                      </span>
                      <h3 className="text-base font-bold text-[#1A1A1A] mt-1">{uni.name}</h3>
                      <span className="text-xs text-[#64748B]">{uni.city}, {uni.country}</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-[#64748B] mt-3 leading-relaxed">
                  {uni.description}
                </p>

                <div className="mt-4 p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-[10px] text-[#64748B] uppercase font-mono font-bold block">Tuition Fee</span>
                    <span className="font-bold text-[#1A1A1A]">{uni.tuitionFee}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#64748B] uppercase font-mono font-bold block">Acceptance Rate</span>
                    <span className="font-bold text-[#0052CC]">{uni.acceptanceRate}%</span>
                  </div>
                </div>

                <div className="mt-4 space-y-1.5">
                  <span className="text-[10px] font-mono text-[#64748B] uppercase font-bold tracking-wider">
                    Featured Degree Programs ({uni.programs.length})
                  </span>
                  {uni.programs.map((prog) => (
                    <div key={prog.id} className="p-2.5 rounded-lg bg-white border border-[#E2E8F0] flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-[#1A1A1A] block">{prog.name}</span>
                        <span className="text-[11px] text-[#64748B]">{prog.degree} • Deadline: {prog.deadline}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                <Link
                  href="/applications"
                  className="px-3.5 py-1.5 rounded-lg bg-[#0052CC]/10 text-[#0052CC] font-bold border border-[#0052CC]/30 hover:bg-[#0052CC]/20 flex items-center space-x-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add to Bucket List</span>
                </Link>

                <a
                  href={uni.website}
                  target="_blank"
                  rel="noreferrer"
                  className="text-[#0052CC] font-bold hover:underline flex items-center space-x-1"
                >
                  <span>Official Website</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
