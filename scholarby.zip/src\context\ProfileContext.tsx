'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { StudentPassport, TestScore, Project, Achievement } from '@/types';
import { CURRENT_STUDENT } from '@/lib/mockData';

interface ProfileContextType {
  student: StudentPassport;
  updateProfile: (updated: Partial<StudentPassport> & { name?: string; avatarUrl?: string; country?: string; headline?: string; bio?: string }) => void;
  addTestScore: (score: Omit<TestScore, 'id'>) => void;
  removeTestScore: (id: string) => void;
  addProject: (project: Omit<Project, 'id'>) => void;
  removeProject: (id: string) => void;
  addAchievement: (achievement: Omit<Achievement, 'id'>) => void;
  removeAchievement: (id: string) => void;
}

const STORAGE_KEY = 'scholarby_user_profile_v1';

const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

export const ProfileProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [student, setStudent] = useState<StudentPassport>(CURRENT_STUDENT);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        setStudent(parsed);
      }
    } catch (e) {
      console.error('Failed to load profile from localStorage', e);
    }
    setIsLoaded(true);
  }, []);

  // Save helper
  const saveStudentState = (newStudent: StudentPassport) => {
    setStudent(newStudent);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newStudent));
    } catch (e) {
      console.error('Failed to save profile to localStorage', e);
    }
  };

  const updateProfile = (data: Partial<StudentPassport> & { name?: string; avatarUrl?: string; country?: string; headline?: string; bio?: string }) => {
    const updated: StudentPassport = {
      ...student,
      ...data,
      user: {
        ...student.user,
        name: data.name !== undefined ? data.name : student.user.name,
        avatarUrl: data.avatarUrl !== undefined ? data.avatarUrl : student.user.avatarUrl,
        country: data.country !== undefined ? data.country : student.user.country,
        headline: data.headline !== undefined ? data.headline : student.user.headline,
        bio: data.bio !== undefined ? data.bio : student.user.bio,
      },
    };
    saveStudentState(updated);
  };

  const addTestScore = (scoreData: Omit<TestScore, 'id'>) => {
    const newScore: TestScore = { ...scoreData, id: `ts_${Date.now()}` };
    const updated = {
      ...student,
      testScores: [...student.testScores, newScore],
    };
    saveStudentState(updated);
  };

  const removeTestScore = (id: string) => {
    const updated = {
      ...student,
      testScores: student.testScores.filter((s) => s.id !== id),
    };
    saveStudentState(updated);
  };

  const addProject = (projectData: Omit<Project, 'id'>) => {
    const newProj: Project = { ...projectData, id: `proj_${Date.now()}` };
    const updated = {
      ...student,
      projects: [...student.projects, newProj],
    };
    saveStudentState(updated);
  };

  const removeProject = (id: string) => {
    const updated = {
      ...student,
      projects: student.projects.filter((p) => p.id !== id),
    };
    saveStudentState(updated);
  };

  const addAchievement = (achData: Omit<Achievement, 'id'>) => {
    const newAch: Achievement = { ...achData, id: `ach_${Date.now()}` };
    const updated = {
      ...student,
      achievements: [...student.achievements, newAch],
    };
    saveStudentState(updated);
  };

  const removeAchievement = (id: string) => {
    const updated = {
      ...student,
      achievements: student.achievements.filter((a) => a.id !== id),
    };
    saveStudentState(updated);
  };

  return (
    <ProfileContext.Provider
      value={{
        student,
        updateProfile,
        addTestScore,
        removeTestScore,
        addProject,
        removeProject,
        addAchievement,
        removeAchievement,
      }}
    >
      {children}
    </ProfileContext.Provider>
  );
};

export function useProfile() {
  const context = useContext(ProfileContext);
  if (!context) {
    throw new Error('useProfile must be used within a ProfileProvider');
  }
  return context;
}
