'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  Microscope,
  Search,
  BadgeCheck,
  MessageSquare,
  FileText,
  ExternalLink,
  BookOpen,
  Plus,
  Send,
} from 'lucide-react';
import { MOCK_PROFESSORS, CURRENT_STUDENT } from '@/lib/mockData';
import { ProfessorListing } from '@/types';
import Link from 'next/link';

export default function ProfessorsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProf, setSelectedProf] = useState<ProfessorListing | null>(null);
  const [applySuccess, setApplySuccess] = useState(false);

  const filteredProfs = MOCK_PROFESSORS.filter((prof) => {
    if (
      searchQuery &&
      !prof.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !prof.university.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !prof.researchFocus.some((r) => r.toLowerCase().includes(searchQuery.toLowerCase()))
    ) {
      return false;
    }
    return true;
  });

  const handleApplyRA = () => {
    setApplySuccess(true);
    setTimeout(() => {
      setApplySuccess(false);
      setSelectedProf(null);
    }, 3000);
  };

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="pb-6 border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <Microscope className="w-4 h-4 text-[#0052CC]" />
            <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
              Professors & Research Labs Network
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
            Professors & Research Labs Directory (20+ Lab Directors)
          </h1>
          <p className="text-xs text-[#64748B] mt-1">
            Discover verified professors across MIT, Stanford, Harvard, ETH Zurich, Oxford, and apply for active Research Assistant (RA) vacancies.
          </p>
        </div>

        {/* Search Toolbar */}
        <div className="mt-6 flex items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#64748B]" />
            <input
              type="text"
              placeholder="Search Robotics, Quantum, Neural Nets, MIT..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-[#E2E8F0] rounded-xl pl-8 pr-3 py-2 text-xs text-[#1A1A1A] placeholder-[#64748B] focus:border-[#0052CC] focus:outline-none shadow-sm"
            />
          </div>
        </div>

        {/* Professor Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          {filteredProfs.map((prof) => (
            <div
              key={prof.id}
              className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC] transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start space-x-4">
                  <img
                    src={prof.avatarUrl}
                    alt={prof.name}
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-[#0052CC] flex-shrink-0"
                  />
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <h3 className="text-base font-bold text-[#1A1A1A]">{prof.name}</h3>
                      {prof.isVerified && (
                        <span className="w-4 h-4 rounded-full bg-[#FFD60A] text-[#1A1A1A] flex items-center justify-center text-[10px] font-bold" title="Verified Faculty">
                          ✓
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-semibold text-[#0052CC]">{prof.title}</p>
                    <p className="text-xs text-[#64748B]">{prof.university} • {prof.department}</p>
                  </div>
                </div>

                <p className="text-xs text-[#64748B] mt-3 leading-relaxed">
                  {prof.bio}
                </p>

                {/* Research Focus Tags */}
                <div className="mt-3 flex items-center space-x-1.5 flex-wrap gap-y-1">
                  {prof.researchFocus.map((rf) => (
                    <span
                      key={rf}
                      className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#0052CC]/10 text-[#0052CC] border border-[#0052CC]/20 font-bold"
                    >
                      {rf}
                    </span>
                  ))}
                </div>

                {prof.recentPaper && (
                  <div className="mt-4 p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] text-xs">
                    <span className="text-[10px] text-[#64748B] uppercase font-mono font-bold block">Recent Publication</span>
                    <span className="font-bold text-[#1A1A1A] block">{prof.recentPaper.title}</span>
                    <span className="text-[11px] text-[#0052CC] font-mono">DOI: {prof.recentPaper.doi}</span>
                  </div>
                )}
              </div>

              <div className="mt-6 pt-4 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                <Link
                  href="/messages"
                  className="px-3 py-1.5 rounded-lg bg-white border border-[#E2E8F0] hover:border-[#0052CC] text-[#1A1A1A] font-bold flex items-center space-x-1"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-[#0052CC]" />
                  <span>Contact Lab</span>
                </Link>

                <button
                  onClick={() => setSelectedProf(prof)}
                  className="px-4 py-1.5 rounded-lg bg-[#0052CC] text-white font-bold hover:bg-[#003D99] transition-colors shadow-sm flex items-center space-x-1"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Apply for RA ({prof.activeOpeningsCount} Openings)</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* RA Application Modal */}
        {selectedProf && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white border border-[#E2E8F0] rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
                <h3 className="text-base font-bold text-[#1A1A1A]">Apply for Research Assistant (RA) Position</h3>
                <button onClick={() => setSelectedProf(null)} className="text-xs font-bold text-[#64748B] hover:text-[#1A1A1A]">
                  ✕ Close
                </button>
              </div>

              <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] text-xs space-y-1">
                <p className="font-bold text-[#1A1A1A]">{selectedProf.name} — {selectedProf.labName || selectedProf.university}</p>
                <p className="text-[#64748B]">{selectedProf.university} • {selectedProf.department}</p>
              </div>

              {applySuccess ? (
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold text-center">
                  ✓ Research Assistant application submitted successfully using your ScholarBy Passport™!
                </div>
              ) : (
                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Attached ScholarBy Passport</label>
                    <div className="p-2.5 rounded-lg bg-white border border-[#E2E8F0] font-mono text-[11px] text-[#0052CC] font-bold">
                      scholarby.com/@{CURRENT_STUDENT.user.name.toLowerCase().replace(/\s+/g, '')} (Verified SAT 1560, USACO Gold)
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Statement of Research Interest</label>
                    <textarea
                      rows={4}
                      defaultValue={`Dear ${selectedProf.name},\n\nI am writing to express my strong enthusiasm for joining the ${selectedProf.labName || 'Research Lab'} as a Research Assistant. My research background in ${selectedProf.researchFocus[0]} aligns directly with your lab's publications...`}
                      className="w-full bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-3 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
                    />
                  </div>

                  <button
                    onClick={handleApplyRA}
                    className="w-full py-3 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors shadow-blue-lg flex items-center justify-center space-x-1.5"
                  >
                    <Send className="w-4 h-4" />
                    <span>Submit RA Application</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
