'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  Bot,
  Sparkles,
  Search,
  FileText,
  Upload,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Share2,
  Sliders,
  Send,
  Zap,
  TrendingUp,
  Award,
  Layers,
  ArrowRight,
  ShieldCheck,
  Globe,
  Bell,
  Clock,
  ChevronRight,
  Cpu,
  FileCheck,
  Eye,
} from 'lucide-react';
import {
  MOCK_AI_AGENTS,
  MOCK_CHANGE_LOGS,
  MOCK_MATCH_SUITABILITY,
  MOCK_CONTENT_FACTORY,
  MOCK_OPPORTUNITIES,
  MOCK_UNIVERSITIES,
  CURRENT_STUDENT,
} from '@/lib/mockData';
import { ScholarshipChangeLog, ContentFactoryItem, AiAgentStatus } from '@/types';

export default function AiAssistantPage() {
  const [activeTab, setActiveTab] = useState<'COPILOT' | 'DOC_AI' | 'DISCOVERY' | 'CONTENT' | 'AGENTS' | 'ESSAY'>('COPILOT');

  // Copilot Query State
  const [query, setQuery] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{ role: 'user' | 'assistant'; text: string; data?: any }>>([
    {
      role: 'assistant',
      text: 'Greetings Alex! I am ScholarBy AI Copilot. I directly query ScholarBy’s structured database of 20+ Universities, 25+ Scholarships, 20+ Professors, and 20+ Consultants.\n\nAsk me anything like:\n• "Find fully-funded CS Master scholarships in Japan or Switzerland"\n• "What are my admission odds for MIT EECS with my 3.92 GPA and USACO Gold?"\n• "Show Oxford & Cambridge RA openings with monthly stipend"',
    },
  ]);
  const [isQuerying, setIsQuerying] = useState(false);

  // Document Intelligence Upload State
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isParsingDoc, setIsParsingDoc] = useState(false);
  const [parsedProfile, setParsedProfile] = useState<any>(null);

  // Change Log Verification State
  const [changeLogs, setChangeLogs] = useState<ScholarshipChangeLog[]>(MOCK_CHANGE_LOGS);

  // Essay State
  const [essayText, setEssayText] = useState('');
  const [essayFeedback, setEssayFeedback] = useState<string | null>(null);
  const [isAnalyzingEssay, setIsAnalyzingEssay] = useState(false);

  const handleQuerySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    const userText = query;
    setQuery('');
    setChatHistory((prev) => [...prev, { role: 'user', text: userText }]);
    setIsQuerying(true);

    setTimeout(() => {
      setIsQuerying(false);
      let replyText = '';
      let matchData = null;

      if (userText.toLowerCase().includes('japan') || userText.toLowerCase().includes('mext')) {
        replyText = `🔎 **Query Result: MEXT Japanese Government Research Fellowship 2027**\n\n• **Status**: Active (Deadline Extended by AI Change Agent to Nov 30!)\n• **Funding**: 100% Tuition Waiver + ¥143,000/mo stipend + roundtrip airfare.\n\n📊 **Your 4D Suitability Breakdown**:\n- **Academic Fit**: 95% (Your 3.92 GPA satisfies first-class honors benchmark)\n- **Field Fit**: 98% (CS/Robotics research matches Tokyo Tech & Kyoto University labs)\n- **Funding Fit**: 100% (Fully funded)\n- **Deadline Urgency**: URGENT (18 Days Left)\n\n✅ **Why You Match**: Your USACO Gold Medal and NeuroSwarm drone paper put you in the top 2% of international applicants.\n\n⚠️ **Missing Action**: Research proposal draft for Tokyo Institute of Technology supervisor approval.`;
        matchData = MOCK_OPPORTUNITIES.find((o) => o.id === 'opp_3');
      } else if (userText.toLowerCase().includes('mit') || userText.toLowerCase().includes('odds')) {
        replyText = `📊 **Query Result: MIT EECS Graduate Admissions & RA Opportunity**\n\n• **Overall Match Score**: 96% Match\n• **Academic Fit**: 94% | **Field Fit**: 98% | **Funding Fit**: 100%\n• **Supervising Faculty Match**: Dr. Jane Smith (Swarm Robotics Lab - 3 RA openings)\n\n💡 **Semantic Analysis**: MIT EECS heavily weighs verified credentials. Your verified USACO Gold badge and IEEE published paper establish strong research capability.\n\n🎯 **Application OS Checklist**: SAT 1560 Sent ✅ | USACO Badge Uploaded ✅ | Statement of Purpose Draft ⏳ (Incomplete - 18 days remaining).`;
        matchData = MOCK_OPPORTUNITIES.find((o) => o.id === 'opp_1');
      } else {
        replyText = `🔎 **Query Result: ETH Zurich Excellence Master Fellowship (ESOP)**\n\n• **Funding Surge**: Updated to €15,000/yr living allowance + 100% tuition waiver.\n• **4D Suitability**: Academic Fit: 96% | Field Fit: 92% | Funding Fit: 100% | Urgency: HIGH.\n• **Why You Match**: Your B.Sc. coursework in Data Structures & Swarm Systems aligns with ETH Systems & Control M.Sc. requirements.\n\n📌 **Recommended Next Step**: Submit recommendation request to Prof. David Chen via ScholarBy Network.`;
        matchData = MOCK_OPPORTUNITIES.find((o) => o.id === 'opp_3');
      }

      setChatHistory((prev) => [...prev, { role: 'assistant', text: replyText, data: matchData }]);
    }, 1200);
  };

  const handleDocUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadedFile(file);
      setIsParsingDoc(true);

      setTimeout(() => {
        setIsParsingDoc(false);
        setParsedProfile({
          candidateName: CURRENT_STUDENT.user.name,
          extractedGpa: '3.92 / 4.00 (Top 1% Rank)',
          education: 'B.Sc. Computer Science & Artificial Intelligence',
          testScores: { SAT: '1560/1600', IELTS: '8.0/9.0', GRE: '332/340' },
          researchKeywords: ['Swarm Intelligence', 'Edge-AI Drones', 'Distributed Consensus'],
          publicationsExtracted: [
            { title: 'NeuroSwarm: Autonomous Edge-AI Swarm Navigation', doi: '10.1109/LRA.2026.342119' },
          ],
          verifiedCredentials: ['USACO Gold Medalist', 'ISEF 1st Grand Award'],
        });
      }, 1500);
    }
  };

  const handleVerifyChange = (id: string) => {
    setChangeLogs((prev) =>
      prev.map((item) => (item.id === id ? { ...item, verificationStatus: 'VERIFIED_AND_PUBLISHED' } : item))
    );
  };

  const handleEssayAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!essayText.trim()) return;

    setIsAnalyzingEssay(true);
    setTimeout(() => {
      setIsAnalyzingEssay(false);
      setEssayFeedback(
        `ScholarBy AI Essay Evaluation:\n\n1. Impact & Authenticity Score: 96/100\n2. Key Strengths: Outstanding connection between USACO Gold algorithmic resilience and edge-AI swarm robotics research.\n3. Tactical Refinement: Expand paragraph 3 to explicitly explain why Dr. Jane Smith's lab at MIT EECS is your single target destination.`
      );
    }, 1400);
  };

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
        {/* Header Banner */}
        <div className="p-6 rounded-3xl bg-gradient-to-br from-[#0052CC] via-[#003D99] to-[#002966] text-white shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div>
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-xs font-mono text-[#FFD60A] font-bold">
                <Cpu className="w-3.5 h-3.5" />
                <span>SCHOLARBY AI-NATIVE SCHOLARSHIP OPERATING SYSTEM</span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight mt-2 text-white">
                AI Scholarship Intelligence & Autonomous OS
              </h1>
              <p className="text-xs sm:text-sm text-blue-100 mt-1 max-w-3xl">
                10 Autonomous AI Sectors working in real-time: Scholarship Discovery, 4D Suitability Matching, Change Detection, Multichannel Content Factory, Document Parsing & Application OS.
              </p>
            </div>

            {/* Live Agent Operational Badge */}
            <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/20">
              <div className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">10 Autonomous Agents Live</p>
                <p className="text-[10px] text-blue-200 font-mono">1,240 tasks today • Human-in-the-Loop ✓</p>
              </div>
            </div>
          </div>

          {/* Nav Tabs */}
          <div className="mt-6 flex flex-wrap gap-2 pt-4 border-t border-white/15">
            {[
              { id: 'COPILOT', label: '💬 AI Student Copilot', desc: 'DB Query' },
              { id: 'DOC_AI', label: '📄 Document Intelligence', desc: 'CV/Transcript AI' },
              { id: 'DISCOVERY', label: '🔎 Discovery & Change Feed', desc: 'Live Monitoring' },
              { id: 'CONTENT', label: '✍️ Content & News Radar', desc: 'Multichannel' },
              { id: 'AGENTS', label: '🤖 AI Employees Cockpit', desc: 'Orchestrator' },
              { id: 'ESSAY', label: '📝 Essay & Application OS', desc: 'Checklist AI' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex flex-col items-start ${
                  activeTab === tab.id
                    ? 'bg-white text-[#0052CC] shadow-md border border-white'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                <span>{tab.label}</span>
                <span className={`text-[9px] ${activeTab === tab.id ? 'text-[#0052CC]/70' : 'text-blue-200'}`}>
                  {tab.desc}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* TAB 1: AI STUDENT COPILOT & DB QUERY */}
        {activeTab === 'COPILOT' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm flex flex-col h-[550px]">
                <div className="flex items-center justify-between pb-4 border-b border-[#E2E8F0]">
                  <div className="flex items-center space-x-2">
                    <Bot className="w-5 h-5 text-[#0052CC]" />
                    <span className="font-bold text-sm text-[#1A1A1A]">ScholarBy AI Copilot Terminal</span>
                  </div>
                  <span className="text-[10px] bg-[#0052CC]/10 text-[#0052CC] font-mono font-bold px-2.5 py-1 rounded-full">
                    Direct DB Access • 20+ Universities • 25+ Scholarships
                  </span>
                </div>

                {/* Chat Stream */}
                <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
                  {chatHistory.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[85%] p-4 rounded-2xl text-xs leading-relaxed ${
                          msg.role === 'user'
                            ? 'bg-[#0052CC] text-white font-medium rounded-br-none shadow-sm'
                            : 'bg-[#F8FAFC] border border-[#E2E8F0] text-[#1A1A1A] rounded-bl-none shadow-sm'
                        }`}
                      >
                        <p className="whitespace-pre-line font-sans">{msg.text}</p>

                        {msg.data && (
                          <div className="mt-3 p-3 rounded-xl bg-white border border-[#E2E8F0] text-[#1A1A1A] space-y-2">
                            <div className="flex items-center justify-between text-[11px] font-bold">
                              <span className="text-[#0052CC]">{msg.data.title}</span>
                              <span className="bg-[#FFD60A] text-[#1A1A1A] px-2 py-0.5 rounded-md font-mono">
                                96% Suitability
                              </span>
                            </div>
                            <p className="text-[10px] text-[#64748B]">{msg.data.organization} • {msg.data.location}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  {isQuerying && (
                    <div className="flex justify-start">
                      <div className="p-3 rounded-2xl bg-[#F8FAFC] border border-[#E2E8F0] text-xs text-[#64748B] flex items-center space-x-2">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#0052CC]" />
                        <span>Querying ScholarBy Structured Database & 4D Matching Engine...</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Input Form */}
                <form onSubmit={handleQuerySubmit} className="pt-3 border-t border-[#E2E8F0] flex items-center space-x-2">
                  <input
                    type="text"
                    placeholder="Ask Copilot (e.g. Find fully funded CS scholarships in Japan with $1,400 stipend)..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="flex-1 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl px-4 py-3 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none font-sans"
                  />
                  <button
                    type="submit"
                    disabled={isQuerying || !query.trim()}
                    className="p-3 bg-[#0052CC] text-white rounded-xl hover:bg-[#003D99] disabled:opacity-50 transition-colors shadow-sm"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </div>

            {/* Sidebar Quick Prompts & 4D Breakdown */}
            <div className="space-y-4">
              <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-3">
                <div className="flex items-center space-x-2 text-xs font-bold text-[#1A1A1A]">
                  <Sparkles className="w-4 h-4 text-[#0052CC]" />
                  <span>Preset Database Queries</span>
                </div>
                <div className="space-y-2">
                  {[
                    'Find fully-funded CS Master scholarships in Japan',
                    'What are my admission odds for MIT EECS with 3.92 GPA?',
                    'Show ETH Zurich Excellence Fellowship requirements',
                    'List Oxford & Cambridge RA openings with monthly stipend',
                  ].map((preset, i) => (
                    <button
                      key={i}
                      onClick={() => setQuery(preset)}
                      className="w-full text-left p-2.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] hover:border-[#0052CC] hover:bg-blue-50/50 transition-colors text-[11px] text-[#4A5568] font-medium flex items-center justify-between group"
                    >
                      <span>{preset}</span>
                      <ChevronRight className="w-3.5 h-3.5 text-[#64748B] group-hover:text-[#0052CC]" />
                    </button>
                  ))}
                </div>
              </div>

              {/* 4D Matching Engine Explainer Card */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-white to-blue-50/40 border border-[#0052CC]/20 shadow-sm space-y-3">
                <div className="flex items-center space-x-2 text-xs font-bold text-[#0052CC]">
                  <Sliders className="w-4 h-4" />
                  <span>ScholarBy 4D Matching Model</span>
                </div>
                <p className="text-[11px] text-[#64748B] leading-relaxed">
                  We separate <strong>Eligibility</strong> from <strong>Suitability</strong> into 4 distinct dimensions:
                </p>
                <div className="space-y-2 text-[11px]">
                  <div className="flex justify-between items-center bg-white p-2 rounded-lg border border-[#E2E8F0]">
                    <span className="font-semibold text-[#1A1A1A]">🎓 Academic Fit</span>
                    <span className="font-bold text-[#0052CC]">94%</span>
                  </div>
                  <div className="flex justify-between items-center bg-white p-2 rounded-lg border border-[#E2E8F0]">
                    <span className="font-semibold text-[#1A1A1A]">🔬 Field & Research Fit</span>
                    <span className="font-bold text-emerald-600">98%</span>
                  </div>
                  <div className="flex justify-between items-center bg-white p-2 rounded-lg border border-[#E2E8F0]">
                    <span className="font-semibold text-[#1A1A1A]">💰 Funding Requirement</span>
                    <span className="font-bold text-[#0052CC]">100%</span>
                  </div>
                  <div className="flex justify-between items-center bg-white p-2 rounded-lg border border-[#E2E8F0]">
                    <span className="font-semibold text-[#1A1A1A]">⏰ Deadline Urgency</span>
                    <span className="font-bold text-amber-600">HIGH</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: DOCUMENT INTELLIGENCE ENGINE */}
        {activeTab === 'DOC_AI' && (
          <div className="space-y-6">
            <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4">
              <div className="flex items-center space-x-3">
                <div className="p-3 rounded-xl bg-[#0052CC]/10 text-[#0052CC]">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-[#1A1A1A]">
                    Sector 8: AI Document Intelligence Engine (CV & Transcript Parser)
                  </h2>
                  <p className="text-xs text-[#64748B]">
                    Upload your CV, academic transcript, or test score certificates. ScholarBy AI extracts structured profile JSON instantly, eliminating repetitive form entries.
                  </p>
                </div>
              </div>

              {/* Upload Box */}
              <div className="border-2 border-dashed border-[#0052CC]/30 hover:border-[#0052CC] bg-[#F8FAFC] rounded-2xl p-8 text-center transition-all cursor-pointer">
                <input
                  type="file"
                  onChange={handleDocUpload}
                  accept=".pdf,.docx,.jpg,.png"
                  className="hidden"
                  id="doc-upload-input"
                />
                <label htmlFor="doc-upload-input" className="cursor-pointer block space-y-3">
                  <div className="w-12 h-12 rounded-full bg-[#0052CC]/10 text-[#0052CC] flex items-center justify-center mx-auto">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#1A1A1A]">
                      {uploadedFile ? uploadedFile.name : 'Click to Upload CV, Transcript or Test Report (PDF)'}
                    </p>
                    <p className="text-[10px] text-[#64748B] mt-0.5">
                      Supports PDF, DOCX up to 10MB • Auto-extracts GPA, IELTS, DOIs & Verified Credentials
                    </p>
                  </div>
                </label>
              </div>

              {isParsingDoc && (
                <div className="p-4 rounded-xl bg-blue-50 text-[#0052CC] text-xs font-bold flex items-center justify-center space-x-2 animate-pulse">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Document Intelligence Agent parsing transcript layout & extracting research DOIs...</span>
                </div>
              )}
            </div>

            {/* Extracted Structured JSON Profile View */}
            {parsedProfile && (
              <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
                  <div className="flex items-center space-x-2 text-emerald-700 font-bold text-xs">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Structured Profile Machine JSON Created</span>
                  </div>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-mono font-bold px-2.5 py-0.5 rounded-full">
                    99.5% Extraction Accuracy
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2">
                    <span className="text-[11px] font-bold text-[#64748B] uppercase font-mono">Academic Metrics</span>
                    <div className="text-xs space-y-1 font-semibold text-[#1A1A1A]">
                      <p>🎓 Candidate: <span className="text-[#0052CC]">{parsedProfile.candidateName}</span></p>
                      <p>📊 Extracted GPA: {parsedProfile.extractedGpa}</p>
                      <p>📜 Degree Track: {parsedProfile.education}</p>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2">
                    <span className="text-[11px] font-bold text-[#64748B] uppercase font-mono">Standardized Test Scores</span>
                    <div className="text-xs space-y-1 font-semibold text-[#1A1A1A]">
                      <p>📝 SAT: {parsedProfile.testScores.SAT}</p>
                      <p>🗣️ IELTS: {parsedProfile.testScores.IELTS}</p>
                      <p>📈 GRE: {parsedProfile.testScores.GRE}</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 text-slate-100 font-mono text-[11px] overflow-x-auto space-y-1">
                  <span className="text-emerald-400 font-bold">// ScholarBy Machine-Readable Profile Record</span>
                  <pre>{JSON.stringify(parsedProfile, null, 2)}</pre>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: DISCOVERY & CHANGE FEED */}
        {activeTab === 'DISCOVERY' && (
          <div className="space-y-6">
            {/* Sector 1 & 3 Explanation */}
            <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-[#1A1A1A]">
                  Sectors 1 & 3: Scholarship Discovery Engine & Live Change Detection
                </h2>
                <p className="text-xs text-[#64748B] mt-1">
                  Autonomous AI agents continuously crawl 450+ university portals and 1,200+ live URLs, detecting deadline extensions, eligibility shifts, and funding surges.
                </p>
              </div>
              <div className="flex items-center space-x-2 text-xs font-bold text-[#0052CC] bg-[#0052CC]/10 px-3 py-1.5 rounded-full">
                <ShieldCheck className="w-4 h-4 text-[#0052CC]" />
                <span>Human-in-the-Loop Safeguard Active</span>
              </div>
            </div>

            {/* Change Logs List */}
            <div className="space-y-3">
              {changeLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC]/40 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-amber-100 text-amber-900 border border-amber-300">
                        {log.changeType.replace('_', ' ')}
                      </span>
                      <span className="text-[11px] text-[#64748B] font-mono">{log.detectedAt}</span>
                    </div>

                    <h3 className="text-xs font-bold text-[#1A1A1A]">{log.scholarshipTitle}</h3>
                    <p className="text-[11px] text-[#64748B]">{log.universityOrSource}</p>

                    <div className="p-2.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] text-[11px] flex items-center space-x-3 font-mono">
                      <span className="line-through text-red-500">{log.oldValue}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#64748B]" />
                      <span className="font-bold text-emerald-700">{log.newValue}</span>
                    </div>
                  </div>

                  <div className="flex flex-col items-end space-y-2">
                    {log.verificationStatus === 'VERIFIED_AND_PUBLISHED' ? (
                      <span className="inline-flex items-center space-x-1 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Human Verified ✓</span>
                      </span>
                    ) : (
                      <button
                        onClick={() => handleVerifyChange(log.id)}
                        className="px-3.5 py-1.5 rounded-xl bg-[#0052CC] text-white text-xs font-bold hover:bg-[#003D99] transition-colors shadow-sm flex items-center space-x-1.5"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-[#FFD60A]" />
                        <span>Human Verify & Publish</span>
                      </button>
                    )}

                    <a
                      href={log.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] font-mono text-[#0052CC] hover:underline flex items-center space-x-1"
                    >
                      <Globe className="w-3 h-3" />
                      <span>Primary PDF Source</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: CONTENT FACTORY & NEWS RADAR */}
        {activeTab === 'CONTENT' && (
          <div className="space-y-6">
            <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-3">
              <h2 className="text-lg font-bold text-[#1A1A1A]">
                Sectors 4 & 5: Multichannel AI Content Factory & News Intelligence Radar
              </h2>
              <p className="text-xs text-[#64748B]">
                One verified scholarship automatically transforms into 7 multi-channel formats. The News Radar tags international higher ed developments into 🔴 Urgent, 🟡 Useful, and ⚪ Low priority.
              </p>
            </div>

            {/* Content Items */}
            <div className="space-y-4">
              {MOCK_CONTENT_FACTORY.map((item) => (
                <div key={item.id} className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
                    <div className="flex items-center space-x-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-red-100 text-red-800 border border-red-300 flex items-center space-x-1">
                        <span>🔴</span>
                        <span>{item.priority} NEWS RADAR</span>
                      </span>
                      <span className="text-xs font-bold text-[#1A1A1A]">{item.sourceScholarship}</span>
                    </div>
                    <span className="text-[10px] text-[#64748B] font-mono">{item.publishedAt}</span>
                  </div>

                  {/* Multi-channel Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Web Article */}
                    <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-1.5">
                      <span className="text-[10px] font-bold text-[#0052CC] uppercase font-mono">🌐 Web Article</span>
                      <h4 className="text-xs font-bold text-[#1A1A1A]">{item.webArticle.title}</h4>
                      <p className="text-[11px] text-[#64748B] line-clamp-2">{item.webArticle.snippet}</p>
                    </div>

                    {/* Instagram Carousel */}
                    <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-1.5">
                      <span className="text-[10px] font-bold text-pink-600 uppercase font-mono">📸 Instagram 4:5 Carousel</span>
                      <p className="text-xs font-semibold text-[#1A1A1A]">{item.instagramCarousel.headline}</p>
                      <span className="text-[10px] text-[#64748B] font-mono">{item.instagramCarousel.slidesCount} Slides Generated</span>
                    </div>

                    {/* Telegram & LinkedIn */}
                    <div className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-1.5">
                      <span className="text-[10px] font-bold text-blue-600 uppercase font-mono">📱 Telegram & LinkedIn</span>
                      <p className="text-[11px] text-[#1A1A1A] line-clamp-2 font-mono">{item.telegramAlert.text}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: AUTONOMOUS AI EMPLOYEES COCKPIT */}
        {activeTab === 'AGENTS' && (
          <div className="space-y-6">
            <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-[#1A1A1A]">
                  Sector 10: ScholarBy Autonomous AI Employees Cockpit (The Orchestrator)
                </h2>
                <p className="text-xs text-[#64748B] mt-1">
                  Instead of disconnected tools, 10 internal AI agents operate as specialized software employees governed by strict human-in-the-loop rules.
                </p>
              </div>
              <div className="px-3.5 py-1.5 rounded-full bg-[#0052CC] text-white text-xs font-bold shadow-sm">
                System Health: 100% Operational
              </div>
            </div>

            {/* Grid of 10 Agents */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {MOCK_AI_AGENTS.map((agent) => (
                <div
                  key={agent.id}
                  className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC]/40 transition-all space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#0052CC]">{agent.sector}</span>
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800">
                      {agent.status}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-xs font-extrabold text-[#1A1A1A]">{agent.name}</h3>
                    <p className="text-[10px] text-[#64748B] mt-0.5 leading-relaxed">{agent.role}</p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] text-[10px] space-y-1 font-mono">
                    <p className="text-[#1A1A1A] font-medium">⚡ Last Action: {agent.lastAction}</p>
                    <div className="flex justify-between text-[#64748B] pt-1 border-t border-[#E2E8F0]">
                      <span>Completed Today: {agent.tasksCompletedToday}</span>
                      <span className="font-bold text-[#0052CC]">Accuracy: {agent.accuracy}</span>
                    </div>
                  </div>

                  <div className="p-2 rounded-lg bg-amber-50 border border-amber-200 text-[10px] text-amber-900 font-sans">
                    <strong>🛡️ Human Rule:</strong> {agent.humanInLoopRule}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: ESSAY & APPLICATION OS CHECKLIST */}
        {activeTab === 'ESSAY' && (
          <div className="space-y-6">
            {/* Sector 7 Application OS */}
            <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4">
              <div className="flex items-center space-x-2 text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
                <FileCheck className="w-4 h-4" />
                <span>Sector 7: Application OS & Essay Narrative Evaluator</span>
              </div>

              <h2 className="text-lg font-bold text-[#1A1A1A]">
                AI College Essay Feedback & Application OS Reminder Engine
              </h2>

              <form onSubmit={handleEssayAnalyze} className="space-y-4">
                <textarea
                  rows={6}
                  placeholder="Paste your Common App essay, MIT supplemental essay, or Statement of Purpose draft..."
                  value={essayText}
                  onChange={(e) => setEssayText(e.target.value)}
                  className="w-full bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-4 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none resize-none font-sans"
                />

                <button
                  type="submit"
                  disabled={isAnalyzingEssay || !essayText.trim()}
                  className="w-full py-3.5 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] disabled:opacity-50 transition-colors shadow-sm flex items-center justify-center space-x-2"
                >
                  <Sparkles className="w-4 h-4 text-[#FFD60A]" />
                  <span>{isAnalyzingEssay ? 'Analyzing Narrative Alignment...' : 'Evaluate Essay Narrative & Fit'}</span>
                </button>
              </form>

              {essayFeedback && (
                <div className="p-5 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-2">
                  <div className="flex items-center space-x-2 text-emerald-700 font-bold text-xs">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>AI Narrative Analysis Complete</span>
                  </div>
                  <p className="text-xs text-[#1A1A1A] whitespace-pre-line leading-relaxed font-medium">
                    {essayFeedback}
                  </p>
                </div>
              )}
            </div>

            {/* Application OS Countdown Alerts */}
            <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-[#1A1A1A] flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-amber-500" />
                  <span>Application OS Countdown & Missing Document Alerts</span>
                </h3>
                <span className="text-[10px] text-[#64748B] font-mono">Real-time Tracker</span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between text-amber-950 font-medium">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                    <span><strong>MIT EECS Application</strong>: 18 days remaining. Research proposal is still incomplete.</span>
                  </div>
                  <button className="px-3 py-1 rounded-lg bg-amber-600 text-white text-[10px] font-bold hover:bg-amber-700">
                    Complete Draft
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
