'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import {
  Compass,
  GraduationCap,
  Sparkles,
  BookmarkCheck,
  User,
  Users,
  MessageSquare,
  Bot,
  Settings,
  Bell,
  Search,
  Menu,
  X,
  Microscope,
  Trophy,
  BookOpen,
  UserCheck,
} from 'lucide-react';
import { useProfile } from '@/context/ProfileContext';
import { getCountryFlag } from '@/lib/countryFlags';

export const Navbar: React.FC = () => {
  const pathname = usePathname();
  const { student } = useProfile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const navLinks = [
    { name: 'Feed', href: '/feed', icon: Compass },
    { name: 'Explore', href: '/opportunities', icon: Sparkles },
    { name: 'Bucket List', href: '/applications', icon: BookmarkCheck },
    { name: 'Professors', href: '/professors', icon: Microscope },
    { name: 'Universities', href: '/universities', icon: GraduationCap },
    { name: 'Tutors', href: '/tutors', icon: BookOpen },
    { name: 'Consultants', href: '/consultants', icon: UserCheck },
    { name: 'Tracker', href: '/profile-tracker', icon: Trophy },
    { name: 'AI Assistant', href: '/ai-assistant', icon: Bot },
    { name: 'Communities', href: '/communities', icon: Users },
  ];

  const flagEmoji = getCountryFlag(student.user.country);

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-[#E2E8F0] shadow-sm">
      <div className="max-w-[1550px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Top-Left: Logo & Brand Identity */}
          <div className="flex-shrink-0 flex items-center">
            <Link href="/dashboard" className="flex items-center space-x-3 group">
              <div className="relative w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-[#E2E8F0] group-hover:scale-105 transition-transform p-1 shadow-card-soft">
                <Image
                  src="/logo.png"
                  alt="ScholarBy Logo"
                  width={32}
                  height={32}
                  style={{ width: 'auto', height: '100%' }}
                  className="object-contain"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-extrabold tracking-tight text-[#1A1A1A] group-hover:text-[#0052CC] transition-colors font-sans">
                  Scholar<span className="text-[#0052CC]">By</span>
                </span>
                <span className="text-[9px] tracking-widest text-[#64748B] uppercase font-mono font-semibold">
                  Global Academic Ecosystem
                </span>
              </div>
            </Link>
          </div>

          {/* Center: Desktop Navigation Tabs Starting From Middle */}
          <div className="hidden xl:flex flex-1 justify-center items-center px-4">
            <nav className="flex items-center space-x-1.5 bg-[#F8FAFC] border border-[#E2E8F0] p-1.5 rounded-2xl shadow-inner">
              {navLinks.slice(0, 8).map((link) => {
                const Icon = link.icon;
                const isActive = pathname === link.href || (link.href !== '/' && pathname.startsWith(link.href));
                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      isActive
                        ? 'bg-[#0052CC]/15 text-[#0052CC] border border-[#0052CC]/30 font-bold shadow-sm'
                        : 'text-[#4A5568] hover:text-[#0052CC] hover:bg-white/80'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#0052CC]' : 'text-[#64748B]'}`} />
                    <span>{link.name}</span>
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* Top-Right: Actions & User Profile */}
          <div className="hidden lg:flex flex-shrink-0 items-center space-x-3">
            <Link
              href="/settings"
              className="p-2 rounded-full bg-white border border-[#E2E8F0] text-[#64748B] hover:text-[#0052CC] hover:border-[#0052CC] transition-colors shadow-sm"
              title="Edit Profile Settings"
            >
              <Settings className="w-4 h-4" />
            </Link>

            <Link
              href="/messages"
              className="p-2 rounded-full bg-white border border-[#E2E8F0] text-[#64748B] hover:text-[#0052CC] hover:border-[#0052CC] transition-colors relative shadow-sm"
            >
              <MessageSquare className="w-4 h-4" />
              <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-[#FFD60A] rounded-full ring-2 ring-white" />
            </Link>

            <div className="relative">
              <button
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                className="p-2 rounded-full bg-white border border-[#E2E8F0] text-[#64748B] hover:text-[#0052CC] hover:border-[#0052CC] transition-colors relative shadow-sm"
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-[#0052CC] rounded-full ring-2 ring-white" />
              </button>

              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white border border-[#E2E8F0] rounded-xl shadow-xl p-4 z-50 text-xs">
                  <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0]">
                    <span className="font-semibold text-[#1A1A1A]">Academic Alerts</span>
                    <span className="text-[10px] bg-[#FFD60A] text-[#1A1A1A] font-bold px-2 py-0.5 rounded-full font-mono">3 New</span>
                  </div>
                  <div className="space-y-3 mt-3">
                    <div className="p-2.5 rounded-lg bg-[#F8FAFC] border border-[#E2E8F0]">
                      <p className="font-semibold text-[#1A1A1A]">Prof. Vance Accepted RA Application</p>
                      <p className="text-[#64748B] mt-0.5">Invited you for a research video interview next Tuesday.</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Profile Capsule */}
            <Link
              href={`/passport/${student.user.name.toLowerCase().replace(/\s+/g, '')}`}
              className="flex items-center space-x-2 pl-2 pr-3 py-1 rounded-full bg-white border border-[#E2E8F0] hover:border-[#0052CC] transition-colors shadow-sm group"
            >
              <div className="relative">
                <img
                  src={student.user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
                  alt={student.user.name}
                  className="w-7 h-7 rounded-full object-cover border border-[#0052CC]"
                />
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-xs font-bold text-[#1A1A1A] group-hover:text-[#0052CC] leading-tight">
                  {student.user.name.split(' ')[0]}
                </span>
                <span className="text-xs leading-none select-none ml-0.5" title={student.user.country}>
                  {flagEmoji}
                </span>
              </div>
            </Link>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="xl:hidden flex items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-[#64748B] hover:text-[#1A1A1A] hover:bg-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-b border-[#E2E8F0] bg-white px-4 pt-2 pb-4 space-y-1">
          {navLinks.map((link) => {
            const Icon = link.icon;
            return (
              <Link
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-semibold text-[#4A5568] hover:text-[#0052CC] hover:bg-[#F8FAFC]"
              >
                <Icon className="w-5 h-5 text-[#0052CC]" />
                <span>{link.name}</span>
              </Link>
            );
          })}
        </div>
      )}
    </header>
  );
};
