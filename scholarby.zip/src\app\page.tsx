import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  Sparkles,
  GraduationCap,
  BookmarkCheck,
  Compass,
  CheckCircle2,
  BadgeCheck,
  Building2,
  Microscope,
  Award,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Play,
  Users,
  TrendingUp,
} from 'lucide-react';
import { MOCK_OPPORTUNITIES, MOCK_UNIVERSITIES } from '@/lib/mockData';

export default function LandingPage() {
  return (
    <main className="relative overflow-hidden bg-[#F8FAFC]">
      {/* Hero Section matching User Mockup Image */}
      <section className="relative pt-12 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Soft Blue glow backdrop */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-[#0052CC]/10 blur-[140px] rounded-full pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 text-left space-y-6">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#FFD60A] text-xs font-bold text-[#1A1A1A] shadow-sm">
              <span>Learn</span>
              <span>•</span>
              <span>Grow</span>
              <span>•</span>
              <span>Build Your Future</span>
            </div>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-[#1A1A1A] leading-[1.1] font-sans">
              Your Learning <span className="text-[#0052CC]">Journey Starts Here</span>
            </h1>

            <p className="text-base sm:text-lg text-[#64748B] max-w-xl leading-relaxed">
              ScholarBy helps you learn, improve and achieve your goals with high-quality research opportunities, university applications, Olympiads, and a supportive global academic community.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-4">
              <Link
                href="/opportunities"
                className="px-8 py-4 rounded-full bg-[#0052CC] text-white font-bold text-sm hover:bg-[#003D99] transition-all shadow-blue-lg flex items-center space-x-2"
              >
                <span>Explore Courses & Opportunities</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/dashboard"
                className="px-6 py-4 rounded-full bg-white border border-[#E2E8F0] hover:border-[#0052CC] text-[#1A1A1A] font-bold text-sm transition-all shadow-sm flex items-center space-x-2"
              >
                <div className="w-6 h-6 rounded-full bg-[#FFD60A] flex items-center justify-center text-[#1A1A1A]">
                  <Play className="w-3 h-3 fill-current ml-0.5" />
                </div>
                <span>Watch Video</span>
              </Link>
            </div>
          </div>

          {/* Right Mobile Mockup Graphics Column matching UI design */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            <div className="relative w-full max-w-md bg-white border border-[#E2E8F0] rounded-3xl p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
                <div className="flex items-center space-x-2">
                  <div className="w-7 h-7 rounded-lg bg-[#0052CC] flex items-center justify-center text-white font-bold text-xs">
                    SB
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#1A1A1A]">ScholarBy Mobile App</h4>
                    <p className="text-[10px] text-[#64748B]">Global Student Passport</p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-[#0052CC] bg-[#0052CC]/10 px-2 py-0.5 rounded-full">
                  Live Sync
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-[#0052CC] text-white space-y-2">
                <span className="text-[10px] uppercase font-mono tracking-widest text-[#FFD60A] font-bold">
                  Verified Passport
                </span>
                <h3 className="text-lg font-bold">Alex Chen 🇺🇸</h3>
                <p className="text-xs text-white/80">SAT 1560 • USACO Gold • ISEF 2nd Award</p>
              </div>

              <div className="space-y-2">
                <div className="p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <GraduationCap className="w-5 h-5 text-[#0052CC]" />
                    <span className="text-xs font-bold text-[#1A1A1A]">MIT EECS Application</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-[#0052CC]">92%</span>
                </div>
                <div className="p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <Microscope className="w-5 h-5 text-[#0052CC]" />
                    <span className="text-xs font-bold text-[#1A1A1A]">Dr. Smith MIT Lab RA</span>
                  </div>
                  <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                    Accepted
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4 Feature Pillars matching Mockup design */}
      <section className="py-12 bg-white border-y border-[#E2E8F0] px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl bg-[#F8FAFC] border border-[#E2E8F0] hover:border-[#0052CC] transition-all card-hover-effect">
            <div className="w-12 h-12 rounded-xl bg-[#FFD60A] flex items-center justify-center text-[#1A1A1A] font-bold mb-4 shadow-sm">
              <GraduationCap className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[#1A1A1A]">Quality Courses</h3>
            <p className="text-xs text-[#64748B] mt-2 leading-relaxed">
              Learn from expert instructors with industry-relevant content across SAT, AP, programming, and research.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#F8FAFC] border border-[#E2E8F0] hover:border-[#0052CC] transition-all card-hover-effect">
            <div className="w-12 h-12 rounded-xl bg-[#FFD60A] flex items-center justify-center text-[#1A1A1A] font-bold mb-4 shadow-sm">
              <BookOpen className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[#1A1A1A]">Helpful Resources</h3>
            <p className="text-xs text-[#64748B] mt-2 leading-relaxed">
              Get access to research papers, notes, tools, and study materials anytime, anywhere.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#F8FAFC] border border-[#E2E8F0] hover:border-[#0052CC] transition-all card-hover-effect">
            <div className="w-12 h-12 rounded-xl bg-[#FFD60A] flex items-center justify-center text-[#1A1A1A] font-bold mb-4 shadow-sm">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[#1A1A1A]">Supportive Community</h3>
            <p className="text-xs text-[#64748B] mt-2 leading-relaxed">
              Connect with 10,000+ global student scholars, professors, tutors, and alumni to grow together.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#F8FAFC] border border-[#E2E8F0] hover:border-[#0052CC] transition-all card-hover-effect">
            <div className="w-12 h-12 rounded-xl bg-[#FFD60A] flex items-center justify-center text-[#1A1A1A] font-bold mb-4 shadow-sm">
              <TrendingUp className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[#1A1A1A]">Track Your Progress</h3>
            <p className="text-xs text-[#64748B] mt-2 leading-relaxed">
              Stay motivated with personalized learning paths, readiness scores, and verified passport badges.
            </p>
          </div>
        </div>
      </section>

      {/* Featured on ScholarBy Cards Grid matching UI Mockup */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-extrabold text-[#1A1A1A]">Featured on <span className="text-[#0052CC]">ScholarBy</span></h2>
            <p className="text-xs text-[#64748B] mt-1">Discover top global opportunities, research labs, and Olympiads</p>
          </div>
          <Link href="/opportunities" className="text-xs font-bold text-[#0052CC] hover:underline">
            View All ({MOCK_OPPORTUNITIES.length}) →
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl bg-[#0052CC] text-white flex flex-col justify-between h-56 shadow-blue-lg">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-widest text-[#FFD60A] font-bold">ScholarBy Feature</span>
              <h3 className="text-xl font-extrabold mt-2 leading-snug">Better Learning. Bigger Opportunities.</h3>
            </div>
            <Link href="/opportunities" className="inline-flex items-center text-xs font-bold text-[#FFD60A] hover:underline">
              Explore Opportunities →
            </Link>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] flex flex-col justify-between h-56 shadow-sm border-t-4 border-t-[#0052CC]">
            <div>
              <span className="px-2.5 py-1 rounded-full bg-[#FFD60A] text-[#1A1A1A] text-[10px] font-bold">Research Labs</span>
              <h3 className="text-lg font-bold text-[#1A1A1A] mt-3 leading-snug">Learn Something Worth Knowing.</h3>
              <p className="text-xs text-[#64748B] mt-1">20+ Verified Lab Directors accepting RAs.</p>
            </div>
            <Link href="/professors" className="inline-flex items-center text-xs font-bold text-[#0052CC] hover:underline">
              View Professors →
            </Link>
          </div>

          <div className="p-6 rounded-2xl bg-[#003D99] text-white flex flex-col justify-between h-56 shadow-lg">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-widest text-white/80">Olympiads</span>
              <h3 className="text-xl font-extrabold mt-2 leading-snug">Your Journey Is Just Beginning.</h3>
            </div>
            <Link href="/opportunities?tab=olympiads" className="inline-flex items-center text-xs font-bold text-[#FFD60A] hover:underline">
              Explore Olympiads →
            </Link>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] flex flex-col justify-between h-56 shadow-sm border-t-4 border-t-[#FFD60A]">
            <div>
              <span className="px-2.5 py-1 rounded-full bg-[#0052CC]/10 text-[#0052CC] text-[10px] font-bold">Community</span>
              <h3 className="text-lg font-bold text-[#1A1A1A] mt-3 leading-snug">Real People. Real Progress.</h3>
              <p className="text-xs text-[#64748B] mt-1">Join a community that grows with you.</p>
            </div>
            <Link href="/communities" className="inline-flex items-center text-xs font-bold text-[#0052CC] hover:underline">
              Join Community →
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
