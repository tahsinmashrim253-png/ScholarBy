'use client';

import React, { useState, useEffect } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  User,
  GraduationCap,
  Award,
  Code,
  Globe,
  Save,
  CheckCircle2,
  Plus,
  Trash2,
  BookOpen,
  Camera,
  Phone,
} from 'lucide-react';
import { useProfile } from '@/context/ProfileContext';
import { getCountryFlag } from '@/lib/countryFlags';

export default function SettingsPage() {
  const { student, updateProfile, addTestScore, removeTestScore, addProject, removeProject } = useProfile();

  const [name, setName] = useState(student.user.name);
  const [avatarUrl, setAvatarUrl] = useState(student.user.avatarUrl || '');
  const [mobile, setMobile] = useState('+1 (555) 234-5678');
  const [headline, setHeadline] = useState(student.user.headline || '');
  const [bio, setBio] = useState(student.user.bio || '');
  const [school, setSchool] = useState(student.school || '');
  const [major, setMajor] = useState(student.major || '');
  const [gpa, setGpa] = useState(student.gpa || 3.96);
  const [country, setCountry] = useState(student.user.country || 'United States');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Sync state if student changes
  useEffect(() => {
    setName(student.user.name);
    setAvatarUrl(student.user.avatarUrl || '');
    setHeadline(student.user.headline || '');
    setBio(student.user.bio || '');
    setSchool(student.school || '');
    setMajor(student.major || '');
    setGpa(student.gpa || 3.96);
    setCountry(student.user.country || 'United States');
  }, [student]);

  const flagEmoji = getCountryFlag(country);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      avatarUrl,
      headline,
      bio,
      school,
      major,
      gpa: Number(gpa),
      country,
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  const handleAddNewScore = () => {
    addTestScore({
      testType: 'SAT',
      totalScore: '1560',
      breakdown: 'Math: 800 | Reading: 760',
    });
  };

  const handleAddNewProject = () => {
    addProject({
      title: 'New AI Research Initiative',
      description: 'Engineered a novel machine learning framework for global student opportunity discovery.',
      role: 'Lead Architect',
      technologies: 'Python, PyTorch, Next.js',
    });
  };

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto">
        {/* Header */}
        <div className="pb-6 border-b border-[#E2E8F0] flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <User className="w-4 h-4 text-[#0052CC]" />
              <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
                ScholarBy Profile & Settings
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1 flex items-center space-x-2">
              <span>Edit Profile, Photo & Country Flag</span>
              <span className="text-2xl">{flagEmoji}</span>
            </h1>
          </div>

          <button
            onClick={handleSaveProfile}
            className="px-5 py-2.5 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center space-x-2 shadow-blue-lg"
          >
            <Save className="w-4 h-4" />
            <span>Save Passport Changes</span>
          </button>
        </div>

        {savedSuccess && (
          <div className="mt-4 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 text-xs font-bold flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Profile photo, mobile number, and country flag {flagEmoji} updated & saved permanently across ScholarBy!</span>
          </div>
        )}

        <form onSubmit={handleSaveProfile} className="mt-6 space-y-8">
          {/* Section 1: Photo & Basic Identity */}
          <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-6">
            <h2 className="text-base font-bold text-[#1A1A1A] flex items-center space-x-2">
              <Camera className="w-4 h-4 text-[#0052CC]" />
              <span>Profile Photo & Personal Identity</span>
            </h2>

            {/* Avatar Preview & URL Input */}
            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0]">
              <div className="relative">
                <img
                  src={avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
                  alt={name}
                  className="w-20 h-20 rounded-full object-cover border-4 border-[#0052CC] shadow-md"
                />
                <span className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-[#FFD60A] border-2 border-white flex items-center justify-center text-xs" title="Verified Photo">
                  ✓
                </span>
              </div>
              <div className="flex-1 w-full">
                <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Profile Photo Image URL</label>
                <input
                  type="text"
                  placeholder="https://images.unsplash.com/..."
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  className="w-full bg-white border border-[#E2E8F0] rounded-xl px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
                />
                <p className="text-[10px] text-[#64748B] mt-1">Paste any public image link or avatar photo URL.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-white border border-[#E2E8F0] rounded-xl px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1A1A1A] mb-1 flex items-center justify-between">
                  <span>Mobile / Phone Number</span>
                  <Phone className="w-3.5 h-3.5 text-[#0052CC]" />
                </label>
                <input
                  type="text"
                  placeholder="+1 (555) 000-0000"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  className="w-full bg-white border border-[#E2E8F0] rounded-xl px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1A1A1A] mb-1 flex items-center justify-between">
                  <span>Country of Residence</span>
                  <span className="text-sm">{flagEmoji}</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="e.g. United States, Singapore, Bangladesh, United Kingdom..."
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full bg-white border border-[#E2E8F0] rounded-xl pl-3.5 pr-8 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm pointer-events-none">
                    {flagEmoji}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Academic Headline</label>
                <input
                  type="text"
                  value={headline}
                  onChange={(e) => setHeadline(e.target.value)}
                  className="w-full bg-white border border-[#E2E8F0] rounded-xl px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Academic Bio</label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full bg-white border border-[#E2E8F0] rounded-xl p-3 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none resize-none"
              />
            </div>
          </div>

          {/* Section 2: Education & GPA */}
          <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4">
            <h2 className="text-base font-bold text-[#1A1A1A]">Education & Academic Record</h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#1A1A1A] mb-1">High School / University</label>
                <input
                  type="text"
                  value={school}
                  onChange={(e) => setSchool(e.target.value)}
                  className="w-full bg-white border border-[#E2E8F0] rounded-xl px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Major / Intended Field</label>
                <input
                  type="text"
                  value={major}
                  onChange={(e) => setMajor(e.target.value)}
                  className="w-full bg-white border border-[#E2E8F0] rounded-xl px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1A1A1A] mb-1">Unweighted GPA</label>
                <input
                  type="number"
                  step="0.01"
                  value={gpa}
                  onChange={(e) => setGpa(Number(e.target.value))}
                  className="w-full bg-white border border-[#E2E8F0] rounded-xl px-3.5 py-2 text-xs text-[#1A1A1A] focus:border-[#0052CC] focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Standardized Examinations */}
          <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-[#1A1A1A]">Standardized Examinations (SAT, IELTS, APs)</h2>
              <button
                type="button"
                onClick={handleAddNewScore}
                className="px-3 py-1.5 rounded-lg bg-[#0052CC]/10 text-[#0052CC] border border-[#0052CC]/30 text-xs font-bold hover:bg-[#0052CC]/20 flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Score</span>
              </button>
            </div>

            <div className="space-y-3">
              {student.testScores.map((ts) => (
                <div key={ts.id} className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] flex items-center justify-between gap-3">
                  <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <span className="text-xs font-bold text-[#1A1A1A]">{ts.testType}</span>
                    <span className="text-xs font-mono font-bold text-[#0052CC]">{ts.totalScore}</span>
                    <span className="text-xs text-[#64748B]">{ts.breakdown}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeTestScore(ts.id)}
                    className="p-1.5 rounded-lg bg-white text-[#64748B] hover:text-red-500 border border-[#E2E8F0]"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Section 4: Projects */}
          <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-[#1A1A1A]">Research & Software Projects</h2>
              <button
                type="button"
                onClick={handleAddNewProject}
                className="px-3 py-1.5 rounded-lg bg-[#0052CC]/10 text-[#0052CC] border border-[#0052CC]/30 text-xs font-bold hover:bg-[#0052CC]/20 flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Project</span>
              </button>
            </div>

            <div className="space-y-3">
              {student.projects.map((p) => (
                <div key={p.id} className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] flex items-start justify-between gap-3">
                  <div>
                    <h4 className="text-xs font-bold text-[#1A1A1A]">{p.title}</h4>
                    <p className="text-[11px] text-[#64748B] mt-0.5">{p.description}</p>
                    <span className="text-[10px] font-mono text-[#0052CC] font-bold mt-1 block">{p.technologies}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeProject(p.id)}
                    className="p-1.5 rounded-lg bg-white text-[#64748B] hover:text-red-500 border border-[#E2E8F0]"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center justify-center space-x-2 shadow-blue-lg"
            >
              <Save className="w-4 h-4" />
              <span>Save & Update ScholarBy Passport</span>
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}
