'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import {
  UserCheck2,
  Search,
  Star,
  Globe,
  Award,
  MessageSquare,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { MOCK_CONSULTANTS } from '@/lib/mockData';
import Link from 'next/link';

export default function ConsultantsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('ALL');

  const filteredConsultants = MOCK_CONSULTANTS.filter((c) => {
    if (selectedCountry !== 'ALL' && !c.targetCountries.includes(selectedCountry)) return false;
    if (
      searchQuery &&
      !c.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !c.specialization.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()))
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="pb-6 border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <UserCheck2 className="w-4 h-4 text-[#0052CC]" />
            <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
              Admissions & Career Consultants Marketplace
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
            Verified University Admissions Consultants (20+ Experts)
          </h1>
          <p className="text-xs text-[#64748B] mt-1">
            Book 1-on-1 consultations with verified Ivy League, Oxbridge, European, and Full Scholarship advisors.
          </p>
        </div>

        {/* Toolbar */}
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2 overflow-x-auto w-full md:w-auto pb-1">
            {['ALL', 'United States', 'United Kingdom', 'Switzerland', 'Singapore', 'Canada', 'Germany'].map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCountry(c)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCountry === c
                    ? 'bg-[#0052CC] text-white shadow-sm'
                    : 'bg-white text-[#64748B] hover:text-[#1A1A1A] border border-[#E2E8F0]'
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#64748B]" />
            <input
              type="text"
              placeholder="Search Ivy League, Oxbridge, Pre-Med..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-[#E2E8F0] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#1A1A1A] placeholder-[#64748B] focus:border-[#0052CC] focus:outline-none"
            />
          </div>
        </div>

        {/* Consultants Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          {filteredConsultants.map((c) => (
            <div
              key={c.id}
              className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC] transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <img
                      src={c.avatarUrl}
                      alt={c.name}
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-[#0052CC]"
                    />
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <h3 className="text-base font-bold text-[#1A1A1A]">{c.name}</h3>
                        {c.isVerified && (
                          <span className="w-4 h-4 rounded-full bg-[#FFD60A] text-[#1A1A1A] flex items-center justify-center text-[10px] font-bold" title="Verified Consultant">
                            ✓
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#64748B] font-semibold">{c.experienceYears} Years Admissions Experience</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-base font-extrabold font-mono text-[#0052CC]">{c.hourlyRate}</span>
                    <div className="flex items-center text-xs text-[#FFD60A] font-bold justify-end">
                      <Star className="w-3.5 h-3.5 fill-current mr-0.5" />
                      <span>{c.rating} ({c.reviewsCount})</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-[#64748B] mt-3 leading-relaxed">
                  {c.bio}
                </p>

                <div className="mt-3 p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] flex items-center justify-between text-xs">
                  <span className="text-[10px] text-[#64748B] uppercase font-mono font-bold">Track Record</span>
                  <span className="font-bold text-emerald-700">{c.successRate} Historical Success</span>
                </div>

                <div className="mt-3 flex items-center space-x-1.5 flex-wrap gap-y-1">
                  {c.specialization.map((spec) => (
                    <span
                      key={spec}
                      className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#0052CC]/10 text-[#0052CC] border border-[#0052CC]/20 font-bold"
                    >
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                <span className="text-[#64748B] font-bold">Countries: {c.targetCountries.join(', ')}</span>
                <Link
                  href="/messages"
                  className="px-4 py-2 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center space-x-1.5 shadow-sm"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Book Consultation</span>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
