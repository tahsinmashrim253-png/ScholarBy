'use client';

import React from 'react';
import Link from 'next/link';
import {
  BadgeCheck,
  Award,
  BookOpen,
  Code,
  Globe,
  Share2,
  Download,
  GraduationCap,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  Github,
  MapPin,
  Settings,
} from 'lucide-react';
import { useProfile } from '@/context/ProfileContext';
import { getCountryFlag } from '@/lib/countryFlags';

export default function PassportPage({ params }: { params: { username: string } }) {
  const { student } = useProfile();
  const flagEmoji = getCountryFlag(student.user.country);

  const handleCopyPassportUrl = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(`https://scholarby.com/@${params.username}`);
      alert(`ScholarBy Passport link copied to clipboard! (https://scholarby.com/@${params.username})`);
    }
  };

  return (
    <main className="bg-[#F8FAFC] min-h-[calc(100vh-4rem)] py-8 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
      {/* Banner & Profile Hero Header */}
      <div className="relative rounded-3xl bg-white border border-[#E2E8F0] p-6 sm:p-8 overflow-hidden shadow-sm">
        {/* Glow accent */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#0052CC]/10 blur-3xl rounded-full pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center space-x-5">
            <div className="relative">
              <img
                src={student.user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
                alt={student.user.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-4 border-[#0052CC] shadow-md"
              />
              <span className="absolute -bottom-2 -right-2 bg-white p-1.5 rounded-full border border-[#0052CC] text-sm leading-none shadow-sm">
                {flagEmoji}
              </span>
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono bg-[#FFD60A] text-[#1A1A1A] uppercase font-bold">
                  ScholarBy Verified Passport
                </span>
                <span className="text-xs text-[#64748B] font-mono font-bold">@{params.username}</span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1 flex items-center space-x-2">
                <span>{student.user.name}</span>
                <span className="text-xl" title={student.user.country}>{flagEmoji}</span>
                <span className="w-5 h-5 rounded-full bg-[#FFD60A] text-[#1A1A1A] flex items-center justify-center text-xs font-bold">
                  ✓
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-[#64748B] mt-1 max-w-xl font-medium">{student.user.headline}</p>

              <div className="flex items-center space-x-4 mt-3 text-xs text-[#64748B] flex-wrap gap-y-1 font-semibold">
                <span className="flex items-center">
                  <GraduationCap className="w-3.5 h-3.5 mr-1 text-[#0052CC]" />
                  {student.school}
                </span>
                <span className="flex items-center">
                  <span className="mr-1">{flagEmoji}</span>
                  {student.user.country}
                </span>
                <span className="font-mono text-[#0052CC] font-bold">GPA: {student.gpa} / 4.0</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-2 w-full sm:w-auto">
            <Link
              href="/settings"
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white border border-[#E2E8F0] hover:border-[#0052CC] text-xs font-bold text-[#0052CC] transition-colors flex items-center justify-center space-x-2 shadow-sm"
            >
              <Settings className="w-4 h-4" />
              <span>Edit Profile</span>
            </Link>

            <button
              onClick={handleCopyPassportUrl}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center justify-center space-x-2 shadow-sm"
            >
              <Share2 className="w-4 h-4" />
              <span>Share Passport URL</span>
            </button>
          </div>
        </div>

        {/* Bio summary */}
        <p className="text-xs text-[#64748B] mt-6 pt-4 border-t border-[#E2E8F0] leading-relaxed font-medium">
          {student.user.bio}
        </p>
      </div>

      {/* Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        {/* Left Column: Standardized Test Scores & Verified Medals */}
        <div className="space-y-8">
          {/* Section: Standardized Test Scores */}
          <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center space-x-2 mb-4">
              <Award className="w-5 h-5 text-[#0052CC]" />
              <h2 className="text-base font-bold text-[#1A1A1A]">Standardized Examination Scores</h2>
            </div>

            <div className="space-y-3">
              {student.testScores.map((score) => (
                <div
                  key={score.id}
                  className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] flex items-center justify-between"
                >
                  <div>
                    <span className="text-xs font-bold text-[#1A1A1A]">{score.testType}</span>
                    <p className="text-[11px] text-[#64748B] mt-0.5">{score.breakdown}</p>
                  </div>
                  <span className="text-sm font-extrabold font-mono text-[#0052CC] bg-[#0052CC]/10 px-2.5 py-1 rounded-lg border border-[#0052CC]/20">
                    {score.totalScore}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Verified Achievements & Olympiads */}
          <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center space-x-2 mb-4">
              <ShieldCheck className="w-5 h-5 text-[#0052CC]" />
              <h2 className="text-base font-bold text-[#1A1A1A]">ScholarBy Verified Honors</h2>
            </div>

            <div className="space-y-3">
              {student.achievements.map((ach) => (
                <div key={ach.id} className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0]">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#1A1A1A]">🏆 {ach.title}</span>
                    {ach.isVerified && <BadgeCheck className="w-4 h-4 text-[#0052CC]" />}
                  </div>
                  <p className="text-[11px] text-[#64748B] mt-1">{ach.issuer}</p>
                  {ach.verifiedBy && (
                    <span className="text-[10px] text-emerald-700 font-bold font-mono mt-1.5 flex items-center">
                      <CheckCircle2 className="w-3 h-3 mr-1" /> {ach.verifiedBy}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Projects & Publications */}
        <div className="lg:col-span-2 space-y-8">
          {/* Section: Research & Software Projects */}
          <div className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm">
            <div className="flex items-center space-x-2 mb-4">
              <Code className="w-5 h-5 text-[#0052CC]" />
              <h2 className="text-base font-bold text-[#1A1A1A]">Featured Research & Engineering Projects</h2>
            </div>

            <div className="space-y-4">
              {student.projects.map((proj) => (
                <div
                  key={proj.id}
                  className="p-5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] hover:border-[#0052CC] transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-[#1A1A1A]">{proj.title}</h3>
                    <div className="flex items-center space-x-2">
                      {proj.githubUrl && (
                        <a
                          href={proj.githubUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 rounded-lg bg-white text-[#64748B] hover:text-[#1A1A1A] border border-[#E2E8F0]"
                        >
                          <Github className="w-4 h-4" />
                        </a>
                      )}
                      {proj.projectUrl && (
                        <a
                          href={proj.projectUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 rounded-lg bg-white text-[#64748B] hover:text-[#0052CC] border border-[#E2E8F0]"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-[#64748B] mt-2 leading-relaxed">{proj.description}</p>

                  <div className="mt-3 pt-3 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                    <span className="text-[#64748B] font-medium">Role: {proj.role}</span>
                    <span className="font-mono text-[#0052CC] font-bold text-[11px]">{proj.technologies}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
