'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Briefcase, Search, Globe, Building2, ExternalLink, BookmarkCheck } from 'lucide-react';

export default function CareersPage() {
  const [searchQuery, setSearchQuery] = useState('');

  const jobs = [
    { id: 'job_1', title: 'Quantitative Research Intern', company: 'Jane Street Capital', location: 'New York / London', type: 'Summer Internship', stipend: '$12,000 / month', requirements: ['Math / CS Senior', 'USACO / IMO Medalist'], verified: true },
    { id: 'job_2', title: 'Deep Learning Engineering Intern', company: 'Google DeepMind', location: 'London & Remote', type: 'Research Internship', stipend: '$9,500 / month', requirements: ['PyTorch / JAX', 'Published Paper'], verified: true },
    { id: 'job_3', title: 'Autonomous Flight Software Engineer', company: 'Skydio Drones', location: 'San Mateo, CA', type: 'Full-Time / Grad Hire', stipend: '$160,000 / yr', requirements: ['C++ / ROS2', 'Robotics Degree'], verified: true },
    { id: 'job_4', title: 'Biomedical AI Research Fellow', company: 'Genentech Bio', location: 'Basel, Switzerland', type: 'Fellowship', stipend: 'CHF 6,500 / mo', requirements: ['Genomics / Bio-AI'], verified: true }
  ];

  return (
    <div className="flex bg-[#F8FAFC] min-h-[calc(100vh-4rem)]">
      <Sidebar />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        <div className="pb-6 border-b border-[#E2E8F0]">
          <div className="flex items-center space-x-2">
            <Briefcase className="w-4 h-4 text-[#0052CC]" />
            <span className="text-xs font-mono text-[#0052CC] font-bold uppercase tracking-wider">
              Corporate Careers & Internships
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mt-1">
            Corporate Careers & Micro-Internships
          </h1>
          <p className="text-xs text-[#64748B] mt-1">
            Discover internships, fellowship programs, and full-time hiring roles matching your ScholarBy Passport™ credentials.
          </p>
        </div>

        <div className="mt-6 relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#64748B]" />
          <input
            type="text"
            placeholder="Search Quant, AI Internships, Google, Jane Street..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-[#E2E8F0] rounded-xl pl-8 pr-3 py-2 text-xs text-[#1A1A1A] placeholder-[#64748B] focus:border-[#0052CC] focus:outline-none"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          {jobs.map((job) => (
            <div key={job.id} className="p-6 rounded-2xl bg-white border border-[#E2E8F0] shadow-sm hover:border-[#0052CC] transition-colors flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#FFD60A] text-[#1A1A1A]">
                      {job.type}
                    </span>
                    <h3 className="text-base font-bold text-[#1A1A1A] mt-2">{job.title}</h3>
                    <p className="text-xs text-[#64748B] font-semibold">{job.company} • {job.location}</p>
                  </div>
                  <span className="text-xs font-extrabold font-mono text-[#0052CC]">{job.stipend}</span>
                </div>

                <div className="mt-4 flex items-center space-x-1.5 flex-wrap gap-y-1">
                  {job.requirements.map((req) => (
                    <span key={req} className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#0052CC]/10 text-[#0052CC] font-bold">
                      {req}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#E2E8F0] flex items-center justify-between text-xs">
                <span className="text-emerald-700 font-bold">✓ Verified Hiring Partner</span>
                <a href="#" className="px-4 py-2 rounded-xl bg-[#0052CC] text-white font-bold text-xs hover:bg-[#003D99] transition-colors flex items-center space-x-1 shadow-sm">
                  <span>Apply with Passport</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
