import { StudentPassport, OpportunityItem } from '@/types';

export interface MatchResult {
  opportunity: OpportunityItem;
  score: number; // 0 to 100
  reasons: string[];
}

export function calculateOpportunityMatch(
  student: Partial<StudentPassport>,
  opp: OpportunityItem
): MatchResult {
  let score = 50; // base score
  const reasons: string[] = [];

  const studentMajor = (student.major || '').toLowerCase();
  const studentInterests = (student.interests || []).map((i) => i.toLowerCase());
  const targetCountries = (student.targetCountries || []).map((c) => c.toLowerCase());
  const oppTags = (opp.tags || []).map((t) => t.toLowerCase());
  const oppLocation = (opp.location || '').toLowerCase();

  // 1. Major & Technical Alignment (+25%)
  if (studentMajor && (opp.description.toLowerCase().includes(studentMajor) || oppTags.includes(studentMajor))) {
    score += 25;
    reasons.push(`Direct alignment with your major in ${student.major}`);
  }

  // 2. Interest / Skill Matches (+15%)
  const matchedInterests = studentInterests.filter((interest) =>
    oppTags.some((tag) => tag.includes(interest) || interest.includes(tag))
  );
  if (matchedInterests.length > 0) {
    score += Math.min(20, matchedInterests.length * 10);
    reasons.push(`Matches your skills: ${matchedInterests.slice(0, 3).join(', ')}`);
  }

  // 3. Location / Remote Compatibility (+15%)
  if (opp.isRemote) {
    score += 15;
    reasons.push('Remote flexibility aligns with international applicants');
  } else if (targetCountries.some((c) => oppLocation.includes(c))) {
    score += 15;
    reasons.push(`Located in one of your target regions (${opp.location})`);
  }

  // 4. Academic Rigor / High Test Scores Bonus (+10%)
  const hasHighSat = (student.testScores || []).some(
    (t) => t.testType === 'SAT' && parseInt(t.totalScore) >= 1450
  );
  if (hasHighSat) {
    score += 10;
    reasons.push('High SAT benchmark satisfies eligibility prerequisites');
  }

  // Cap score between 0 and 99
  const finalScore = Math.min(99, Math.max(35, score));

  if (reasons.length === 0) {
    reasons.push('Broad academic eligibility match based on degree level');
  }

  return {
    opportunity: {
      ...opp,
      matchScore: finalScore,
    },
    score: finalScore,
    reasons,
  };
}
